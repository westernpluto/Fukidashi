#!/bin/bash
# Builds an unsigned Fukidashi.ipa. Run from the folder that contains project.yml.
set -euo pipefail

brew list xcodegen >/dev/null 2>&1 || brew install xcodegen
# Xcode 26+ ships the Metal compiler separately; MLX needs it for its GPU kernels.
xcodebuild -downloadComponent MetalToolchain >/dev/null 2>&1 || true

xcodegen generate

set +e
xcodebuild \
  -project Fukidashi.xcodeproj \
  -scheme Fukidashi \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath build \
  -skipMacroValidation \
  -skipPackagePluginValidation \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build > build.log 2>&1
status=$?
set -e
if [ $status -ne 0 ]; then
  echo "Build failed. First errors:"
  grep -E "error:" build.log | head -40 || tail -60 build.log
  exit 1
fi

rm -rf Payload Fukidashi.ipa
mkdir -p Payload
cp -R build/Build/Products/Release-iphoneos/Fukidashi.app Payload/
zip -qry Fukidashi.ipa Payload
echo "Built $(du -h Fukidashi.ipa | cut -f1) Fukidashi.ipa"
