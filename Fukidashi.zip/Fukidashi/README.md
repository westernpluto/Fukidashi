# Fukidashi

An iPhone/iPad manga reader that translates pages **entirely on device** and letters the English back into the speech bubbles — no servers, no people in the loop.

## What it does, per page

1. **Finds the speech bubbles.** It looks for compact, enclosed regions of flat background that contain many small marks (the lettering). Panel interiors and art are rejected automatically.
2. **Reads the text.** Each bubble is cropped and read with Live Text (VisionKit), which handles vertical Japanese. Horizontal text (manhwa, captions, signs) is also read with Vision.
3. **Translates the whole page at once,** in reading order (right‑to‑left for manga), with the previous page's dialogue as context. It uses Apple Intelligence's on-device model with localization instructions (natural English, character voice, inferred subjects, sound effects, optional honorifics). Apple Translate is the fallback.
4. **Erases the original lettering** by repainting the bubble interior with its own background colour. Text over art is filled in from the surrounding pixels.
5. **Letters the English** in Comic Neue Bold, all caps by default. Lines follow the bubble's shape: short lines at the narrow top and bottom of an oval, longer ones through the middle. The text is centred and balanced, at the largest size that fits. Captions over art get a halo so they stay readable.

Lettering follows English manga conventions: a hand-lettered bold italic font (Mali, condensed slightly), one consistent dialogue size per page, joined balloons lettered lobe by lobe, and a heavy display font (Bangers) for short shouts in burst balloons. Furigana (small reading hints beside kanji) are removed before the text is read, so they don't garble the translation. You can import your own lettering font in Settings.

Hold your finger on a page to peek at the original. The script button shows each line's source text next to its English.

## Offline translation model (optional, recommended)

In Settings → **Offline translation model**, download Hy-MT2 (1.8B, about 1.9 GB; or 7B, about 4.3 GB). It's a dedicated translation model that runs on the phone with Apple's MLX and becomes the first choice under **Best available**. It translates each page in one pass with the previous pages as background, and it follows your **Names & terms**. Downloads go to the app's own storage and work with no connection afterwards. Hy-MT2 is made by Tencent and covered by the Tencent Hunyuan Community License.

## Names & terms

Settings → **Names & terms** holds fixed translations ("ユウタ → Yuta"). Every engine uses them, and a line that is exactly a name is replaced directly. To add one from a page, open its script and long-press a line.

## Requirements

- iOS 26 or later.
- **Best quality:** a device with Apple Intelligence turned on (iPhone 15 Pro or newer).
- **Otherwise:** open Settings in the app and download the language pack for Apple Translate. It still runs offline, but translates line by line with less context.

## Build it (no Mac needed)

The included GitHub Actions workflow builds an unsigned `.ipa` on GitHub's macOS runners.

From iSH:

```sh
cd Fukidashi
git init -b main
git add .
git commit -m "Fukidashi"
git remote add origin https://github.com/<you>/Fukidashi.git
git push -u origin main
```

Then open the repo on GitHub → **Actions** → **Build unsigned IPA** → the latest run → download **Fukidashi-ipa**. The build steps live in `ci/build.sh`, so the workflow file rarely needs to change. With the MLX packages, the first build takes 15–25 minutes. Sideload it like your other apps (SideStore, AltStore, Sideloadly, etc.).

You can re-run the build at any time with **Run workflow** on the Actions tab.

## Using it

- **+ → From Photos** or **From Files** to import pages, a folder of images, a `.cbz`/`.zip`, or a PDF. You can also use *Open in Fukidashi* from the Files app.
- Opening a chapter starts translating it automatically. Turn this off in Settings if you prefer to start translations yourself.
- **⋯ → Re-translate this page** re-runs a page, for example after changing a setting.
- Settings include source language (Japanese, Korean, Chinese), reading direction (including webtoon vertical scroll), honorifics, translating text outside bubbles, and all-caps lettering.

## Honest limits

- On-device models are small. Expect good, readable translations, not a professional release. Puns, wordplay and heavy slang are the weak spots.
- Bubbles with broken or dotted outlines (some thought bubbles) and stylised sound effects drawn into the art are often not detected. Those stay untranslated rather than getting garbled.
- Vertical Japanese written directly over the art (outside any bubble) isn't read yet.

## Project layout

```
Fukidashi/
  App/        app entry point
  Pipeline/   bubble detection, OCR, translation, cleaning, lettering
  Models/     library storage, settings, translation queue
  Import/     ZIP/CBZ reader
  Views/      library, reader, settings
  Resources/  Comic Neue fonts (SIL OFL), app icon
project.yml   XcodeGen project definition
```

Fonts: [Mali](https://github.com/cadsondemak/Mali), [Bangers](https://github.com/google/fonts/tree/main/ofl/bangers) and [Comic Neue](https://github.com/crozynski/comicneue), all SIL Open Font License 1.1 (license texts in `Resources/Fonts`).
