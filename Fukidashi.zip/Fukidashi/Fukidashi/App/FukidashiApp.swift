import SwiftUI

@main
struct FukidashiApp: App {
    @StateObject private var library = LibraryStore()
    @StateObject private var settings = AppSettings()
    @StateObject private var coordinator = TranslationCoordinator()

    init() {
        FontRegistry.registerBundledFonts()
    }

    var body: some Scene {
        WindowGroup {
            LibraryView()
                .environmentObject(library)
                .environmentObject(settings)
                .environmentObject(coordinator)
                .onOpenURL { url in
                    // "Open in Fukidashi" from Files or the share sheet.
                    library.importFiles([url])
                }
        }
    }
}
