import Compression
import Foundation

/// Minimal reader for ZIP/CBZ archives (stored and deflated entries).
final class ZipReader {
    struct Entry {
        let name: String
        let method: UInt16
        let compressedSize: Int
        let uncompressedSize: Int
        let localHeaderOffset: Int
        var isDirectory: Bool { name.hasSuffix("/") }
    }

    enum ZipError: LocalizedError {
        case notAZip, unsupported(String), corrupt
        var errorDescription: String? {
            switch self {
            case .notAZip: return "This file isn't a ZIP/CBZ archive."
            case .unsupported(let what): return "Unsupported archive: \(what)."
            case .corrupt: return "The archive looks damaged."
            }
        }
    }

    private let data: Data
    let entries: [Entry]

    init(url: URL) throws {
        data = try Data(contentsOf: url, options: .mappedIfSafe)
        entries = try ZipReader.readDirectory(data)
    }

    private static func u16(_ d: Data, _ o: Int) -> Int {
        Int(d[d.startIndex + o]) | Int(d[d.startIndex + o + 1]) << 8
    }

    private static func u32(_ d: Data, _ o: Int) -> Int {
        u16(d, o) | u16(d, o + 2) << 16
    }

    private static func readDirectory(_ d: Data) throws -> [Entry] {
        guard d.count >= 22 else { throw ZipError.notAZip }
        var eocd = -1
        var i = d.count - 22
        let floor = max(0, d.count - 65_557)
        while i >= floor {
            if u32(d, i) == 0x0605_4B50 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw ZipError.notAZip }
        let count = u16(d, eocd + 10)
        let dirOffset = u32(d, eocd + 16)
        if dirOffset == 0xFFFF_FFFF || count == 0xFFFF { throw ZipError.unsupported("ZIP64") }

        var entries: [Entry] = []
        var p = dirOffset
        for _ in 0..<count {
            guard p + 46 <= d.count, u32(d, p) == 0x0201_4B50 else { throw ZipError.corrupt }
            let flags = u16(d, p + 8)
            let method = UInt16(u16(d, p + 10))
            let compressed = u32(d, p + 20)
            let uncompressed = u32(d, p + 24)
            let nameLength = u16(d, p + 28)
            let extraLength = u16(d, p + 30)
            let commentLength = u16(d, p + 32)
            let localOffset = u32(d, p + 42)
            guard p + 46 + nameLength <= d.count else { throw ZipError.corrupt }
            let nameData = d.subdata(in: (d.startIndex + p + 46)..<(d.startIndex + p + 46 + nameLength))
            let name = (flags & 0x0800 != 0 ? String(data: nameData, encoding: .utf8) : nil)
                ?? String(data: nameData, encoding: .utf8)
                ?? String(data: nameData, encoding: .isoLatin1) ?? "entry\(entries.count)"
            entries.append(Entry(name: name, method: method, compressedSize: compressed,
                                 uncompressedSize: uncompressed, localHeaderOffset: localOffset))
            p += 46 + nameLength + extraLength + commentLength
        }
        return entries
    }

    func extract(_ entry: Entry) throws -> Data {
        let o = entry.localHeaderOffset
        guard o + 30 <= data.count, ZipReader.u32(data, o) == 0x0403_4B50 else { throw ZipError.corrupt }
        let start = o + 30 + ZipReader.u16(data, o + 26) + ZipReader.u16(data, o + 28)
        guard start + entry.compressedSize <= data.count else { throw ZipError.corrupt }
        let payload = data.subdata(in: (data.startIndex + start)..<(data.startIndex + start + entry.compressedSize))
        switch entry.method {
        case 0:
            return payload
        case 8:
            guard entry.uncompressedSize > 0 else { return Data() }
            var output = Data(count: entry.uncompressedSize)
            let written = output.withUnsafeMutableBytes { (dst: UnsafeMutableRawBufferPointer) -> Int in
                payload.withUnsafeBytes { (src: UnsafeRawBufferPointer) -> Int in
                    guard let d = dst.bindMemory(to: UInt8.self).baseAddress,
                          let s = src.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                    // COMPRESSION_ZLIB is raw DEFLATE, which is what ZIP stores.
                    return compression_decode_buffer(d, entry.uncompressedSize, s, payload.count, nil, COMPRESSION_ZLIB)
                }
            }
            guard written == entry.uncompressedSize else { throw ZipError.corrupt }
            return output
        default:
            throw ZipError.unsupported("compression method \(entry.method)")
        }
    }
}
