import PhotosUI
import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var coordinator: TranslationCoordinator

    @State private var showPhotos = false
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showFiles = false
    @State private var showSettings = false
    @State private var renaming: Chapter?
    @State private var renameText = ""

    private let columns = [GridItem(.adaptive(minimum: 150, maximum: 220), spacing: 16)]

    var body: some View {
        NavigationStack {
            Group {
                if library.chapters.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 20) {
                            ForEach(library.chapters) { chapter in
                                NavigationLink(value: chapter.id) { card(chapter) }
                                    .buttonStyle(.plain)
                                    .contextMenu { menu(for: chapter) }
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Fukidashi")
            .navigationDestination(for: UUID.self) { id in ReaderView(chapterID: id) }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                        .accessibilityLabel("Settings")
                }
                ToolbarItem(placement: .topBarTrailing) { addMenu }
            }
            .photosPicker(isPresented: $showPhotos, selection: $photoItems, maxSelectionCount: nil,
                          selectionBehavior: .ordered, matching: .images)
            .onChange(of: photoItems) { _, items in
                guard !items.isEmpty else { return }
                Task {
                    await library.importPhotos(items)
                    photoItems = []
                }
            }
            .fileImporter(isPresented: $showFiles, allowedContentTypes: LibraryStore.importTypes,
                          allowsMultipleSelection: true) { result in
                if case .success(let urls) = result { library.importFiles(urls) }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .alert("Rename chapter", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("Title", text: $renameText)
                Button("Save") { if let c = renaming { library.rename(c, to: renameText) } }
                Button("Cancel", role: .cancel) {}
            }
            .alert("Import problem", isPresented: Binding(get: { library.importError != nil },
                                                          set: { if !$0 { library.importError = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(library.importError ?? "") }
            .overlay(alignment: .bottom) {
                if let status = library.importStatus {
                    HStack(spacing: 10) { ProgressView(); Text(status) }
                        .padding(.horizontal, 16).padding(.vertical, 10)
                        .background(.regularMaterial, in: Capsule())
                        .padding(.bottom, 24)
                }
            }
        }
    }

    private var addMenu: some View {
        Menu {
            Button { showPhotos = true } label: { Label("From Photos", systemImage: "photo.on.rectangle") }
            Button { showFiles = true } label: { Label("From Files (images, CBZ, ZIP, PDF, folder)", systemImage: "folder") }
        } label: {
            Image(systemName: "plus")
        }
        .accessibilityLabel("Add chapter")
    }

    private var emptyState: some View {
        VStack(spacing: 18) {
            Image(systemName: "text.bubble")
                .font(.system(size: 54, weight: .light))
                .foregroundStyle(.secondary)
            Text("Add a chapter to start")
                .font(.title3.weight(.semibold))
            Text("Import pages from Photos or Files. Fukidashi finds the speech bubbles, translates the page on your iPhone and letters the English back in.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)
            HStack(spacing: 12) {
                Button { showPhotos = true } label: { Label("Photos", systemImage: "photo.on.rectangle") }
                    .buttonStyle(.borderedProminent)
                Button { showFiles = true } label: { Label("Files", systemImage: "folder") }
                    .buttonStyle(.bordered)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func card(_ chapter: Chapter) -> some View {
        let done = library.translatedCount(chapter)
        let job = coordinator.jobs[chapter.id]
        return VStack(alignment: .leading, spacing: 8) {
            Group {
                if chapter.pages.isEmpty {
                    Rectangle().fill(Color(.secondarySystemBackground))
                } else {
                    ThumbnailView(url: library.originalURL(chapter, 0))
                }
            }
            .aspectRatio(0.7, contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(alignment: .topTrailing) {
                if job != nil {
                    ProgressView().padding(6).background(.regularMaterial, in: Circle()).padding(6)
                }
            }
            Text(chapter.title).font(.subheadline.weight(.semibold)).lineLimit(2)
            if let job {
                ProgressView(value: Double(job.done), total: Double(max(job.total, 1)))
            } else {
                Text(done == chapter.pages.count ? "\(chapter.pages.count) pages · translated"
                                                 : "\(done) of \(chapter.pages.count) translated")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder
    private func menu(for chapter: Chapter) -> some View {
        Button {
            coordinator.translate(chapter, library: library, options: settings.options)
        } label: { Label("Translate", systemImage: "character.bubble") }
        Button {
            coordinator.translate(chapter, library: library, options: settings.options, force: true)
        } label: { Label("Re-translate all pages", systemImage: "arrow.clockwise") }
        Button {
            renameText = chapter.title
            renaming = chapter
        } label: { Label("Rename", systemImage: "pencil") }
        Button(role: .destructive) {
            coordinator.cancel(chapter.id)
            library.delete(chapter)
        } label: { Label("Delete", systemImage: "trash") }
    }
}
