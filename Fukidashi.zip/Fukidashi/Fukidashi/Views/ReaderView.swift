import SwiftUI
import UIKit

struct ReaderView: View {
    let chapterID: UUID

    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var coordinator: TranslationCoordinator

    @State private var page = 0
    @State private var showOriginal = false
    @State private var holding = false
    @State private var chromeHidden = false
    @State private var showScript = false

    var body: some View {
        Group {
            if let chapter = library.chapter(id: chapterID) {
                reader(chapter)
            } else {
                ContentUnavailableView("Chapter not found", systemImage: "book.closed")
            }
        }
    }

    @ViewBuilder
    private func reader(_ chapter: Chapter) -> some View {
        let mode = settings.resolvedReading
        let job = coordinator.jobs[chapter.id]
        ZStack(alignment: .bottom) {
            Color.black.ignoresSafeArea()
            if mode == .vertical {
                VerticalReader(chapter: chapter, showOriginal: showOriginal || holding)
            } else {
                TabView(selection: $page) {
                    ForEach(chapter.pages.indices, id: \.self) { i in
                        PageView(chapter: chapter, index: i, showOriginal: showOriginal || holding,
                                 onTap: { withAnimation(.easeInOut(duration: 0.2)) { chromeHidden.toggle() } },
                                 onHold: { holding = $0 })
                            .environment(\.layoutDirection, .leftToRight)
                            .tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .environment(\.layoutDirection, mode == .rightToLeft ? .rightToLeft : .leftToRight)
                .ignoresSafeArea()
            }

            if !chromeHidden {
                statusBar(chapter, job: job, paged: mode != .vertical)
                    .transition(.opacity)
            }
        }
        .navigationTitle(chapter.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(chromeHidden ? .hidden : .visible, for: .navigationBar)
        .toolbar { readerToolbar(chapter) }
        .statusBarHidden(chromeHidden)
        .sheet(isPresented: $showScript) {
            ScriptSheet(script: library.script(chapter, page), pageNumber: page + 1)
        }
        .alert("Translation problem", isPresented: Binding(get: { coordinator.lastError != nil },
                                                           set: { if !$0 { coordinator.lastError = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(coordinator.lastError ?? "") }
        .onAppear {
            if settings.autoTranslate {
                coordinator.translate(chapter, library: library, options: settings.options)
            }
        }
    }

    @ToolbarContentBuilder
    private func readerToolbar(_ chapter: Chapter) -> some ToolbarContent {
        ToolbarItemGroup(placement: .topBarTrailing) {
            Button { showOriginal.toggle() } label: {
                Image(systemName: showOriginal ? "eye.slash" : "eye")
            }
            .accessibilityLabel(showOriginal ? "Show translation" : "Show original")

            Button { showScript = true } label: { Image(systemName: "text.quote") }
                .accessibilityLabel("Show script")

            Menu {
                if coordinator.isRunning(chapter.id) {
                    Button(role: .destructive) { coordinator.cancel(chapter.id) } label: {
                        Label("Stop translating", systemImage: "stop.circle")
                    }
                } else {
                    Button {
                        coordinator.translate(chapter, library: library, options: settings.options)
                    } label: { Label("Translate chapter", systemImage: "character.bubble") }
                    Button {
                        coordinator.translate(chapter, library: library, options: settings.options, pages: [page], force: true)
                    } label: { Label("Re-translate this page", systemImage: "arrow.clockwise") }
                }
                if library.isTranslated(chapter, page) {
                    ShareLink(item: library.translatedURL(chapter, page)) {
                        Label("Share this page", systemImage: "square.and.arrow.up")
                    }
                }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
        }
    }

    private func statusBar(_ chapter: Chapter, job: TranslationCoordinator.Job?, paged: Bool) -> some View {
        HStack(spacing: 10) {
            if let job {
                ProgressView().controlSize(.small)
                Text("Translating \(job.done + 1) of \(job.total)")
            } else if paged && !library.isTranslated(chapter, page) {
                Image(systemName: "character.bubble")
                Text("Not translated yet")
            }
            if paged {
                if job != nil || !library.isTranslated(chapter, page) { Text("·").foregroundStyle(.secondary) }
                Text("Page \(page + 1) of \(chapter.pages.count)")
            }
            if showOriginal || holding {
                Text("· Original").foregroundStyle(.secondary)
            }
        }
        .font(.footnote.weight(.medium))
        .padding(.horizontal, 14).padding(.vertical, 8)
        .background(.regularMaterial, in: Capsule())
        .padding(.bottom, 18)
    }
}

/// One page in the paged reader.
private struct PageView: View {
    let chapter: Chapter
    let index: Int
    let showOriginal: Bool
    let onTap: () -> Void
    let onHold: (Bool) -> Void

    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var coordinator: TranslationCoordinator
    @State private var image: UIImage?

    private var url: URL {
        !showOriginal && library.isTranslated(chapter, index)
            ? library.translatedURL(chapter, index) : library.originalURL(chapter, index)
    }

    var body: some View {
        ZoomableImageView(image: image, onTap: onTap, onHold: onHold)
            .overlay {
                if image == nil { ProgressView().tint(.white) }
            }
            .task(id: "\(url.path)#\(coordinator.revision)") {
                let screen = UIScreen.main.bounds.size
                let maxDim = Int(max(screen.width, screen.height) * UIScreen.main.scale * 1.5)
                if let loaded = await DisplayImages.load(url, maxDimension: maxDim) { image = loaded }
            }
    }
}

/// Webtoon-style continuous vertical scroll.
private struct VerticalReader: View {
    let chapter: Chapter
    let showOriginal: Bool
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var coordinator: TranslationCoordinator

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                ForEach(chapter.pages.indices, id: \.self) { i in
                    StripImage(url: !showOriginal && library.isTranslated(chapter, i)
                               ? library.translatedURL(chapter, i) : library.originalURL(chapter, i),
                               revision: coordinator.revision)
                }
            }
        }
    }
}

private struct StripImage: View {
    let url: URL
    let revision: Int
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                Rectangle().fill(Color(white: 0.12)).aspectRatio(0.7, contentMode: .fit)
                    .overlay { ProgressView().tint(.white) }
            }
        }
        .task(id: "\(url.path)#\(revision)") {
            let width = Int(UIScreen.main.bounds.width * UIScreen.main.scale)
            image = await DisplayImages.load(url, maxDimension: width * 6)
        }
    }
}

/// The page's source text next to its English, for checking a line.
struct ScriptSheet: View {
    let script: PageScript?
    let pageNumber: Int
    @Environment(\.dismiss) private var dismiss
    @State private var addingTerm: ScriptLine?

    var body: some View {
        NavigationStack {
            Group {
                if let script, !script.lines.isEmpty {
                    List {
                        if let note = script.note {
                            Section { Text(note).font(.footnote).foregroundStyle(.secondary) }
                        }
                        Section {
                            ForEach(script.lines) { line in
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(line.english).font(.body)
                                    Text(line.source).font(.callout).foregroundStyle(.secondary)
                                        .textSelection(.enabled)
                                }
                                .padding(.vertical, 2)
                                .contextMenu {
                                    Button {
                                        addingTerm = line
                                    } label: { Label("Add to names & terms", systemImage: "character.book.closed") }
                                }
                            }
                        }
                    }
                } else {
                    ContentUnavailableView("No script yet", systemImage: "text.quote",
                                           description: Text(script?.note ?? "This page hasn't been translated."))
                }
            }
            .navigationTitle("Page \(pageNumber) script")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
                if let script, !script.lines.isEmpty {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            UIPasteboard.general.string = script.lines.map(\.english).joined(separator: "\n")
                        } label: { Image(systemName: "doc.on.doc") }
                        .accessibilityLabel("Copy English")
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .sheet(item: $addingTerm) { line in
            GlossaryEditor(source: line.source, english: line.english)
        }
    }
}
