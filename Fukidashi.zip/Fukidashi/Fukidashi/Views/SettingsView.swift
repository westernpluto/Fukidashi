import SwiftUI
import Translation

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Comics are in", selection: $settings.sourceLanguage) {
                        ForEach(SourceLanguage.allCases) { Text($0.displayName).tag($0) }
                    }
                    Picker("Reading direction", selection: $settings.readingMode) {
                        ForEach(ReadingMode.allCases) { Text($0.label).tag($0) }
                    }
                } header: { Text("Source") }

                Section {
                    Picker("Translator", selection: $settings.engine) {
                        ForEach(EngineChoice.allCases) { Text($0.label).tag($0) }
                    }
                    Toggle("Keep honorifics (-san, -kun…)", isOn: $settings.keepHonorifics)
                    Toggle("Translate text outside bubbles", isOn: $settings.translateOutsideBubbles)
                    Toggle("Translate when a chapter opens", isOn: $settings.autoTranslate)
                } header: { Text("Translation") } footer: {
                    Text("Apple Intelligence reads each page as a whole, with the previous page for context, so it handles dropped subjects and character voice better. Apple Translate is used as a fallback. Everything runs on this device.")
                }

                Section {
                    Toggle("All-caps lettering", isOn: $settings.allCaps)
                } header: { Text("Lettering") } footer: {
                    Text("English manga is traditionally lettered in capitals. Changes apply to pages translated afterwards.")
                }

                Section {
                    LabeledContent("Apple Intelligence", value: Localizer.appleIntelligenceStatus)
                    LanguagePackRow(language: settings.sourceLanguage)
                } header: { Text("On-device engines") }

                Section {
                    Text("Lettering font: Comic Neue, licensed under the SIL Open Font License.")
                        .font(.footnote).foregroundStyle(.secondary)
                } header: { Text("About") }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
        }
    }
}

/// Shows whether Apple Translate's language pack is installed and offers the
/// system download prompt if it isn't.
private struct LanguagePackRow: View {
    let language: SourceLanguage
    @State private var status: LanguageAvailability.Status?
    @State private var configuration: TranslationSession.Configuration?

    var body: some View {
        HStack {
            Text("Apple Translate · \(language.displayName)")
            Spacer()
            switch status {
            case .none:
                ProgressView()
            case .some(.installed):
                Text("Installed").foregroundStyle(.secondary)
            case .some(.supported):
                Button("Download") {
                    configuration = TranslationSession.Configuration(source: language.localeLanguage,
                                                                     target: Locale.Language(identifier: "en"))
                }
            default:
                Text("Not supported").foregroundStyle(.secondary)
            }
        }
        .task(id: language) { await refresh() }
        .translationTask(configuration) { session in
            do { try await session.prepareTranslation() } catch {}
            await refresh()
        }
    }

    @MainActor
    private func refresh() async {
        status = await LanguageAvailability().status(from: language.localeLanguage,
                                                     to: Locale.Language(identifier: "en"))
        if status == .installed { configuration = nil }
    }
}
