import SwiftUI
import Translation
import UniformTypeIdentifiers

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State private var importingFont = false
    @State private var fontError: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Comics are in", selection: $settings.sourceLanguage) {
                        ForEach(SourceLanguage.allCases) { Text($0.displayName).tag($0) }
                    }
                    Picker("Reading direction", selection: $settings.readingMode) {
                        ForEach(ReadingMode.allCases) { Text($0.label).tag($0) }
                    }
                } header: { Text("Source") }

                Section {
                    Picker("Translator", selection: $settings.engine) {
                        ForEach(EngineChoice.allCases) { Text($0.label).tag($0) }
                    }
                    Toggle("Keep honorifics (-san, -kun…)", isOn: $settings.keepHonorifics)
                    Toggle("Translate text outside bubbles", isOn: $settings.translateOutsideBubbles)
                    Toggle("Translate when a chapter opens", isOn: $settings.autoTranslate)
                    NavigationLink {
                        GlossaryView()
                    } label: {
                        LabeledContent("Names & terms", value: settings.glossary.isEmpty ? "None" : "\(settings.glossary.count)")
                    }
                } header: { Text("Translation") } footer: {
                    Text("Best available uses the offline model once it's downloaded, then Apple Intelligence, then Apple Translate. Names & terms are always translated your way. Everything runs on this device.")
                }

                OfflineModelSection()

                Section {
                    Picker("Font", selection: $settings.fontChoice) {
                        ForEach(LetteringFontChoice.allCases) { choice in
                            Text(choice == .custom ? (settings.customFontName ?? "Your font") : choice.label).tag(choice)
                        }
                    }
                    Button("Import a font…") { importingFont = true }
                    if let fontError {
                        Text(fontError).font(.footnote).foregroundStyle(.red)
                    }
                    Toggle("All-caps speech bubbles", isOn: $settings.allCaps)
                    Picker("Text over the art", selection: $settings.captionStyle) {
                        ForEach(CaptionStyle.allCases) { Text($0.label).tag($0) }
                    }
                } header: { Text("Lettering") } footer: {
                    Text("Import a .ttf or .otf you own (for example a comic lettering font) to use it for all lettering. Blend rebuilds the art behind captions and letters the English with an outline; Caption box puts it on a soft white panel. Changes apply to pages translated afterwards.")
                }

                Section {
                    LabeledContent("Apple Intelligence", value: Localizer.appleIntelligenceStatus)
                    LanguagePackRow(language: settings.sourceLanguage)
                } header: { Text("On-device engines") }

                Section {
                    Text("Lettering font: Comic Neue, licensed under the SIL Open Font License.")
                        .font(.footnote).foregroundStyle(.secondary)
                } header: { Text("About") }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importingFont, allowedContentTypes: [.font]) { result in
                switch result {
                case .success(let url):
                    do {
                        settings.customFontName = try FontRegistry.importFont(from: url)
                        settings.fontChoice = .custom
                        fontError = nil
                    } catch {
                        fontError = "That file couldn't be used as a font."
                    }
                case .failure:
                    break
                }
            }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } }
            }
        }
    }
}

/// Shows whether Apple Translate's language pack is installed and offers the
/// system download prompt if it isn't.
private struct LanguagePackRow: View {
    let language: SourceLanguage
    @State private var status: LanguageAvailability.Status?
    @State private var configuration: TranslationSession.Configuration?

    var body: some View {
        HStack {
            Text("Apple Translate · \(language.displayName)")
            Spacer()
            switch status {
            case .none:
                ProgressView()
            case .some(.installed):
                Text("Installed").foregroundStyle(.secondary)
            case .some(.supported):
                Button("Download") {
                    configuration = TranslationSession.Configuration(source: language.localeLanguage,
                                                                     target: Locale.Language(identifier: "en"))
                }
            default:
                Text("Not supported").foregroundStyle(.secondary)
            }
        }
        .task(id: language) { await refresh() }
        .translationTask(configuration) { session in
            do { try await session.prepareTranslation() } catch {}
            await refresh()
        }
    }

    @MainActor
    private func refresh() async {
        status = await LanguageAvailability().status(from: language.localeLanguage,
                                                     to: Locale.Language(identifier: "en"))
        if status == .installed { configuration = nil }
    }
}

/// Download, status and choice of the offline translation model.
private struct OfflineModelSection: View {
    @EnvironmentObject private var settings: AppSettings
    @ObservedObject private var downloader = OfflineModelDownloader.shared
    @State private var confirmDelete = false

    var body: some View {
        let model = settings.offlineModel
        let installed = OfflineModelFiles.isInstalled(model)
        Section {
            Picker("Model", selection: $settings.offlineModel) {
                ForEach(OfflineModelChoice.allCases) { Text($0.label).tag($0) }
            }
            .disabled(isDownloading)
            switch downloader.state {
            case .downloading(let fraction):
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: fraction)
                    HStack {
                        Text("Downloading… \(Int(fraction * 100))%").font(.footnote).foregroundStyle(.secondary)
                        Spacer()
                        Button("Cancel", role: .cancel) { downloader.cancel() }.font(.footnote)
                    }
                }
            case .failed(let message):
                Text(message).font(.footnote).foregroundStyle(.red)
                Button("Try again") { downloader.download(model) }
            case .idle:
                if installed {
                    LabeledContent("Status", value: "Ready, works offline")
                    Button("Delete model", role: .destructive) { confirmDelete = true }
                } else {
                    Button("Download model") { downloader.download(model) }
                }
            }
        } header: {
            Text("Offline translation model")
        } footer: {
            Text("\(model.note) Downloads once (Wi-Fi recommended), then translates with no connection. Hy-MT2 is made by Tencent and covered by the Tencent Hunyuan Community License.")
        }
        .id(downloader.revision)
        .confirmationDialog("Delete the offline model?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Delete", role: .destructive) { downloader.delete(model) }
        }
    }

    private var isDownloading: Bool {
        if case .downloading = downloader.state { return true }
        return false
    }
}

/// The user's fixed translations for names and terms.
struct GlossaryView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var editing: GlossaryEntry?
    @State private var adding = false

    var body: some View {
        List {
            if settings.glossary.isEmpty {
                Text("Add character names and special terms so every page spells them the same way, e.g. ユウタ → Yuta. You can also add them from a page's script.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(settings.glossary) { entry in
                Button {
                    editing = entry
                } label: {
                    HStack {
                        Text(entry.source)
                        Spacer()
                        Text(entry.english).foregroundStyle(.secondary)
                    }
                }
                .foregroundStyle(.primary)
            }
            .onDelete { settings.glossary.remove(atOffsets: $0) }
        }
        .navigationTitle("Names & terms")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { adding = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Add")
            }
        }
        .sheet(isPresented: $adding) { GlossaryEditor(source: "", english: "") }
        .sheet(item: $editing) { entry in GlossaryEditor(source: entry.source, english: entry.english) }
    }
}

/// Add or change one name/term.
struct GlossaryEditor: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.dismiss) private var dismiss
    @State var source: String
    @State var english: String

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Japanese (e.g. ユウタ)", text: $source)
                    TextField("English (e.g. Yuta)", text: $english)
                        .textInputAutocapitalization(.words)
                } footer: {
                    Text("Pages translated after this use your spelling. Re-translate a page to apply it there.")
                }
            }
            .navigationTitle("Name or term")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        settings.addGlossary(source: source, english: english)
                        dismiss()
                    }
                    .disabled(source.trimmingCharacters(in: .whitespaces).isEmpty
                              || english.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
    }
}
