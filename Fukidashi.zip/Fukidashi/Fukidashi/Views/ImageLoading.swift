import SwiftUI
import UIKit

enum DisplayImages {
    /// Decodes off the main thread at a size suitable for the screen.
    static func load(_ url: URL, maxDimension: Int) async -> UIImage? {
        await Task.detached(priority: .userInitiated) { () -> UIImage? in
            guard let cg = ImageFiles.thumbnail(url, maxDimension: maxDimension) else { return nil }
            return UIImage(cgImage: cg)
        }.value
    }
}

/// A small async thumbnail for the library grid.
struct ThumbnailView: View {
    let url: URL
    var maxDimension = 500
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            Rectangle().fill(Color(.secondarySystemBackground))
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "book.pages").font(.title2).foregroundStyle(.tertiary)
            }
        }
        .clipped()
        .task(id: url) { image = await DisplayImages.load(url, maxDimension: maxDimension) }
    }
}
