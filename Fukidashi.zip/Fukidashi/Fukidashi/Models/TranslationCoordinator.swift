import Foundation
import SwiftUI
import UIKit

/// Runs chapter translations page by page, in order, so each page can use the
/// previous page's dialogue as context.
@MainActor
final class TranslationCoordinator: ObservableObject {
    struct Job {
        var done: Int
        var total: Int
        var currentPage: Int?
    }

    @Published private(set) var jobs: [UUID: Job] = [:]
    @Published var lastError: String?
    /// Bumped whenever a page finishes so views reload that image.
    @Published private(set) var revision = 0

    private var tasks: [UUID: Task<Void, Never>] = [:]
    private var backgroundTasks: [UUID: UIBackgroundTaskIdentifier] = [:]

    func isRunning(_ chapterID: UUID) -> Bool { tasks[chapterID] != nil }

    func translate(_ chapter: Chapter, library: LibraryStore, options: TranslationOptions,
                   pages: [Int]? = nil, force: Bool = false) {
        guard tasks[chapter.id] == nil else { return }
        let indices = pages ?? Array(chapter.pages.indices)
        let todo = indices.filter { force || !library.isTranslated(chapter, $0) }
        guard !todo.isEmpty else { return }
        if force { library.clearTranslations(chapter, pages: todo) }

        let chapterID = chapter.id
        jobs[chapterID] = Job(done: 0, total: todo.count, currentPage: todo.first)
        // Keep going for a little while if the app is sent to the background.
        backgroundTasks[chapterID] = UIApplication.shared.beginBackgroundTask(withName: "Translate chapter") { [weak self] in
            Task { @MainActor in self?.endBackgroundTask(chapterID) }
        }

        tasks[chapterID] = Task { [weak self] in
            for (n, index) in todo.enumerated() {
                if Task.isCancelled { break }
                self?.jobs[chapterID]?.currentPage = index
                let input = library.originalURL(chapter, index)
                let output = library.translatedURL(chapter, index)
                let scriptURL = library.scriptURL(chapter, index)
                let context = library.contextLines(before: index, in: chapter)
                do {
                    _ = try await Task.detached(priority: .userInitiated) {
                        try await PageProcessor.process(input: input, output: output, scriptURL: scriptURL,
                                                        context: context, options: options)
                    }.value
                    self?.revision += 1
                } catch {
                    self?.lastError = "Page \(index + 1): \(error.localizedDescription)"
                    if error is TranslationEngineError { break }
                }
                self?.jobs[chapterID]?.done = n + 1
            }
            self?.finish(chapterID, library: library)
        }
    }

    func cancel(_ chapterID: UUID) {
        tasks[chapterID]?.cancel()
    }

    private func finish(_ chapterID: UUID, library: LibraryStore) {
        jobs[chapterID] = nil
        tasks[chapterID] = nil
        library.objectWillChange.send()
        endBackgroundTask(chapterID)
    }

    private func endBackgroundTask(_ chapterID: UUID) {
        guard let id = backgroundTasks.removeValue(forKey: chapterID), id != .invalid else { return }
        UIApplication.shared.endBackgroundTask(id)
    }
}
