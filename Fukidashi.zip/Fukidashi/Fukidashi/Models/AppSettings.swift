import Combine
import Foundation

enum SourceLanguage: String, CaseIterable, Identifiable, Codable, Sendable {
    case japanese, korean, chineseSimplified, chineseTraditional

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .japanese: return "Japanese"
        case .korean: return "Korean"
        case .chineseSimplified: return "Chinese (Simplified)"
        case .chineseTraditional: return "Chinese (Traditional)"
        }
    }

    /// BCP-47 code used by Vision and Live Text.
    var visionCode: String {
        switch self {
        case .japanese: return "ja-JP"
        case .korean: return "ko-KR"
        case .chineseSimplified: return "zh-Hans"
        case .chineseTraditional: return "zh-Hant"
        }
    }

    var localeLanguage: Locale.Language {
        switch self {
        case .japanese: return Locale.Language(identifier: "ja")
        case .korean: return Locale.Language(identifier: "ko")
        case .chineseSimplified: return Locale.Language(identifier: "zh-Hans")
        case .chineseTraditional: return Locale.Language(identifier: "zh-Hant")
        }
    }

    var defaultReading: ReadingMode { self == .japanese ? .rightToLeft : .leftToRight }

    /// Korean separates words with spaces; Japanese and Chinese don't.
    var joinsLinesWithSpace: Bool { self == .korean }

    /// Number of characters in `text` that belong to this language's script.
    func scriptCount(_ text: String) -> Int {
        text.unicodeScalars.reduce(0) { (count: Int, s: Unicode.Scalar) -> Int in
            let v = s.value
            let hit: Bool
            switch self {
            case .japanese:
                hit = (0x3040...0x30FF).contains(v) || (0x4E00...0x9FFF).contains(v)
                    || (0x3400...0x4DBF).contains(v) || (0xFF66...0xFF9F).contains(v)
            case .korean:
                hit = (0xAC00...0xD7AF).contains(v) || (0x1100...0x11FF).contains(v) || (0x3130...0x318F).contains(v)
            case .chineseSimplified, .chineseTraditional:
                hit = (0x4E00...0x9FFF).contains(v) || (0x3400...0x4DBF).contains(v)
            }
            return hit ? count + 1 : count
        }
    }
}

enum ReadingMode: String, CaseIterable, Identifiable, Codable {
    case automatic, rightToLeft, leftToRight, vertical
    var id: String { rawValue }
    var label: String {
        switch self {
        case .automatic: return "Match language"
        case .rightToLeft: return "Right to left (manga)"
        case .leftToRight: return "Left to right"
        case .vertical: return "Vertical scroll (webtoon)"
        }
    }
}

enum CaptionStyle: String, CaseIterable, Identifiable, Codable, Sendable {
    case blend, box
    var id: String { rawValue }
    var label: String { self == .blend ? "Blend into the art" : "Caption box" }
}

enum EngineChoice: String, CaseIterable, Identifiable, Codable, Sendable {
    case automatic, appleIntelligence, appleTranslate
    var id: String { rawValue }
    var label: String {
        switch self {
        case .automatic: return "Best available"
        case .appleIntelligence: return "Apple Intelligence"
        case .appleTranslate: return "Apple Translate"
        }
    }
}

/// A snapshot of the settings that affect translation output.
struct TranslationOptions: Sendable {
    var source: SourceLanguage
    var engine: EngineChoice
    var keepHonorifics: Bool
    var allCaps: Bool
    var translateOutsideBubbles: Bool
    var captionStyle: CaptionStyle
}

@MainActor
final class AppSettings: ObservableObject {
    private let defaults = UserDefaults.standard

    @Published var sourceLanguage: SourceLanguage { didSet { defaults.set(sourceLanguage.rawValue, forKey: "sourceLanguage") } }
    @Published var engine: EngineChoice { didSet { defaults.set(engine.rawValue, forKey: "engine") } }
    @Published var keepHonorifics: Bool { didSet { defaults.set(keepHonorifics, forKey: "keepHonorifics") } }
    @Published var allCaps: Bool { didSet { defaults.set(allCaps, forKey: "allCaps") } }
    @Published var translateOutsideBubbles: Bool { didSet { defaults.set(translateOutsideBubbles, forKey: "outsideBubbles") } }
    @Published var autoTranslate: Bool { didSet { defaults.set(autoTranslate, forKey: "autoTranslate") } }
    @Published var readingMode: ReadingMode { didSet { defaults.set(readingMode.rawValue, forKey: "readingMode") } }
    @Published var captionStyle: CaptionStyle { didSet { defaults.set(captionStyle.rawValue, forKey: "captionStyle") } }

    init() {
        let d = UserDefaults.standard
        sourceLanguage = SourceLanguage(rawValue: d.string(forKey: "sourceLanguage") ?? "") ?? .japanese
        engine = EngineChoice(rawValue: d.string(forKey: "engine") ?? "") ?? .automatic
        keepHonorifics = d.object(forKey: "keepHonorifics") as? Bool ?? false
        allCaps = d.object(forKey: "allCaps") as? Bool ?? true
        translateOutsideBubbles = d.object(forKey: "outsideBubbles") as? Bool ?? true
        autoTranslate = d.object(forKey: "autoTranslate") as? Bool ?? true
        readingMode = ReadingMode(rawValue: d.string(forKey: "readingMode") ?? "") ?? .automatic
        captionStyle = CaptionStyle(rawValue: d.string(forKey: "captionStyle") ?? "") ?? .blend
    }

    var resolvedReading: ReadingMode {
        readingMode == .automatic ? sourceLanguage.defaultReading : readingMode
    }

    var options: TranslationOptions {
        TranslationOptions(source: sourceLanguage, engine: engine, keepHonorifics: keepHonorifics,
                           allCaps: allCaps, translateOutsideBubbles: translateOutsideBubbles,
                           captionStyle: captionStyle)
    }
}
