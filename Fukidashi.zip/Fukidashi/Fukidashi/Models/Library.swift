import Foundation
import PDFKit
import PhotosUI
import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct Chapter: Identifiable, Codable, Hashable {
    var id: UUID
    var title: String
    var created: Date
    /// File names inside the chapter's pages/ folder, in reading order.
    var pages: [String]
}

/// Chapters live in Documents/Library/<id>/ with pages/, translated/ and scripts/.
@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var chapters: [Chapter] = []
    @Published var importStatus: String?
    @Published var importError: String?

    let root: URL

    static let importTypes: [UTType] = {
        var types: [UTType] = [.image, .zip, .pdf, .folder]
        if let cbz = UTType(filenameExtension: "cbz") { types.append(cbz) }
        return types
    }()

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        root = docs.appendingPathComponent("Library", isDirectory: true)
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        load()
    }

    // MARK: Paths

    func folder(_ chapter: Chapter) -> URL { root.appendingPathComponent(chapter.id.uuidString, isDirectory: true) }

    func originalURL(_ chapter: Chapter, _ index: Int) -> URL {
        folder(chapter).appendingPathComponent("pages").appendingPathComponent(chapter.pages[index])
    }

    func translatedURL(_ chapter: Chapter, _ index: Int) -> URL {
        folder(chapter).appendingPathComponent("translated").appendingPathComponent(String(format: "%04d.jpg", index + 1))
    }

    func scriptURL(_ chapter: Chapter, _ index: Int) -> URL {
        folder(chapter).appendingPathComponent("scripts").appendingPathComponent(String(format: "%04d.json", index + 1))
    }

    func isTranslated(_ chapter: Chapter, _ index: Int) -> Bool {
        FileManager.default.fileExists(atPath: translatedURL(chapter, index).path)
    }

    func translatedCount(_ chapter: Chapter) -> Int {
        chapter.pages.indices.filter { isTranslated(chapter, $0) }.count
    }

    func chapter(id: UUID) -> Chapter? { chapters.first { $0.id == id } }

    func script(_ chapter: Chapter, _ index: Int) -> PageScript? {
        guard let data = try? Data(contentsOf: scriptURL(chapter, index)) else { return nil }
        return try? JSONDecoder().decode(PageScript.self, from: data)
    }

    /// English lines from the pages just before `index`, for translation context.
    func contextLines(before index: Int, in chapter: Chapter, limit: Int = 10) -> [String] {
        var lines: [String] = []
        var i = index - 1
        while i >= 0 && lines.count < limit {
            if let s = script(chapter, i) { lines = s.lines.map(\.english) + lines }
            i -= 1
            if index - i > 2 { break }
        }
        return Array(lines.suffix(limit))
    }

    // MARK: Persistence

    func load() {
        let fm = FileManager.default
        let dirs = (try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)) ?? []
        chapters = dirs.compactMap { dir in
            guard let data = try? Data(contentsOf: dir.appendingPathComponent("chapter.json")) else { return nil }
            return try? JSONDecoder().decode(Chapter.self, from: data)
        }
        .sorted { $0.created > $1.created }
    }

    private func save(_ chapter: Chapter) {
        if let data = try? JSONEncoder().encode(chapter) {
            try? data.write(to: folder(chapter).appendingPathComponent("chapter.json"))
        }
    }

    func rename(_ chapter: Chapter, to title: String) {
        guard let i = chapters.firstIndex(where: { $0.id == chapter.id }) else { return }
        let trimmed = title.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        chapters[i].title = trimmed
        save(chapters[i])
    }

    func delete(_ chapter: Chapter) {
        try? FileManager.default.removeItem(at: folder(chapter))
        chapters.removeAll { $0.id == chapter.id }
    }

    func clearTranslations(_ chapter: Chapter, pages: [Int]? = nil) {
        for i in pages ?? Array(chapter.pages.indices) {
            try? FileManager.default.removeItem(at: translatedURL(chapter, i))
            try? FileManager.default.removeItem(at: scriptURL(chapter, i))
        }
        objectWillChange.send()
    }

    // MARK: Import

    func importPhotos(_ items: [PhotosPickerItem]) async {
        guard !items.isEmpty else { return }
        importStatus = "Importing \(items.count) photo(s)…"
        var blobs: [Data] = []
        for item in items {
            if let data = try? await item.loadTransferable(type: Data.self) { blobs.append(data) }
        }
        let title = "Imported " + Date().formatted(date: .abbreviated, time: .shortened)
        let root = self.root
        let pages = blobs
        let chapter = await Task.detached(priority: .userInitiated) { () -> Chapter? in
            ChapterWriter.write(title: title, root: root) { emit in
                for data in pages { emit(data, nil) }
            }
        }.value
        finishImport(chapter)
    }

    func importFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        importStatus = "Importing…"
        let root = self.root
        Task {
            let created = await Task.detached(priority: .userInitiated) { () -> ([Chapter], String?) in
                var made: [Chapter] = []
                var looseImages: [URL] = []
                var errorText: String?
                var scoped: [URL] = []
                for url in urls where url.startAccessingSecurityScopedResource() { scoped.append(url) }
                defer { scoped.forEach { $0.stopAccessingSecurityScopedResource() } }

                for url in urls {
                    let ext = url.pathExtension.lowercased()
                    var isDir: ObjCBool = false
                    FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
                    do {
                        if isDir.boolValue {
                            if let c = ChapterWriter.importFolder(url, root: root) { made.append(c) }
                        } else if ext == "zip" || ext == "cbz" {
                            if let c = try ChapterWriter.importArchive(url, root: root) { made.append(c) }
                        } else if ext == "pdf" {
                            if let c = ChapterWriter.importPDF(url, root: root) { made.append(c) }
                        } else if ImageFiles.imageExtensions.contains(ext) {
                            looseImages.append(url)
                        }
                    } catch {
                        errorText = "\(url.lastPathComponent): \(error.localizedDescription)"
                    }
                }
                if !looseImages.isEmpty {
                    let sorted = looseImages.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
                    let title = sorted.count == 1 ? sorted[0].deletingPathExtension().lastPathComponent : "Imported pages"
                    if let c = ChapterWriter.write(title: title, root: root, pages: { emit in
                        for u in sorted { if let d = try? Data(contentsOf: u) { emit(d, u.pathExtension) } }
                    }) { made.append(c) }
                }
                return (made, errorText)
            }.value
            for c in created.0 { chapters.insert(c, at: 0) }
            importStatus = nil
            if let e = created.1 { importError = e } else if created.0.isEmpty { importError = "No pages were found in that file." }
        }
    }

    private func finishImport(_ chapter: Chapter?) {
        importStatus = nil
        if let chapter { chapters.insert(chapter, at: 0) } else { importError = "Those photos couldn't be imported." }
    }
}

/// File work for importing, safe to run off the main thread.
enum ChapterWriter {
    /// Creates a chapter folder and writes pages as `pages` emits them.
    static func write(title: String, root: URL, pages: (_ emit: (Data, String?) -> Void) -> Void) -> Chapter? {
        let id = UUID()
        let folder = root.appendingPathComponent(id.uuidString, isDirectory: true)
        let pagesDir = folder.appendingPathComponent("pages", isDirectory: true)
        let fm = FileManager.default
        for sub in ["pages", "translated", "scripts"] {
            try? fm.createDirectory(at: folder.appendingPathComponent(sub, isDirectory: true), withIntermediateDirectories: true)
        }
        var names: [String] = []
        pages { data, hintedExt in
            guard let ext = ImageFiles.fileExtension(for: data) ?? hintedExt?.lowercased() else { return }
            let name = String(format: "%04d.%@", names.count + 1, ext)
            if (try? data.write(to: pagesDir.appendingPathComponent(name))) != nil { names.append(name) }
        }
        guard !names.isEmpty else {
            try? fm.removeItem(at: folder)
            return nil
        }
        let chapter = Chapter(id: id, title: title, created: Date(), pages: names)
        if let json = try? JSONEncoder().encode(chapter) {
            try? json.write(to: folder.appendingPathComponent("chapter.json"))
        }
        return chapter
    }

    static func importArchive(_ url: URL, root: URL) throws -> Chapter? {
        let zip = try ZipReader(url: url)
        let images = zip.entries
            .filter { !$0.isDirectory && !$0.name.hasPrefix("__MACOSX") && !($0.name as NSString).lastPathComponent.hasPrefix(".") }
            .filter { ImageFiles.imageExtensions.contains(($0.name as NSString).pathExtension.lowercased()) }
            .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        return write(title: url.deletingPathExtension().lastPathComponent, root: root) { emit in
            for entry in images {
                if let data = try? zip.extract(entry) { emit(data, (entry.name as NSString).pathExtension) }
            }
        }
    }

    static func importFolder(_ url: URL, root: URL) -> Chapter? {
        let files = ((try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? [])
            .filter { ImageFiles.imageExtensions.contains($0.pathExtension.lowercased()) }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        return write(title: url.lastPathComponent, root: root) { emit in
            for f in files { if let d = try? Data(contentsOf: f) { emit(d, f.pathExtension) } }
        }
    }

    static func importPDF(_ url: URL, root: URL) -> Chapter? {
        guard let doc = PDFDocument(url: url) else { return nil }
        return write(title: url.deletingPathExtension().lastPathComponent, root: root) { emit in
            for i in 0..<doc.pageCount {
                guard let page = doc.page(at: i) else { continue }
                let bounds = page.bounds(for: .mediaBox)
                let scale = min(3.0, 2400.0 / max(bounds.width, bounds.height))
                let size = CGSize(width: bounds.width * scale, height: bounds.height * scale)
                let image = page.thumbnail(of: size, for: .mediaBox)
                if let data = image.jpegData(compressionQuality: 0.92) { emit(data, "jpg") }
            }
        }
    }
}
