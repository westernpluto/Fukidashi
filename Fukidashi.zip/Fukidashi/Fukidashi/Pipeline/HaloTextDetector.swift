import CoreGraphics
import Foundation

/// Text found outside speech bubbles: captions over the art, credits, labels.
struct HaloBlock {
    /// Page pixels, top-left origin.
    var rect: CGRect
    /// Typical glyph size in page pixels.
    var glyph: CGFloat
    /// Dark components that make up the lettering.
    var markIDs: Set<Int32>
    var vertical: Bool
}

struct HaloDetection {
    var blocks: [HaloBlock]
    /// Areas covered by a title logo (left alone).
    var logoZones: [CGRect]
    var logoMarkIDs: Set<Int32>
    /// Component labels of the page's dark pixels (ids used by `markIDs`).
    var labels: [Int32]
}

/// Lettering outside bubbles almost always has a light outline so it stays
/// readable over the art. A dark mark whose whole edge touches light pixels is
/// a "haloed" mark; glyph-sized haloed marks that sit close together and share
/// a size form a block of text. Clusters of very large haloed marks are title
/// logos, which are left alone.
enum HaloTextDetector {
    struct Mark {
        var id: Int32
        var minX: Int, minY: Int, maxX: Int, maxY: Int
        var area: Int
        var width: Int { maxX - minX + 1 }
        var height: Int { maxY - minY + 1 }
        var size: Int { max(width, height) }
        var aspect: Double { Double(size) / Double(max(1, min(width, height))) }
        /// Size used to compare marks: for long merged runs of glyphs, their thickness.
        var key: Int { aspect > 1.6 ? min(width, height) : size }
        var fill: Double { Double(area) / Double(width * height) }
        var rect: CGRect { CGRect(x: minX, y: minY, width: width, height: height) }
        var center: CGPoint { CGPoint(x: CGFloat(minX + maxX) / 2, y: CGFloat(minY + maxY) / 2) }
    }

    static func detect(gray: [UInt8], width w: Int, height h: Int, excluding bubbles: [BubbleCandidate]) -> HaloDetection {
        let dark = gray.map { $0 <= 100 }
        let (labels, comps) = BubbleDetector.label(dark, width: w, height: h, eightConnected: true)
        let gmin = max(7, Int(0.007 * Double(w)))
        let bigGlyph = 0.065 * Double(w)

        var marks: [Mark] = []
        for c in comps {
            let size = max(c.width, c.height)
            guard size >= 3, Double(size) <= 0.25 * Double(w), c.area >= 4 else { continue }
            guard haloFraction(c, labels: labels, gray: gray, width: w, height: h) >= 0.72 else { continue }
            let cx = (c.minX + c.maxX) / 2, cy = (c.minY + c.maxY) / 2
            if bubbles.contains(where: { $0.filled.contains(cx, cy) }) { continue }
            marks.append(Mark(id: c.id, minX: c.minX, minY: c.minY, maxX: c.maxX, maxY: c.maxY, area: c.area))
        }

        // Title-logo zones: clusters of five or more huge, glyph-shaped marks.
        let huge = marks.filter { Double($0.size) > bigGlyph && $0.aspect <= 1.8 && $0.fill < 0.75 }
        var logoZones: [CGRect] = []
        for zone in cluster(huge, gap: { 0.6 * Double(min($0.size, $1.size)) }, compatible: { _, _ in true }) where zone.count >= 5 {
            let sizes = zone.map(\.size).sorted()
            let pad = CGFloat(sizes[sizes.count / 2]) * 0.3
            logoZones.append(union(zone.map(\.rect)).insetBy(dx: -pad, dy: -pad))
        }

        // Blocks of text: nearby marks of a similar size.
        let glyphMarks = marks.filter { $0.key >= gmin && Double($0.key) <= 0.15 * Double(w) }
        let sizeFloor = Int(1.5 * Double(gmin))
        let groups = cluster(glyphMarks,
                             gap: { 0.5 * Double(min($0.key, $1.key)) + 2 },
                             compatible: { max($0.key, $1.key) * 2 <= min($0.key, $1.key) * 5 },
                             spread: 2.5, floor: sizeFloor)
        var blocks: [(rect: CGRect, glyph: CGFloat, marks: [Mark])] = []
        for g in groups {
            let glyph = CGFloat(median(g.map(\.key)))
            guard g.count >= 3 || (g.count == 2 && Double(glyph) >= 0.03 * Double(w)) else { continue }
            blocks.append((union(g.map(\.rect)), glyph, g))
        }

        // The rest of a title (smaller kana between the big glyphs) joins its logo.
        var grew = !logoZones.isEmpty
        while grew {
            grew = false
            for (i, b) in blocks.enumerated() {
                if let k = logoZones.firstIndex(where: { $0.insetBy(dx: -b.glyph, dy: -b.glyph).intersects(b.rect) }) {
                    logoZones[k] = logoZones[k].union(b.rect)
                    blocks.remove(at: i)
                    grew = true
                    break
                }
            }
        }

        // Staggered columns of one caption become one block.
        var merged = true
        while merged {
            merged = false
            outer: for i in blocks.indices {
                for j in blocks.indices where j > i {
                    let a = blocks[i], b = blocks[j]
                    guard max(a.glyph, b.glyph) <= 1.5 * min(a.glyph, b.glyph) else { continue }
                    let keys = (a.marks + b.marks).map { max($0.key, sizeFloor) }
                    guard let kmax = keys.max(), let kmin = keys.min(), Double(kmax) <= 2.5 * Double(kmin) else { continue }
                    let gap = 0.8 * min(a.glyph, b.glyph)
                    guard a.rect.insetBy(dx: -gap, dy: -gap).intersects(b.rect) else { continue }
                    let all = a.marks + b.marks
                    blocks[i] = (a.rect.union(b.rect), CGFloat(median(all.map(\.key))), all)
                    blocks.remove(at: j)
                    merged = true
                    break outer
                }
            }
        }

        // Attach punctuation, dakuten and other small marks; split stacked rows of
        // horizontal text (credits, labels) so each line keeps its own place.
        var result: [HaloBlock] = []
        for (bi, b) in blocks.enumerated() {
            let others = blocks.enumerated().filter { $0.offset != bi }.map { $0.element.rect }
            let vertical = b.rect.height > 1.3 * b.rect.width
            var zone = b.rect.insetBy(dx: -0.6 * b.glyph, dy: -0.6 * b.glyph)
            if vertical { zone.size.height += 0.9 * b.glyph }   // trailing "…!?" below the last column
            let members = marks.filter { m in
                if b.marks.contains(where: { $0.id == m.id }) { return true }
                return zone.contains(m.center) && CGFloat(m.key) <= 0.7 * b.glyph
                    && !others.contains { $0.contains(m.center) }
            }
            if vertical {
                result.append(HaloBlock(rect: union(members.map(\.rect)), glyph: b.glyph,
                                        markIDs: Set(members.map(\.id)), vertical: true))
            } else {
                for row in rows(of: members, glyph: b.glyph) {
                    let rect = union(row.map(\.rect))
                    let rowGlyph = CGFloat(median(row.filter { CGFloat($0.key) > 0.5 * b.glyph }.map(\.height)))
                    result.append(HaloBlock(rect: rect, glyph: max(rowGlyph, b.glyph * 0.6),
                                            markIDs: Set(row.map(\.id)), vertical: false))
                }
            }
        }
        result.sort { $0.rect.width * $0.rect.height > $1.rect.width * $1.rect.height }

        let logoIDs = Set(marks.filter { m in logoZones.contains { $0.contains(m.center) } }.map(\.id))
        return HaloDetection(blocks: Array(result.prefix(40)), logoZones: logoZones, logoMarkIDs: logoIDs, labels: labels)
    }

    /// Share of a component's edge pixels that have light pixels 2–4 px outside
    /// (looking past the anti-aliased rim).
    static func haloFraction(_ c: BubbleDetector.Component, labels: [Int32], gray: [UInt8], width w: Int, height h: Int) -> Double {
        var edge = 0, lit = 0
        let dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        for y in c.minY...c.maxY {
            for x in c.minX...c.maxX where labels[y * w + x] == c.id {
                for (dx, dy) in dirs {
                    let nx = x + dx, ny = y + dy
                    if nx >= 0, ny >= 0, nx < w, ny < h, labels[ny * w + nx] == c.id { continue }
                    edge += 1
                    for k in 2...4 {
                        let px = x + dx * k, py = y + dy * k
                        if px >= 0, py >= 0, px < w, py < h, gray[py * w + px] >= 175 { lit += 1; break }
                    }
                }
            }
        }
        return edge >= 8 ? Double(lit) / Double(edge) : 0
    }

    /// Rows of horizontal text from the marks' vertical extents.
    static func rows(of marks: [Mark], glyph: CGFloat) -> [[Mark]] {
        let tolerance = max(1, Int(0.05 * glyph))
        var spans: [(lo: Int, hi: Int)] = []
        for m in marks.filter({ CGFloat($0.key) > 0.5 * glyph }).sorted(by: { $0.minY < $1.minY }) {
            if let last = spans.last, m.minY <= last.hi + tolerance {
                spans[spans.count - 1].hi = max(last.hi, m.maxY)
            } else {
                spans.append((m.minY, m.maxY))
            }
        }
        guard spans.count > 1 else { return [marks] }
        var out = [[Mark]](repeating: [], count: spans.count)
        for m in marks {
            let cy = (m.minY + m.maxY) / 2
            let i = spans.firstIndex { cy >= $0.lo - tolerance && cy <= $0.hi + tolerance }
                ?? spans.indices.min { abs((spans[$0].lo + spans[$0].hi) / 2 - cy) < abs((spans[$1].lo + spans[$1].hi) / 2 - cy) }!
            out[i].append(m)
        }
        return out.filter { !$0.isEmpty }
    }

    /// Union-find over nearby marks. With `spread`, a cluster's largest mark may
    /// be at most `spread` times its smallest (sizes below `floor` count as
    /// `floor`), so a chain of in-between sizes can't join small captions to big
    /// display lettering.
    static func cluster(_ items: [Mark], gap: (Mark, Mark) -> Double, compatible: (Mark, Mark) -> Bool,
                        spread: Double? = nil, floor: Int = 0) -> [[Mark]] {
        var parent = Array(items.indices)
        var lo = items.map { max($0.key, floor) }
        var hi = lo
        func find(_ a: Int) -> Int {
            var a = a
            while parent[a] != a { parent[a] = parent[parent[a]]; a = parent[a] }
            return a
        }
        let order = items.indices.sorted { items[$0].minX < items[$1].minX }
        for (n, i) in order.enumerated() {
            let a = items[i]
            for j in order[(n + 1)...] {
                let b = items[j]
                // Sorted by left edge: every gap rule is under a.size + 3, so once b
                // starts that far to the right of a, no later item can link to a.
                if b.minX > a.maxX + a.size + 3 { break }
                guard compatible(a, b) else { continue }
                let g = Int(gap(a, b).rounded(.up))
                if a.maxX + g < b.minX || b.maxX + g < a.minX || a.maxY + g < b.minY || b.maxY + g < a.minY { continue }
                let ra = find(i), rb = find(j)
                guard ra != rb else { continue }
                if let spread, Double(max(hi[ra], hi[rb])) > spread * Double(min(lo[ra], lo[rb])) { continue }
                parent[ra] = rb
                lo[rb] = min(lo[ra], lo[rb])
                hi[rb] = max(hi[ra], hi[rb])
            }
        }
        var groups: [Int: [Mark]] = [:]
        for i in items.indices { groups[find(i), default: []].append(items[i]) }
        return Array(groups.values)
    }

    static func union(_ rects: [CGRect]) -> CGRect {
        rects.dropFirst().reduce(rects.first ?? .zero) { $0.union($1) }
    }

    static func median(_ v: [Int]) -> Int {
        guard !v.isEmpty else { return 0 }
        return v.sorted()[v.count / 2]
    }
}
