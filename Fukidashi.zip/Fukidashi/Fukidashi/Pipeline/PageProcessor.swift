import CoreGraphics
import Foundation

/// One translated piece of text on a page (saved so the reader can show the script).
struct ScriptLine: Codable, Identifiable {
    var id: Int
    var kind: String
    var source: String
    var english: String
    var rect: CGRect
}

struct PageScript: Codable {
    var lines: [ScriptLine]
    var note: String?
}

enum ProcessingError: LocalizedError {
    case unreadable
    var errorDescription: String? { "This page's image couldn't be opened." }
}

/// A piece of text to translate.
struct TextRegion {
    enum Kind: String {
        /// Inside a speech bubble or boxed caption.
        case bubble
        /// A horizontal line Vision read outside bubbles.
        case caption
        /// Outlined lettering outside bubbles (over the art, credits, labels).
        case overlay
    }
    var kind: Kind
    var bubble: BubbleCandidate?
    var marks: Set<Int32> = []
    var vertical = false
    /// Page pixels: bounds used for reading order, erasing and lettering.
    var rect: CGRect
    var glyph: CGFloat
    var source: String
    var lineCount = 1
    var alignment: LetteringPlan.Alignment = .center
    /// Shared size cap so stacked lines (credits) letter at one size.
    var stackGlyph: CGFloat?
}

/// The full on-device pipeline for one page:
/// find text → read it → translate with context → erase → letter English.
enum PageProcessor {
    static func process(input: URL, output: URL, scriptURL: URL, context: [String],
                        options: TranslationOptions) async throws -> PageScript {
        guard let image = ImageFiles.load(input), let canvas = PixelCanvas(image: image) else {
            throw ProcessingError.unreadable
        }
        let w = canvas.width, h = canvas.height
        let gray = canvas.grayscale()
        let lang = options.source

        // 1. Speech bubbles, each read on its own (Live Text handles vertical text).
        let candidates = BubbleDetector.detect(gray: gray, width: w, height: h)
        let observations = PageOCR.recognizeLines(in: image, language: lang)
        var regions: [TextRegion] = []
        var bubbles: [BubbleCandidate] = []
        for bubble in candidates {
            var text = ""
            if let crop = OCRCrop.make(for: bubble, gray: gray, width: w, height: h) {
                let raw = await LiveTextReader.shared.read(crop, language: lang)
                text = normalize(raw, language: lang)
            }
            if lang.scriptCount(text) == 0 {
                // Horizontal text: use Vision's lines that fall inside this bubble.
                let inside = observations
                    .filter { bubble.filled.contains(Int($0.rect.midX), Int($0.rect.midY)) && $0.confidence >= 0.3 }
                    .sorted { $0.rect.minY < $1.rect.minY }
                let joined = normalize(inside.map(\.text).joined(separator: "\n"), language: lang)
                if lang.scriptCount(joined) > 0 { text = joined }
            }
            let isText = lang.scriptCount(text) > 0
                || (Localizer.punctuationOnly(text, language: lang) != nil && bubble.textRect.height < bubble.glyph * 4)
            guard isText else { continue }
            bubbles.append(bubble)
            regions.append(TextRegion(kind: .bubble, bubble: bubble, rect: bubble.filled.frame,
                                      glyph: bubble.glyph, source: text))
        }

        // 2. Text outside bubbles.
        var halo: HaloDetection?
        if options.translateOutsideBubbles {
            let found = HaloTextDetector.detect(gray: gray, width: w, height: h, excluding: bubbles)
            halo = found

            // The title logo is left alone; its text also identifies copies of the
            // title elsewhere on the page (e.g. a small cover image).
            var logoText = ""
            for zone in found.logoZones {
                if let crop = OCRCrop.make(marks: found.logoMarkIDs, rect: zone, glyph: 60, labels: found.labels, width: w, height: h) {
                    let raw = await LiveTextReader.shared.read(crop, language: lang)
                    logoText += normalize(raw, language: lang)
                }
            }
            func usable(_ text: String) -> Bool {
                guard lang.scriptCount(text) >= 2 else { return false }
                let core = String(text.filter { !$0.isPunctuation && !$0.isWhitespace })
                return !(core.count >= 2 && logoText.contains(core))
            }
            func inLogo(_ r: CGRect) -> Bool { found.logoZones.contains { $0.intersects(r) } }
            func inBubble(_ r: CGRect) -> Bool {
                bubbles.contains { $0.filled.contains(Int(r.midX), Int(r.midY)) }
            }

            // Vertical captions over the art.
            var overlays: [TextRegion] = []
            for block in found.blocks where block.vertical {
                guard let crop = OCRCrop.make(marks: block.markIDs, rect: block.rect, glyph: block.glyph,
                                              labels: found.labels, width: w, height: h) else { continue }
                let raw = await LiveTextReader.shared.read(crop, language: lang)
                let text = normalize(raw, language: lang)
                guard usable(text) else { continue }
                overlays.append(TextRegion(kind: .overlay, marks: block.markIDs, vertical: true,
                                           rect: block.rect, glyph: block.glyph, source: text))
            }

            // Horizontal lines Vision read (credits, labels, narration).
            let lines = observations.filter { obs in
                obs.confidence >= 0.35 && lang.scriptCount(obs.text) >= 2 && obs.rect.width >= obs.rect.height * 0.8
                    && !inBubble(obs.rect) && !inLogo(obs.rect)
                    && !overlays.contains { overlap(obs.rect, $0.rect) > 0.3 }
            }
            var rows = groupCaptions(lines, language: lang)

            // Horizontal outlined lines Vision missed.
            for block in found.blocks where !block.vertical {
                if inLogo(block.rect) || inBubble(block.rect) || rows.contains(where: { overlap(block.rect, $0.rect) > 0.4 }) { continue }
                guard let crop = OCRCrop.make(marks: block.markIDs, rect: block.rect, glyph: block.glyph,
                                              labels: found.labels, width: w, height: h) else { continue }
                let raw = await LiveTextReader.shared.read(crop, language: lang)
                let text = normalize(raw, language: lang)
                guard usable(text) else { continue }
                rows.append(TextRegion(kind: .overlay, marks: block.markIDs, rect: block.rect,
                                       glyph: block.glyph, source: text))
            }
            alignStacks(&rows)
            regions += overlays + rows
        }

        guard !regions.isEmpty else {
            if let out = canvas.makeImage() { ImageFiles.writeJPEG(out, to: output) }
            let script = PageScript(lines: [], note: "No text found on this page.")
            try? JSONEncoder().encode(script).write(to: scriptURL)
            return script
        }

        // 3. Translate the page as a whole, in reading order.
        regions = ReadingOrder.sort(regions, rightToLeft: lang == .japanese)
        let result = try await Localizer.translate(regions.map(\.source), context: context, options: options)

        // 4. Erase and letter.
        var script: [ScriptLine] = []
        let page = CGRect(x: 0, y: 0, width: w, height: h)
        for (i, region) in regions.enumerated() {
            guard let english = result.lines[i], !english.isEmpty else { continue }
            switch region.kind {
            case .bubble:
                guard let bubble = region.bubble else { continue }
                let background = Cleaner.backgroundColor(of: bubble, canvas: canvas)
                Cleaner.clean(bubble: bubble, color: background, canvas: canvas)
                let plan = Letterer.plan(text: english, area: bubble.filled, glyph: bubble.glyph,
                                         pageWidth: w, allCaps: options.allCaps)
                Letterer.draw(plan, on: canvas, color: background.luma > 128 ? .black : .white, halo: nil)

            case .caption, .overlay:
                let erased: Cleaner.Erased
                if region.kind == .overlay, let labels = halo?.labels {
                    erased = Cleaner.erase(marks: region.marks, rect: region.rect, glyph: region.glyph,
                                           labels: labels, canvas: canvas)
                } else {
                    erased = Cleaner.inpaint(rect: region.rect, canvas: canvas)
                }
                let r = region.rect, g = region.glyph
                let box: CGRect
                if region.vertical {
                    // English runs across, so give it width around the original column(s).
                    let width = min(CGFloat(w) * 0.48, max(r.width + g * 0.6, g * 8))
                    box = CGRect(x: r.midX - width / 2, y: r.minY, width: width, height: max(r.height, g * 2))
                } else if region.lineCount > 1 {
                    box = r.insetBy(dx: -g * 0.6, dy: -g * 0.3)
                } else {
                    let width = min(CGFloat(w) - 8, max(r.width * 1.6, r.width + g * 4))
                    let height = max(r.height * 1.5, g * 1.6)
                    box = CGRect(x: r.midX - width / 2, y: r.midY - height / 2, width: width, height: height)
                }
                let clipped = box.intersection(page)
                guard !clipped.isNull, clipped.width >= 4, clipped.height >= 4 else { continue }
                let area = LocalMask(x0: Int(clipped.minX), y0: Int(clipped.minY),
                                     width: Int(clipped.width), height: Int(clipped.height), fill: true)
                let plan = Letterer.plan(text: english, area: area, glyph: g, pageWidth: w, allCaps: options.allCaps,
                                         padding: erased.busy ? 8 : 1,
                                         maxScale: region.vertical ? 1.25 : 0.85,
                                         maxSize: region.stackGlyph.map { $0 * 0.85 }, alignment: region.alignment)
                if erased.busy {
                    // Over the art: cover the original with a soft plate sized to both texts.
                    let pad = max(6, plan.fontSize * 0.4)
                    let plate = Letterer.bounds(of: plan).insetBy(dx: -pad, dy: -pad)
                        .union(r.insetBy(dx: -4, dy: -4)).intersection(page)
                    Letterer.drawPlate(plate, on: canvas)
                    Letterer.draw(plan, on: canvas, color: .black, halo: nil)
                } else {
                    let dark = erased.background.luma < 110
                    Letterer.draw(plan, on: canvas, color: dark ? .white : .black, halo: dark ? .black : .white)
                }
            }
            script.append(ScriptLine(id: i, kind: region.kind.rawValue, source: region.source,
                                     english: english, rect: region.rect))
        }

        guard let out = canvas.makeImage() else { throw ProcessingError.unreadable }
        ImageFiles.writeJPEG(out, to: output)
        let pageScript = PageScript(lines: script, note: result.note)
        try? JSONEncoder().encode(pageScript).write(to: scriptURL)
        return pageScript
    }

    static func normalize(_ text: String, language: SourceLanguage) -> String {
        let pieces = text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        if language.joinsLinesWithSpace {
            return pieces.joined(separator: " ")
        }
        return pieces.joined().replacingOccurrences(of: " ", with: "")
    }

    /// Share of `a` covered by `b`.
    static func overlap(_ a: CGRect, _ b: CGRect) -> CGFloat {
        let i = a.intersection(b)
        guard !i.isNull, a.width > 0, a.height > 0 else { return 0 }
        return (i.width * i.height) / (a.width * a.height)
    }

    /// Each Vision line is its own row, except long lines of the same size that
    /// stack closely: those are one paragraph and are translated together.
    static func groupCaptions(_ obs: [PageTextObservation], language: SourceLanguage) -> [TextRegion] {
        var groups: [[PageTextObservation]] = []
        for o in obs.sorted(by: { $0.rect.minY < $1.rect.minY }) {
            let isLong = o.rect.width > o.rect.height * 10
            if isLong, let gi = groups.firstIndex(where: { group in
                guard let last = group.last, last.rect.width > last.rect.height * 10 else { return false }
                let gap = o.rect.minY - last.rect.maxY
                let overlapX = min(o.rect.maxX, last.rect.maxX) - max(o.rect.minX, last.rect.minX)
                let similar = max(o.rect.height, last.rect.height) <= 1.25 * min(o.rect.height, last.rect.height)
                return similar && gap < last.rect.height * 0.8 && gap > -last.rect.height * 0.5 && overlapX > 0
            }) {
                groups[gi].append(o)
            } else {
                groups.append([o])
            }
        }
        return groups.map { group in
            let rect = group.dropFirst().reduce(group[0].rect) { $0.union($1.rect) }
            let heights = group.map(\.rect.height).sorted()
            let glyph = max(8, heights[heights.count / 2] * 0.95)
            let text = normalize(group.map(\.text).joined(separator: "\n"), language: language)
            return TextRegion(kind: .caption, rect: rect, glyph: glyph, source: text, lineCount: group.count)
        }
    }

    /// Stacked single lines (credits, labels) keep the original's alignment and
    /// share one lettering size.
    static func alignStacks(_ rows: inout [TextRegion]) {
        let order = rows.indices.filter { rows[$0].lineCount == 1 }.sorted { rows[$0].rect.minY < rows[$1].rect.minY }
        var stacks: [[Int]] = []
        for i in order {
            let r = rows[i].rect
            if let si = stacks.lastIndex(where: { stack in
                guard let last = stack.last else { return false }
                let p = rows[last].rect
                let gap = r.minY - p.maxY
                let overlapX = min(r.maxX, p.maxX) - max(r.minX, p.minX)
                return gap < 1.2 * min(rows[i].glyph, rows[last].glyph) && gap > -0.5 * rows[last].glyph && overlapX > 0
            }) {
                stacks[si].append(i)
            } else {
                stacks.append([i])
            }
        }
        for stack in stacks where stack.count >= 2 {
            let rects = stack.map { rows[$0].rect }
            let glyph = stack.map { rows[$0].glyph }.min() ?? 0
            let lefts = rects.map(\.minX), rights = rects.map(\.maxX)
            let tolerance = glyph * 0.6
            let alignment: LetteringPlan.Alignment
            if (rights.max()! - rights.min()!) < tolerance {
                alignment = .right(rights.max()!)
            } else if (lefts.max()! - lefts.min()!) < tolerance {
                alignment = .left(lefts.min()!)
            } else {
                alignment = .center
            }
            for i in stack {
                rows[i].alignment = alignment
                rows[i].stackGlyph = glyph
            }
        }
    }
}

enum ReadingOrder {
    /// Rows from top to bottom; within a row, right to left for manga.
    static func sort(_ regions: [TextRegion], rightToLeft: Bool) -> [TextRegion] {
        let byTop = regions.sorted { $0.rect.minY < $1.rect.minY }
        var rows: [[TextRegion]] = []
        var rowLimit: CGFloat = -.greatestFiniteMagnitude
        for r in byTop {
            if !rows.isEmpty && r.rect.minY < rowLimit {
                rows[rows.count - 1].append(r)
            } else {
                rows.append([r])
                rowLimit = r.rect.minY + r.rect.height * 0.6
            }
        }
        return rows.flatMap { row in
            row.sorted { rightToLeft ? $0.rect.midX > $1.rect.midX : $0.rect.midX < $1.rect.midX }
        }
    }
}
