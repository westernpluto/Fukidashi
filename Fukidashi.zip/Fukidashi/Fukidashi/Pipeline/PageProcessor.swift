import CoreGraphics
import Foundation

/// One translated piece of text on a page (saved so the reader can show the script).
struct ScriptLine: Codable, Identifiable {
    var id: Int
    var kind: String
    var source: String
    var english: String
    var rect: CGRect
}

struct PageScript: Codable {
    var lines: [ScriptLine]
    var note: String?
}

enum ProcessingError: LocalizedError {
    case unreadable
    var errorDescription: String? { "This page's image couldn't be opened." }
}

/// A piece of text to translate: a speech bubble or a caption over the art.
struct TextRegion {
    enum Kind: String { case bubble, caption }
    var kind: Kind
    var bubble: BubbleCandidate?
    /// Bounds used for reading order and caption lettering (page pixels).
    var rect: CGRect
    var glyph: CGFloat
    var source: String
}

/// The full on-device pipeline for one page:
/// find text → read it → translate with context → erase → letter English.
enum PageProcessor {
    static func process(input: URL, output: URL, scriptURL: URL, context: [String],
                        options: TranslationOptions) async throws -> PageScript {
        guard let image = ImageFiles.load(input), let canvas = PixelCanvas(image: image) else {
            throw ProcessingError.unreadable
        }
        let w = canvas.width, h = canvas.height
        let gray = canvas.grayscale()
        let lang = options.source

        // 1. Find text.
        let bubbles = BubbleDetector.detect(gray: gray, width: w, height: h)
        let observations = PageOCR.recognizeLines(in: image, language: lang)

        // 2. Read each bubble (Live Text handles vertical text), confirm it's really text.
        var regions: [TextRegion] = []
        for bubble in bubbles {
            var text = ""
            if let crop = OCRCrop.make(for: bubble, gray: gray, width: w, height: h) {
                let raw = await LiveTextReader.shared.read(crop, language: lang)
                text = normalize(raw, language: lang)
            }
            if lang.scriptCount(text) == 0 {
                // Horizontal text: use Vision's lines that fall inside this bubble.
                let inside = observations
                    .filter { bubble.filled.contains(Int($0.rect.midX), Int($0.rect.midY)) && $0.confidence >= 0.3 }
                    .sorted { $0.rect.minY < $1.rect.minY }
                let joined = normalize(inside.map(\.text).joined(separator: "\n"), language: lang)
                if lang.scriptCount(joined) > 0 { text = joined }
            }
            let isText = lang.scriptCount(text) > 0
                || (Localizer.punctuationOnly(text, language: lang) != nil && bubble.textRect.height < bubble.glyph * 4)
            guard isText else { continue }
            regions.append(TextRegion(kind: .bubble, bubble: bubble, rect: bubble.filled.frame,
                                      glyph: bubble.glyph, source: text))
        }

        // 3. Captions and text drawn over the art (horizontal lines Vision read).
        if options.translateOutsideBubbles {
            let free = observations.filter { obs in
                obs.confidence >= 0.35 && lang.scriptCount(obs.text) >= 2 && obs.rect.width >= obs.rect.height * 0.8
                    && !bubbles.contains { $0.filled.frame.insetBy(dx: -4, dy: -4).contains(CGPoint(x: obs.rect.midX, y: obs.rect.midY)) }
            }
            regions += groupCaptions(free, language: lang)
        }

        guard !regions.isEmpty else {
            if let out = canvas.makeImage() { ImageFiles.writeJPEG(out, to: output) }
            let script = PageScript(lines: [], note: "No text found on this page.")
            try? JSONEncoder().encode(script).write(to: scriptURL)
            return script
        }

        // 4. Translate the page as a whole, in reading order.
        regions = ReadingOrder.sort(regions, rightToLeft: lang == .japanese)
        let result = try await Localizer.translate(regions.map(\.source), context: context, options: options)

        // 5. Erase and letter.
        var script: [ScriptLine] = []
        for (i, region) in regions.enumerated() {
            guard let english = result.lines[i], !english.isEmpty else { continue }
            switch region.kind {
            case .bubble:
                guard let bubble = region.bubble else { continue }
                let background = Cleaner.backgroundColor(of: bubble, canvas: canvas)
                Cleaner.clean(bubble: bubble, color: background, canvas: canvas)
                let plan = Letterer.plan(text: english, area: bubble.filled, glyph: bubble.glyph,
                                         pageWidth: w, allCaps: options.allCaps)
                let ink: RGB = background.luma > 128 ? .black : .white
                Letterer.draw(plan, on: canvas, color: ink, halo: nil)
            case .caption:
                let background = Cleaner.inpaint(rect: region.rect, canvas: canvas)
                let grow = region.glyph * 0.6
                let box = region.rect.insetBy(dx: -grow, dy: -grow * 0.5)
                    .intersection(CGRect(x: 0, y: 0, width: w, height: h))
                guard !box.isNull, box.width >= 4, box.height >= 4 else { continue }
                let area = LocalMask(x0: Int(box.minX), y0: Int(box.minY),
                                     width: max(1, Int(box.width)), height: max(1, Int(box.height)), fill: true)
                let plan = Letterer.plan(text: english, area: area, glyph: region.glyph, pageWidth: w,
                                         allCaps: options.allCaps, padding: 1)
                let darkBackground = background.luma < 110
                Letterer.draw(plan, on: canvas, color: darkBackground ? .white : .black,
                              halo: darkBackground ? .black : .white)
            }
            script.append(ScriptLine(id: i, kind: region.kind.rawValue, source: region.source,
                                     english: english, rect: region.rect))
        }

        guard let out = canvas.makeImage() else { throw ProcessingError.unreadable }
        ImageFiles.writeJPEG(out, to: output)
        let pageScript = PageScript(lines: script, note: result.note)
        try? JSONEncoder().encode(pageScript).write(to: scriptURL)
        return pageScript
    }

    static func normalize(_ text: String, language: SourceLanguage) -> String {
        let pieces = text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        if language.joinsLinesWithSpace {
            return pieces.joined(separator: " ")
        }
        return pieces.joined().replacingOccurrences(of: " ", with: "")
    }

    /// Merges stacked caption lines into one region.
    static func groupCaptions(_ obs: [PageTextObservation], language: SourceLanguage) -> [TextRegion] {
        var groups: [[PageTextObservation]] = []
        for o in obs.sorted(by: { $0.rect.minY < $1.rect.minY }) {
            if let gi = groups.firstIndex(where: { group in
                guard let last = group.last else { return false }
                let gap = o.rect.minY - last.rect.maxY
                let overlap = min(o.rect.maxX, last.rect.maxX) - max(o.rect.minX, last.rect.minX)
                return gap < last.rect.height * 0.8 && gap > -last.rect.height * 0.5 && overlap > 0
            }) {
                groups[gi].append(o)
            } else {
                groups.append([o])
            }
        }
        return groups.map { group in
            let rect = group.dropFirst().reduce(group[0].rect) { $0.union($1.rect) }
            let heights = group.map(\.rect.height).sorted()
            let glyph = max(8, heights[heights.count / 2] * 0.95)
            let text = normalize(group.map(\.text).joined(separator: "\n"), language: language)
            return TextRegion(kind: .caption, bubble: nil, rect: rect, glyph: glyph, source: text)
        }
    }
}

enum ReadingOrder {
    /// Rows from top to bottom; within a row, right to left for manga.
    static func sort(_ regions: [TextRegion], rightToLeft: Bool) -> [TextRegion] {
        let byTop = regions.sorted { $0.rect.minY < $1.rect.minY }
        var rows: [[TextRegion]] = []
        var rowLimit: CGFloat = -.greatestFiniteMagnitude
        for r in byTop {
            if !rows.isEmpty && r.rect.minY < rowLimit {
                rows[rows.count - 1].append(r)
            } else {
                rows.append([r])
                rowLimit = r.rect.minY + r.rect.height * 0.6
            }
        }
        return rows.flatMap { row in
            row.sorted { rightToLeft ? $0.rect.midX > $1.rect.midX : $0.rect.midX < $1.rect.midX }
        }
    }
}
