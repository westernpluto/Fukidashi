import CoreGraphics
import Foundation
import UIKit
import Vision
import VisionKit

/// A line of text found by Vision on the whole page (horizontal text only).
struct PageTextObservation {
    let text: String
    /// Page pixels, top-left origin.
    let rect: CGRect
    let confidence: Float
}

enum PageOCR {
    /// Vision's text recognizer: good for horizontal text (manhwa, captions,
    /// signs). It does not read vertical Japanese, which Live Text handles below.
    static func recognizeLines(in image: CGImage, language: SourceLanguage) -> [PageTextObservation] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.recognitionLanguages = [language.visionCode]
        request.minimumTextHeight = 0.006
        let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
        do { try handler.perform([request]) } catch { return [] }
        guard let results = request.results else { return [] }
        let w = CGFloat(image.width), h = CGFloat(image.height)
        return results.compactMap { observation -> PageTextObservation? in
            guard let candidate = observation.topCandidates(1).first else { return nil }
            let b = observation.boundingBox
            let rect = CGRect(x: b.minX * w, y: (1 - b.maxY) * h, width: b.width * w, height: b.height * h)
            return PageTextObservation(text: candidate.string, rect: rect, confidence: candidate.confidence)
        }
    }
}

/// Live Text (VisionKit) reads vertical Japanese/Chinese correctly, so each
/// bubble is cropped, cleaned up and read on its own.
@MainActor
final class LiveTextReader {
    static let shared = LiveTextReader()
    private let analyzer = ImageAnalyzer()

    func read(_ image: CGImage, language: SourceLanguage) async -> String {
        guard ImageAnalyzer.isSupported else { return "" }
        var configuration = ImageAnalyzer.Configuration([.text])
        configuration.locales = [language.visionCode]
        do {
            let analysis = try await analyzer.analyze(UIImage(cgImage: image), configuration: configuration)
            return analysis.transcript
        } catch {
            return ""
        }
    }
}

enum OCRCrop {
    /// Grayscale crop of a bubble's lettering: everything outside the bubble is
    /// blanked, dark bubbles are inverted, and small text is upscaled.
    static func make(for bubble: BubbleCandidate, gray: [UInt8], width: Int, height: Int) -> CGImage? {
        let margin = Int(max(8, bubble.glyph * 0.8))
        let x0 = max(0, Int(bubble.textRect.minX) - margin)
        let y0 = max(0, Int(bubble.textRect.minY) - margin)
        let x1 = min(width - 1, Int(bubble.textRect.maxX) + margin)
        let y1 = min(height - 1, Int(bubble.textRect.maxY) + margin)
        let cw = x1 - x0 + 1, ch = y1 - y0 + 1
        guard cw > 4, ch > 4 else { return nil }
        var buffer = [UInt8](repeating: 255, count: cw * ch)
        for y in 0..<ch {
            for x in 0..<cw {
                let gx = x0 + x, gy = y0 + y
                guard bubble.filled.contains(gx, gy) else { continue }
                let v = gray[gy * width + gx]
                buffer[y * cw + x] = bubble.isDark ? 255 - v : v
            }
        }
        guard let image = grayImage(buffer, width: cw, height: ch) else { return nil }
        let scale = bubble.glyph < 40 ? min(3.0, 46.0 / Double(max(bubble.glyph, 8))) : 1.0
        guard scale > 1.05 else { return image }
        return upscale(image, by: scale)
    }

    static func grayImage(_ buffer: [UInt8], width: Int, height: Int) -> CGImage? {
        guard let provider = CGDataProvider(data: Data(buffer) as CFData) else { return nil }
        return CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 8,
                       bytesPerRow: width, space: CGColorSpaceCreateDeviceGray(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
    }

    static func upscale(_ image: CGImage, by scale: Double) -> CGImage? {
        let w = Int(Double(image.width) * scale), h = Int(Double(image.height) * scale)
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpaceCreateDeviceGray(),
                                  bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return image }
        ctx.interpolationQuality = .high
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
        return ctx.makeImage() ?? image
    }
}
