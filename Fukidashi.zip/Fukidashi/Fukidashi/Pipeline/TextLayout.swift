import CoreGraphics
import Foundation

/// Reads the structure of the lettering inside a bubble: furigana, separate
/// text groups (joined balloons) and the balloon's outline shape.
enum TextLayout {
    typealias Component = BubbleDetector.Component

    private static func glyphSize(_ comps: [Component]) -> Double? {
        let sizes = comps.map { max($0.width, $0.height) }.filter { $0 >= 3 }.sorted()
        guard sizes.count >= 4 else { return nil }
        return Double(sizes[Int(0.85 * Double(sizes.count - 1))])
    }

    private static func merge(_ spans: [(Int, Int)], gap: Double) -> [(Int, Int)] {
        var out: [(Int, Int)] = []
        for span in spans.sorted(by: { $0.0 < $1.0 }) {
            if let last = out.last, Double(span.0) <= Double(last.1) + gap {
                out[out.count - 1].1 = max(last.1, span.1)
            } else {
                out.append(span)
            }
        }
        return out
    }

    private static func median(_ v: [Int]) -> Double {
        guard !v.isEmpty else { return 0 }
        return Double(v.sorted()[v.count / 2])
    }

    // MARK: Furigana

    /// Furigana are small marks beside the main text: in vertical text they sit
    /// outside every main column, in a thin column just to its right; in
    /// horizontal text, above a row. Removing them keeps OCR from mixing the
    /// reading hints (いろいろ) into the text (色々).
    static func rubyIDs(comps: [Component]) -> Set<Int32> {
        guard let g = glyphSize(comps), g >= 12 else { return [] }
        let big = comps.filter { Double(max($0.width, $0.height)) >= 0.62 * g }
        guard big.count >= 2 else { return [] }
        let cols = merge(big.map { ($0.minX, $0.maxX + 1) }, gap: 0.08 * g)
        let rows = merge(big.map { ($0.minY, $0.maxY + 1) }, gap: 0.08 * g)
        let colWidth = median(cols.map { $0.1 - $0.0 })
        let rowHeight = median(rows.map { $0.1 - $0.0 })
        let spanY = Double((big.map(\.maxY).max() ?? 0) - (big.map(\.minY).min() ?? 0))
        let vertical = colWidth <= 1.7 * g && (cols.count >= 2 || spanY > 2 * g)
        guard vertical || rowHeight <= 1.7 * g else { return [] }

        let tolerance = 0.06 * g
        var candidates: [Component] = []
        for c in comps {
            let size = Double(max(c.width, c.height))
            guard size < 0.62 * g, size >= 2 else { continue }
            if vertical {
                let cx = Double(c.minX + c.maxX + 1) / 2
                let inside = cols.contains { Double($0.0) - tolerance <= cx && cx <= Double($0.1) + tolerance }
                let besideColumn = cols.contains { col in
                    let gap = Double(c.minX - col.1)
                    return gap >= 0 && gap <= 0.75 * g
                }
                if !inside && besideColumn { candidates.append(c) }
            } else {
                let cy = Double(c.minY + c.maxY + 1) / 2
                let inside = rows.contains { Double($0.0) - tolerance <= cy && cy <= Double($0.1) + tolerance }
                let aboveRow = rows.contains { row in
                    let gap = Double(row.0 - (c.maxY + 1))
                    return gap >= 0 && gap <= 0.75 * g
                }
                if !inside && aboveRow { candidates.append(c) }
            }
        }
        // Furigana come in runs of thin-stroked kana. A lone mark must look like
        // one (not a solid dot such as a stray handakuten).
        var ids: Set<Int32> = []
        for c in candidates {
            let cx = Double(c.minX + c.maxX) / 2, cy = Double(c.minY + c.maxY) / 2
            let hasMate = candidates.contains { d in
                guard d.id != c.id else { return false }
                let dx = abs(Double(d.minX + d.maxX) / 2 - cx), dy = abs(Double(d.minY + d.maxY) / 2 - cy)
                return vertical ? (dx < 0.4 * g && dy < 1.6 * g) : (dy < 0.4 * g && dx < 1.6 * g)
            }
            let size = Double(max(c.width, c.height))
            let fill = Double(c.area) / Double(c.width * c.height)
            if hasMate || (size >= 0.3 * g && fill <= 0.55) { ids.insert(c.id) }
        }
        return ids
    }

    // MARK: Joined balloons

    /// Splits vertical text into groups that sit apart (one per lobe of a joined
    /// balloon). Each group gets the share of the interior closest to it.
    static func parts(comps: [Component], filled: [Bool], width w: Int, height h: Int,
                      x0: Int, y0: Int) -> [BubblePart] {
        guard let g = glyphSize(comps), g >= 12 else { return [] }
        let big = comps.filter { Double(max($0.width, $0.height)) >= 0.5 * g }
        guard big.count >= 6 else { return [] }

        struct Box { var minX, minY, maxX, maxY: Int; var count: Int }
        // Columns: big marks that overlap horizontally and follow on vertically.
        var cols: [Box] = []
        for c in big.sorted(by: { $0.minX < $1.minX }) {
            if let i = cols.indices.last, Double(c.minX) <= Double(cols[i].maxX) + 0.1 * g,
               !(Double(c.minY) > Double(cols[i].maxY) + 2.5 * g || Double(c.maxY) < Double(cols[i].minY) - 2.5 * g) {
                cols[i].minX = min(cols[i].minX, c.minX); cols[i].maxX = max(cols[i].maxX, c.maxX)
                cols[i].minY = min(cols[i].minY, c.minY); cols[i].maxY = max(cols[i].maxY, c.maxY)
                cols[i].count += 1
            } else {
                cols.append(Box(minX: c.minX, minY: c.minY, maxX: c.maxX, maxY: c.maxY, count: 1))
            }
        }
        func joinable(_ a: Box, _ b: Box) -> Bool {
            let gapX = Double(max(b.minX - a.maxX, a.minX - b.maxX))
            let gapY = Double(max(b.minY - a.maxY, a.minY - b.maxY))
            if gapX <= 0 && gapY <= 0 { return true }
            let overlap = Double(min(a.maxY, b.maxY) - max(a.minY, b.minY))
            let shorter = Double(min(a.maxY - a.minY, b.maxY - b.minY))
            return (gapX <= 1.3 * g && overlap >= 0.2 * shorter) || (gapY <= 0.6 * g && gapX <= 0)
        }
        var groups = cols
        var changed = true
        while changed {
            changed = false
            outer: for i in groups.indices {
                for j in groups.indices where j > i && joinable(groups[i], groups[j]) {
                    let a = groups[i], b = groups[j]
                    groups[i] = Box(minX: min(a.minX, b.minX), minY: min(a.minY, b.minY),
                                    maxX: max(a.maxX, b.maxX), maxY: max(a.maxY, b.maxY), count: a.count + b.count)
                    groups.remove(at: j)
                    changed = true
                    break outer
                }
            }
        }
        let real = groups.filter { box in
            box.count >= 3 && Double(max(box.maxX - box.minX, box.maxY - box.minY)) >= 1.5 * g
        }
        // Only split vertical text, where every group is a set of columns.
        guard real.count >= 2, real.count <= 4,
              real.allSatisfy({ ($0.maxY - $0.minY) > ($0.maxX - $0.minX) }) else { return [] }

        // Each interior pixel goes to the nearest group.
        var owner = [Int8](repeating: -1, count: w * h)
        for y in 0..<h {
            for x in 0..<w where filled[y * w + x] {
                var best = Double.greatestFiniteMagnitude, bestIndex = 0
                for (k, box) in real.enumerated() {
                    let dx = Double(max(0, max(box.minX - x, x - box.maxX)))
                    let dy = Double(max(0, max(box.minY - y, y - box.maxY)))
                    let d = dx * dx + dy * dy
                    if d < best { best = d; bestIndex = k }
                }
                owner[y * w + x] = Int8(bestIndex)
            }
        }
        var result: [BubblePart] = []
        for (k, box) in real.enumerated() {
            var minX = Int.max, minY = Int.max, maxX = -1, maxY = -1
            for y in 0..<h {
                for x in 0..<w where owner[y * w + x] == Int8(k) {
                    minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
                }
            }
            guard maxX >= minX, maxY >= minY else { return [] }
            let pw = maxX - minX + 1, ph = maxY - minY + 1
            var bits = [Bool](repeating: false, count: pw * ph)
            for y in 0..<ph {
                for x in 0..<pw where owner[(minY + y) * w + minX + x] == Int8(k) { bits[y * pw + x] = true }
            }
            result.append(BubblePart(
                textRect: CGRect(x: x0 + box.minX, y: y0 + box.minY,
                                 width: box.maxX - box.minX + 1, height: box.maxY - box.minY + 1),
                area: LocalMask(x0: x0 + minX, y0: y0 + minY, width: pw, height: ph, bits: bits)))
        }
        return result
    }

    // MARK: Outline shape

    /// Area / convex-hull area. Ovals and boxes score about 0.95–1; spiky burst
    /// balloons fall well below.
    static func solidity(_ filled: [Bool], width w: Int, height h: Int) -> Double {
        var points: [(Double, Double)] = []
        var area = 0
        for y in 0..<h {
            var first = -1, last = -1
            for x in 0..<w where filled[y * w + x] {
                if first < 0 { first = x }
                last = x
                area += 1
            }
            if first >= 0 {
                points.append((Double(first), Double(y)))
                points.append((Double(last + 1), Double(y)))
            }
        }
        guard points.count >= 3, area > 0 else { return 1 }
        points.sort { $0.0 == $1.0 ? $0.1 < $1.1 : $0.0 < $1.0 }
        func cross(_ o: (Double, Double), _ a: (Double, Double), _ b: (Double, Double)) -> Double {
            (a.0 - o.0) * (b.1 - o.1) - (a.1 - o.1) * (b.0 - o.0)
        }
        var lower: [(Double, Double)] = []
        for p in points {
            while lower.count >= 2 && cross(lower[lower.count - 2], lower[lower.count - 1], p) <= 0 { lower.removeLast() }
            lower.append(p)
        }
        var upper: [(Double, Double)] = []
        for p in points.reversed() {
            while upper.count >= 2 && cross(upper[upper.count - 2], upper[upper.count - 1], p) <= 0 { upper.removeLast() }
            upper.append(p)
        }
        let hull = Array(lower.dropLast()) + Array(upper.dropLast())
        var hullArea = 0.0
        for i in hull.indices {
            let a = hull[i], b = hull[(i + 1) % hull.count]
            hullArea += a.0 * b.1 - b.0 * a.1
        }
        hullArea = abs(hullArea) / 2
        return hullArea > 0 ? min(1.05, Double(area) / hullArea) : 1
    }
}
