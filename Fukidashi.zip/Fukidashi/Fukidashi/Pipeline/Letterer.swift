import CoreGraphics
import CoreText
import Foundation

/// A lettering typeface. `condense` narrows it horizontally, as letterers do
/// with comic fonts so more fits across a narrow balloon.
struct LetterFont: Sendable, Equatable {
    var name: String
    var condense: CGFloat
    var lineFactor: CGFloat

    /// Default dialogue font: hand-lettered, bold italic (Wild Words style).
    static let mali = LetterFont(name: "Mali-BoldItalic", condense: 0.88, lineFactor: 1.0)
    static let comicNeue = LetterFont(name: "ComicNeue-Bold", condense: 1.0, lineFactor: 1.08)
    /// Heavy display font for sound effects and burst balloons.
    static let sfx = LetterFont(name: "Bangers-Regular", condense: 1.0, lineFactor: 1.0)

    func ctFont(size: CGFloat) -> CTFont { CTFontCreateWithName(name as CFString, size, nil) }
}

/// How a translated line will be lettered into its bubble.
struct LetteringPlan {
    enum Alignment { case center, left(CGFloat), right(CGFloat) }
    var lines: [String]
    var fontSize: CGFloat
    /// Centre of the text block, page pixels (top-left origin).
    var center: CGPoint
    var lineHeight: CGFloat
    var alignment: Alignment = .center
    var font: LetterFont = .mali
}

/// Shape-aware lettering: lines follow the outline of the bubble (short lines
/// at the narrow top and bottom of an oval, longer ones through the middle),
/// centred, balanced, at the largest size that fits — the way a human
/// letterer fills a balloon.
enum Letterer {
    /// Width of a string as it will be drawn (condensing included).
    static func width(_ s: String, font: CTFont, condense: CGFloat = 1) -> CGFloat {
        let attr = NSAttributedString(string: s, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font])
        return CGFloat(CTLineGetTypographicBounds(CTLineCreateWithAttributedString(attr), nil, nil, nil)) * condense
    }

    static func plan(text: String, area: LocalMask, glyph: CGFloat, pageWidth: Int, allCaps: Bool,
                     padding: CGFloat? = nil, maxScale: CGFloat = 1.15, maxSize: CGFloat? = nil,
                     minSize: CGFloat? = nil, alignment: LetteringPlan.Alignment = .center,
                     font: LetterFont = .mali) -> LetteringPlan {
        var result = layout(text: text, area: area, glyph: glyph, pageWidth: pageWidth, allCaps: allCaps,
                            padding: padding, maxScale: maxScale, maxSize: maxSize, minSize: minSize, letterFont: font)
        result.alignment = alignment
        result.font = font
        return result
    }

    private static func layout(text: String, area: LocalMask, glyph: CGFloat, pageWidth: Int, allCaps: Bool,
                               padding: CGFloat?, maxScale: CGFloat, maxSize capSize: CGFloat?,
                               minSize floorRequest: CGFloat?, letterFont: LetterFont) -> LetteringPlan {
        func font(size: CGFloat) -> CTFont { letterFont.ctFont(size: size) }
        let condense = letterFont.condense
        let content = allCaps ? text.uppercased() : text
        let words = content.split(whereSeparator: { $0 == " " || $0 == "\n" }).map(String.init)
        let w = area.width, h = area.height
        let dist = distanceTransform(area)
        let maxDist = dist.max() ?? 0

        // Visual centre: centroid of the bubble's "core" (ignores tails and spikes).
        var sx: Double = 0, sy: Double = 0, n: Double = 0
        for y in 0..<h {
            for x in 0..<w where dist[y * w + x] >= maxDist * 0.5 && maxDist > 0 {
                sx += Double(x); sy += Double(y); n += 1
            }
        }
        let cx = n > 0 ? CGFloat(sx / n) : CGFloat(w) / 2
        let cy = n > 0 ? CGFloat(sy / n) : CGFloat(h) / 2
        let pad = padding ?? max(2, 0.07 * CGFloat(min(w, h)))
        let available = dist.map { CGFloat($0) >= pad }
        let globalCenter = CGPoint(x: CGFloat(area.x0) + cx, y: CGFloat(area.y0) + cy)
        let lineFactor: CGFloat = letterFont.lineFactor + (allCaps ? 0 : 0.12)

        guard !words.isEmpty else {
            return LetteringPlan(lines: [], fontSize: glyph, center: globalCenter, lineHeight: glyph)
        }

        let minSize = floorRequest ?? max(glyph * 0.5, CGFloat(pageWidth) * 0.012, 7)
        let maxSize = min(glyph * maxScale, capSize ?? .greatestFiniteMagnitude)
        var size = max(maxSize, minSize)
        while size >= minSize {
            if let lines = fit(words: words, size: size, lineFactor: lineFactor, available: available,
                               w: w, h: h, cx: cx, cy: cy, font: letterFont) {
                return LetteringPlan(lines: lines, fontSize: size, center: globalCenter, lineHeight: size * lineFactor)
            }
            size *= 0.95
        }

        // Too long for that size: go smaller before breaking any word.
        let floorSize = max(glyph * 0.32, CGFloat(pageWidth) * 0.011, 7)
        while size >= floorSize {
            if let lines = fit(words: words, size: size, lineFactor: lineFactor, available: available,
                               w: w, h: h, cx: cx, cy: cy, font: letterFont) {
                return LetteringPlan(lines: lines, fontSize: size, center: globalCenter, lineHeight: size * lineFactor)
            }
            size *= 0.95
        }

        // Still too long: hyphenate only genuinely long words.
        let f = font(size: floorSize)
        let widest = widestLine(available: available, w: w, h: h, cx: cx, cy: cy)
        let split = words.flatMap {
            $0.count >= 9 ? hyphenate($0, maxWidth: max(widest * 0.95, floorSize * 2), font: f, condense: condense) : [$0]
        }
        if let lines = fit(words: split, size: floorSize, lineFactor: lineFactor, available: available,
                           w: w, h: h, cx: cx, cy: cy, font: letterFont) {
            return LetteringPlan(lines: lines, fontSize: floorSize, center: globalCenter, lineHeight: floorSize * lineFactor)
        }

        // Last resort: wrap to the bubble's width and let it overflow slightly.
        let lines = greedyWrap(split, maxWidth: CGFloat(w) * 0.85, font: f, condense: condense)
        return LetteringPlan(lines: lines, fontSize: floorSize, center: globalCenter, lineHeight: floorSize * lineFactor)
    }

    // MARK: Fitting

    private static func fit(words: [String], size: CGFloat, lineFactor: CGFloat, available: [Bool],
                            w: Int, h: Int, cx: CGFloat, cy: CGFloat, font letterFont: LetterFont) -> [String]? {
        let f = letterFont.ctFont(size: size)
        let lh = size * lineFactor
        let space = width(" ", font: f, condense: letterFont.condense)
        let widths = words.map { width($0, font: f, condense: letterFont.condense) }
        let maxLines = Int(CGFloat(h) / lh)
        guard maxLines >= 1 else { return nil }

        for count in 1...maxLines {
            guard let lineWidths = lineWidths(count: count, lineHeight: lh, available: available,
                                              w: w, h: h, cx: cx, cy: cy) else { continue }
            guard wrap(widths, space: space, limits: lineWidths, scale: 1) != nil else { continue }
            // Balance: shrink the measure until one more squeeze would add a line.
            var lo: CGFloat = 0.5, hi: CGFloat = 1
            for _ in 0..<10 {
                let mid = (lo + hi) / 2
                if wrap(widths, space: space, limits: lineWidths, scale: mid) != nil { hi = mid } else { lo = mid }
            }
            guard let breaks = wrap(widths, space: space, limits: lineWidths, scale: hi) else { continue }
            return breaks.map { range in words[range].joined(separator: " ") }
        }
        return nil
    }

    /// Usable width of each line of a block of `count` lines centred on (cx, cy),
    /// symmetric about cx so lines share one axis.
    private static func lineWidths(count: Int, lineHeight: CGFloat, available: [Bool],
                                   w: Int, h: Int, cx: CGFloat, cy: CGFloat) -> [CGFloat]? {
        let top = cy - CGFloat(count) * lineHeight / 2
        let ix = Int(cx)
        guard ix >= 0, ix < w else { return nil }
        var result: [CGFloat] = []
        for i in 0..<count {
            let ya = Int(top + CGFloat(i) * lineHeight)
            let yb = Int(top + CGFloat(i + 1) * lineHeight)
            guard ya >= 0, yb < h else { return nil }
            var half = CGFloat.greatestFiniteMagnitude
            for y in ya...yb {
                guard available[y * w + ix] else { return nil }
                var l = ix, r = ix
                while l > 0 && available[y * w + l - 1] { l -= 1 }
                while r < w - 1 && available[y * w + r + 1] { r += 1 }
                half = min(half, cx - CGFloat(l), CGFloat(r) - cx)
            }
            result.append(max(0, half * 2))
        }
        return result
    }

    private static func widestLine(available: [Bool], w: Int, h: Int, cx: CGFloat, cy: CGFloat) -> CGFloat {
        let y = max(0, min(h - 1, Int(cy))), ix = max(0, min(w - 1, Int(cx)))
        guard available[y * w + ix] else { return CGFloat(w) * 0.8 }
        var l = ix, r = ix
        while l > 0 && available[y * w + l - 1] { l -= 1 }
        while r < w - 1 && available[y * w + r + 1] { r += 1 }
        return CGFloat(r - l)
    }

    /// Greedy line breaking into exactly `limits.count` lines or fewer.
    /// Returns word ranges per line, or nil if the words don't fit.
    private static func wrap(_ widths: [CGFloat], space: CGFloat, limits: [CGFloat], scale: CGFloat) -> [Range<Int>]? {
        var lines: [Range<Int>] = []
        var start = 0, current: CGFloat = 0, line = 0
        for (i, wd) in widths.enumerated() {
            guard line < limits.count else { return nil }
            let limit = limits[line] * scale
            if i == start {
                if wd > limit {
                    // Word doesn't fit this line on its own; try the next line (it may be wider).
                    return nil
                }
                current = wd
            } else if current + space + wd <= limit {
                current += space + wd
            } else {
                lines.append(start..<i)
                line += 1
                start = i
                guard line < limits.count, wd <= limits[line] * scale else { return nil }
                current = wd
            }
        }
        lines.append(start..<widths.count)
        return lines.count <= limits.count ? lines : nil
    }

    private static func greedyWrap(_ words: [String], maxWidth: CGFloat, font: CTFont, condense: CGFloat) -> [String] {
        var lines: [String] = []
        var current = ""
        for word in words {
            let candidate = current.isEmpty ? word : current + " " + word
            if width(candidate, font: font, condense: condense) <= maxWidth || current.isEmpty {
                current = candidate
            } else {
                lines.append(current)
                current = word
            }
        }
        if !current.isEmpty { lines.append(current) }
        return lines
    }

    private static func hyphenate(_ word: String, maxWidth: CGFloat, font: CTFont, condense: CGFloat) -> [String] {
        guard width(word, font: font, condense: condense) > maxWidth, word.count > 3 else { return [word] }
        var parts: [String] = []
        var current = ""
        for ch in word {
            let candidate = current + String(ch) + "-"
            if width(candidate, font: font, condense: condense) > maxWidth && current.count >= 2 {
                parts.append(current + "-")
                current = String(ch)
            } else {
                current.append(ch)
            }
        }
        if !current.isEmpty { parts.append(current) }
        return parts
    }

    // MARK: Distance transform

    /// Chamfer (3-4) distance to the nearest pixel outside the area, in pixels.
    static func distanceTransform(_ m: LocalMask) -> [Float] {
        let w = m.width + 2, h = m.height + 2
        let inf: Int32 = 1 << 28
        var d = [Int32](repeating: 0, count: w * h)
        for y in 0..<m.height {
            for x in 0..<m.width where m.bits[y * m.width + x] { d[(y + 1) * w + x + 1] = inf }
        }
        for y in 1..<(h - 1) {
            for x in 1..<(w - 1) {
                let i = y * w + x
                guard d[i] != 0 else { continue }
                var v = d[i]
                v = min(v, d[i - 1] + 3)
                v = min(v, d[i - w] + 3)
                v = min(v, d[i - w - 1] + 4)
                v = min(v, d[i - w + 1] + 4)
                d[i] = v
            }
        }
        for y in stride(from: h - 2, through: 1, by: -1) {
            for x in stride(from: w - 2, through: 1, by: -1) {
                let i = y * w + x
                guard d[i] != 0 else { continue }
                var v = d[i]
                v = min(v, d[i + 1] + 3)
                v = min(v, d[i + w] + 3)
                v = min(v, d[i + w + 1] + 4)
                v = min(v, d[i + w - 1] + 4)
                d[i] = v
            }
        }
        var out = [Float](repeating: 0, count: m.width * m.height)
        for y in 0..<m.height {
            for x in 0..<m.width { out[y * m.width + x] = Float(d[(y + 1) * w + x + 1]) / 3 }
        }
        return out
    }

    // MARK: Drawing

    /// Bounds of the lettered text, page pixels.
    static func bounds(of plan: LetteringPlan) -> CGRect {
        guard !plan.lines.isEmpty else { return CGRect(origin: plan.center, size: .zero) }
        let f = plan.font.ctFont(size: plan.fontSize)
        let widest = plan.lines.map { width($0, font: f, condense: plan.font.condense) }.max() ?? 0
        let height = CGFloat(plan.lines.count) * plan.lineHeight
        let minX: CGFloat
        switch plan.alignment {
        case .center: minX = plan.center.x - widest / 2
        case .left(let edge): minX = edge
        case .right(let edge): minX = edge - widest
        }
        return CGRect(x: minX, y: plan.center.y - height / 2, width: widest, height: height)
    }

    /// A soft white rounded panel behind text that sits over the art.
    static func drawPlate(_ rect: CGRect, on canvas: PixelCanvas) {
        let ctx = canvas.context
        let flipped = CGRect(x: rect.minX, y: CGFloat(canvas.height) - rect.maxY, width: rect.width, height: rect.height)
        let radius = min(16, min(rect.width, rect.height) / 4)
        ctx.saveGState()
        ctx.setShadow(offset: .zero, blur: 10, color: CGColor(red: 1, green: 1, blue: 1, alpha: 1))
        ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 0.96))
        ctx.addPath(CGPath(roundedRect: flipped, cornerWidth: radius, cornerHeight: radius, transform: nil))
        ctx.fillPath()
        ctx.restoreGState()
    }

    /// `haloWidth` is the outline's total width as a fraction of the font size
    /// (half of it falls outside the letters).
    static func draw(_ plan: LetteringPlan, on canvas: PixelCanvas, color: RGB, halo: RGB?, haloWidth: CGFloat = 0.48) {
        guard !plan.lines.isEmpty else { return }
        let ctx = canvas.context
        let f = plan.font.ctFont(size: plan.fontSize)
        let condense = plan.font.condense
        let capHeight = CTFontGetCapHeight(f)
        let top = plan.center.y - CGFloat(plan.lines.count) * plan.lineHeight / 2
        let fontKey = NSAttributedString.Key(kCTFontAttributeName as String)
        let colorKey = NSAttributedString.Key(kCTForegroundColorAttributeName as String)
        let strokeColorKey = NSAttributedString.Key(kCTStrokeColorAttributeName as String)
        let strokeWidthKey = NSAttributedString.Key(kCTStrokeWidthAttributeName as String)

        ctx.saveGState()
        // Condensing: the text matrix narrows glyphs and advances together.
        ctx.textMatrix = CGAffineTransform(a: condense, b: 0, c: 0, d: 1, tx: 0, ty: 0)
        ctx.setShouldAntialias(true)
        ctx.setLineJoin(.round)
        let pageWidth = CGFloat(canvas.width)
        for (i, text) in plan.lines.enumerated() {
            let lineWidth = width(text, font: f, condense: condense)
            let baselineFromTop = top + (CGFloat(i) + 0.5) * plan.lineHeight + capHeight / 2
            var x: CGFloat
            switch plan.alignment {
            case .center: x = plan.center.x - lineWidth / 2
            case .left(let edge): x = edge
            case .right(let edge): x = edge - lineWidth
            }
            x = max(4, min(x, pageWidth - lineWidth - 4))
            let position = CGPoint(x: x, y: CGFloat(canvas.height) - baselineFromTop)
            if let halo {
                let stroke = NSAttributedString(string: text, attributes: [
                    fontKey: f, strokeColorKey: halo.cgColor, strokeWidthKey: NSNumber(value: Double(haloWidth * 100))
                ])
                ctx.textPosition = position
                CTLineDraw(CTLineCreateWithAttributedString(stroke), ctx)
            }
            let fill = NSAttributedString(string: text, attributes: [fontKey: f, colorKey: color.cgColor])
            ctx.textPosition = position
            CTLineDraw(CTLineCreateWithAttributedString(fill), ctx)
        }
        ctx.restoreGState()
    }
}

enum FontRegistry {
    static func registerBundledFonts() {
        for name in ["Mali-BoldItalic", "Bangers-Regular", "ComicNeue-Bold", "ComicNeue-Regular", "ComicNeue-BoldItalic"] {
            guard let url = Bundle.main.url(forResource: name, withExtension: "ttf") else { continue }
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
        if let url = customFontURL { CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil) }
    }

    /// Folder for a lettering font the user imports (e.g. one they own).
    static var customFontsFolder: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Fonts", isDirectory: true)
    }

    static var customFontURL: URL? {
        guard let name = UserDefaults.standard.string(forKey: "customFontFile") else { return nil }
        let url = customFontsFolder.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    /// Copies a .ttf/.otf into the app, registers it and returns its PostScript name.
    static func importFont(from source: URL) throws -> String {
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(source as CFURL) as? [CTFontDescriptor],
              let first = descriptors.first,
              let name = CTFontDescriptorCopyAttribute(first, kCTFontNameAttribute) as? String
        else { throw CocoaError(.fileReadCorruptFile) }
        try FileManager.default.createDirectory(at: customFontsFolder, withIntermediateDirectories: true)
        if let old = customFontURL {
            CTFontManagerUnregisterFontsForURL(old as CFURL, .process, nil)
            try? FileManager.default.removeItem(at: old)
        }
        let destination = customFontsFolder.appendingPathComponent(source.lastPathComponent)
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.copyItem(at: source, to: destination)
        CTFontManagerRegisterFontsForURL(destination as CFURL, .process, nil)
        UserDefaults.standard.set(destination.lastPathComponent, forKey: "customFontFile")
        UserDefaults.standard.set(name, forKey: "customFontName")
        return name
    }
}
