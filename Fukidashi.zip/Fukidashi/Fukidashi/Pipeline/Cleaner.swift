import CoreGraphics
import Foundation

/// Removes the original lettering before the English is drawn.
enum Cleaner {
    struct Erased {
        /// Colour around the text.
        var background: RGB
        /// Art behind the text: the English goes on a soft plate instead of inpainting.
        var busy: Bool
    }

    /// The bubble's own background colour (median of its background pixels).
    static func backgroundColor(of bubble: BubbleCandidate, canvas: PixelCanvas) -> RGB {
        let m = bubble.component
        var samples: [RGB] = []
        let step = max(1, (m.width * m.height) / 4000)
        var i = 0
        while i < m.bits.count {
            if m.bits[i] {
                let y = i / m.width, x = i - y * m.width
                samples.append(canvas.rgb(m.x0 + x, m.y0 + y))
            }
            i += step
        }
        return RGB.median(samples)
    }

    /// Repaints the bubble interior (background + enclosed lettering) with the
    /// bubble colour, which also removes anti-aliasing fringes and JPEG noise.
    static func clean(bubble: BubbleCandidate, color: RGB, canvas: PixelCanvas) {
        let f = bubble.filled
        for y in 0..<f.height {
            for x in 0..<f.width where f.bits[y * f.width + x] {
                canvas.set(f.x0 + x, f.y0 + y, color)
            }
        }
    }

    /// Lettering outside bubbles, found as marks. On a plain background the
    /// marks and their outline are filled with the background colour; over art
    /// nothing is painted here and the caller covers the text with a plate.
    static func erase(marks: Set<Int32>, rect: CGRect, glyph: CGFloat, labels: [Int32], canvas: PixelCanvas) -> Erased {
        let outline = Int(max(2, min(8, glyph * 0.18)))
        let pad = outline + 3
        let x0 = max(0, Int(rect.minX) - pad), y0 = max(0, Int(rect.minY) - pad)
        let x1 = min(canvas.width - 1, Int(rect.maxX) + pad), y1 = min(canvas.height - 1, Int(rect.maxY) + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return Erased(background: .white, busy: false) }
        var bits = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            let row = (y0 + y) * canvas.width + x0
            for x in 0..<w where marks.contains(labels[row + x]) { bits[y * w + x] = true }
        }
        bits = dilate(bits, width: w, height: h, radius: outline)
        return flatFillIfPlain(LocalMask(x0: x0, y0: y0, width: w, height: h, bits: bits), canvas: canvas)
    }

    /// Samples the pixels just outside the mask. If they're a plain, light
    /// colour, paints the mask with it.
    static func flatFillIfPlain(_ mask: LocalMask, canvas: PixelCanvas) -> Erased {
        let w = mask.width, h = mask.height
        let ring = dilate(mask.bits, width: w, height: h, radius: 2)
        var samples: [RGB] = []
        var sum: Double = 0, sumSq: Double = 0
        for i in 0..<(w * h) where ring[i] && !mask.bits[i] {
            let y = i / w, x = i - y * w
            let c = canvas.rgb(mask.x0 + x, mask.y0 + y)
            samples.append(c)
            let l = Double(c.luma)
            sum += l; sumSq += l * l
        }
        guard !samples.isEmpty else { return Erased(background: .white, busy: true) }
        let n = Double(samples.count)
        let spread = (max(0, sumSq / n - (sum / n) * (sum / n))).squareRoot()
        let background = RGB.median(samples)
        let plain = spread <= 22 && background.luma >= 160
        if plain {
            for i in 0..<(w * h) where mask.bits[i] {
                let y = i / w, x = i - y * w
                canvas.set(mask.x0 + x, mask.y0 + y, background)
            }
        }
        return Erased(background: background, busy: !plain)
    }

    /// Text found by Vision as a rectangle: mask the strokes that stand out from
    /// the local background and fill them on a plain background.
    static func inpaint(rect: CGRect, canvas: PixelCanvas) -> Erased {
        let pad = 4
        let x0 = max(0, Int(rect.minX) - pad), y0 = max(0, Int(rect.minY) - pad)
        let x1 = min(canvas.width - 1, Int(rect.maxX) + pad), y1 = min(canvas.height - 1, Int(rect.maxY) + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return Erased(background: .white, busy: false) }

        var border: [RGB] = []
        for x in 0..<w { border.append(canvas.rgb(x0 + x, y0)); border.append(canvas.rgb(x0 + x, y1)) }
        for y in 0..<h { border.append(canvas.rgb(x0, y0 + y)); border.append(canvas.rgb(x1, y0 + y)) }
        let bgLuma = RGB.median(border).luma

        var bits = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            for x in 0..<w where abs(canvas.rgb(x0 + x, y0 + y).luma - bgLuma) > 48 {
                bits[y * w + x] = true
            }
        }
        bits = dilate(bits, width: w, height: h, radius: 2)
        return flatFillIfPlain(LocalMask(x0: x0, y0: y0, width: w, height: h, bits: bits), canvas: canvas)
    }

    /// Onion-peel fill: each pass fills masked pixels from their known neighbours.
    /// The mask's outer frame always stays as anchors. Returns the median colour
    /// of the anchor pixels next to the mask.
    @discardableResult
    static func fill(_ mask: LocalMask, canvas: PixelCanvas) -> RGB {
        let w = mask.width, h = mask.height
        var unknown = mask.bits
        for x in 0..<w { unknown[x] = false; unknown[(h - 1) * w + x] = false }
        for y in 0..<h { unknown[y * w] = false; unknown[y * w + w - 1] = false }

        var r = [Float](repeating: 0, count: w * h)
        var g = r, b = r
        var rim: [RGB] = []
        for y in 0..<h {
            for x in 0..<w {
                let c = canvas.rgb(mask.x0 + x, mask.y0 + y)
                let i = y * w + x
                r[i] = Float(c.r); g[i] = Float(c.g); b[i] = Float(c.b)
                if !unknown[i] && rim.count < 4000 {
                    let touches = (x > 0 && unknown[i - 1]) || (x < w - 1 && unknown[i + 1])
                        || (y > 0 && unknown[i - w]) || (y < h - 1 && unknown[i + w])
                    if touches { rim.append(c) }
                }
            }
        }
        let painted = unknown
        var passes = w + h
        while passes > 0 {
            passes -= 1
            var updates: [(Int, Float, Float, Float)] = []
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) where unknown[y * w + x] {
                    var sr: Float = 0, sg: Float = 0, sb: Float = 0, n: Float = 0
                    for dy in -1...1 {
                        for dx in -1...1 where !(dx == 0 && dy == 0) {
                            let j = (y + dy) * w + (x + dx)
                            if !unknown[j] { sr += r[j]; sg += g[j]; sb += b[j]; n += 1 }
                        }
                    }
                    if n > 0 { updates.append((y * w + x, sr / n, sg / n, sb / n)) }
                }
            }
            if updates.isEmpty { break }
            for (i, vr, vg, vb) in updates {
                r[i] = vr; g[i] = vg; b[i] = vb
                unknown[i] = false
            }
        }

        for y in 0..<h {
            for x in 0..<w where painted[y * w + x] {
                let i = y * w + x
                canvas.set(mask.x0 + x, mask.y0 + y, RGB(r: UInt8(max(0, min(255, r[i]))),
                                                         g: UInt8(max(0, min(255, g[i]))),
                                                         b: UInt8(max(0, min(255, b[i])))))
            }
        }
        return RGB.median(rim)
    }

    /// Square dilation in two separable passes.
    static func dilate(_ bits: [Bool], width w: Int, height h: Int, radius r: Int) -> [Bool] {
        guard r > 0 else { return bits }
        var tmp = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            var count = 0
            for x in 0..<min(r, w) where bits[y * w + x] { count += 1 }
            for x in 0..<w {
                let add = x + r
                if add < w && bits[y * w + add] { count += 1 }
                tmp[y * w + x] = count > 0
                let remove = x - r
                if remove >= 0 && bits[y * w + remove] { count -= 1 }
            }
        }
        var out = [Bool](repeating: false, count: w * h)
        for x in 0..<w {
            var count = 0
            for y in 0..<min(r, h) where tmp[y * w + x] { count += 1 }
            for y in 0..<h {
                let add = y + r
                if add < h && tmp[add * w + x] { count += 1 }
                out[y * w + x] = count > 0
                let remove = y - r
                if remove >= 0 && tmp[remove * w + x] { count -= 1 }
            }
        }
        return out
    }
}
