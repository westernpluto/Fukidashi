import CoreGraphics
import Foundation

/// Removes the original lettering before the English is drawn.
enum Cleaner {
    struct Erased {
        /// Colour around the text.
        var background: RGB
        /// The text sat on art rather than a plain background.
        var busy: Bool
    }

    /// The bubble's own background colour (median of its background pixels).
    static func backgroundColor(of bubble: BubbleCandidate, canvas: PixelCanvas) -> RGB {
        let m = bubble.component
        var samples: [RGB] = []
        let step = max(1, (m.width * m.height) / 4000)
        var i = 0
        while i < m.bits.count {
            if m.bits[i] {
                let y = i / m.width, x = i - y * m.width
                samples.append(canvas.rgb(m.x0 + x, m.y0 + y))
            }
            i += step
        }
        return RGB.median(samples)
    }

    /// Repaints the bubble interior (background + enclosed lettering) with the
    /// bubble colour, which also removes anti-aliasing fringes and JPEG noise.
    static func clean(bubble: BubbleCandidate, color: RGB, canvas: PixelCanvas) {
        let f = bubble.filled
        for y in 0..<f.height {
            for x in 0..<f.width where f.bits[y * f.width + x] {
                canvas.set(f.x0 + x, f.y0 + y, color)
            }
        }
    }

    /// Lettering outside bubbles, found as marks. On a plain background the marks
    /// and their outline are filled with the background colour. Over art, with
    /// `rebuild`, they're rebuilt from nearby texture (never copied from the
    /// `avoid` marks, i.e. other lettering) and softened with a light haze.
    static func erase(marks: Set<Int32>, avoid: Set<Int32>, rect: CGRect, glyph: CGFloat, labels: [Int32],
                      canvas: PixelCanvas, rebuild: Bool) -> Erased {
        let outline = Int(max(2, min(8, glyph * 0.18)))
        let pad = outline + 3
        let x0 = max(0, Int(rect.minX) - pad), y0 = max(0, Int(rect.minY) - pad)
        let x1 = min(canvas.width - 1, Int(rect.maxX) + pad), y1 = min(canvas.height - 1, Int(rect.maxY) + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return Erased(background: .white, busy: false) }
        var bits = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            let row = (y0 + y) * canvas.width + x0
            for x in 0..<w where marks.contains(labels[row + x]) { bits[y * w + x] = true }
        }
        bits = dilate(bits, width: w, height: h, radius: outline)
        let mask = LocalMask(x0: x0, y0: y0, width: w, height: h, bits: bits)
        let result = flatFillIfPlain(mask, canvas: canvas)
        if result.busy && rebuild {
            textureFill(mask, canvas: canvas, avoid: avoid, labels: labels, avoidRadius: outline + 1)
            haze(mask, glyph: glyph, canvas: canvas)
        }
        return result
    }

    /// Text found by Vision as a rectangle: mask the strokes that stand out from
    /// the local background, then fill them like `erase`.
    static func inpaint(rect: CGRect, canvas: PixelCanvas, rebuild: Bool) -> Erased {
        let pad = 4
        let x0 = max(0, Int(rect.minX) - pad), y0 = max(0, Int(rect.minY) - pad)
        let x1 = min(canvas.width - 1, Int(rect.maxX) + pad), y1 = min(canvas.height - 1, Int(rect.maxY) + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return Erased(background: .white, busy: false) }

        var border: [RGB] = []
        for x in 0..<w { border.append(canvas.rgb(x0 + x, y0)); border.append(canvas.rgb(x0 + x, y1)) }
        for y in 0..<h { border.append(canvas.rgb(x0, y0 + y)); border.append(canvas.rgb(x1, y0 + y)) }
        let bgLuma = RGB.median(border).luma

        var bits = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            for x in 0..<w where abs(canvas.rgb(x0 + x, y0 + y).luma - bgLuma) > 48 {
                bits[y * w + x] = true
            }
        }
        bits = dilate(bits, width: w, height: h, radius: 2)
        let mask = LocalMask(x0: x0, y0: y0, width: w, height: h, bits: bits)
        let result = flatFillIfPlain(mask, canvas: canvas)
        if result.busy && rebuild {
            textureFill(mask, canvas: canvas, avoid: [], labels: nil, avoidRadius: 0)
            haze(mask, glyph: rect.height, canvas: canvas)
        }
        return result
    }

    /// Samples the pixels just outside the mask. If they're a plain, light
    /// colour, paints the mask with it.
    static func flatFillIfPlain(_ mask: LocalMask, canvas: PixelCanvas) -> Erased {
        let w = mask.width, h = mask.height
        let ring = dilate(mask.bits, width: w, height: h, radius: 2)
        var samples: [RGB] = []
        var sum: Double = 0, sumSq: Double = 0
        for i in 0..<(w * h) where ring[i] && !mask.bits[i] {
            let y = i / w, x = i - y * w
            let c = canvas.rgb(mask.x0 + x, mask.y0 + y)
            samples.append(c)
            let l = Double(c.luma)
            sum += l; sumSq += l * l
        }
        guard !samples.isEmpty else { return Erased(background: .white, busy: true) }
        let n = Double(samples.count)
        let spread = (max(0, sumSq / n - (sum / n) * (sum / n))).squareRoot()
        let background = RGB.median(samples)
        let plain = spread <= 22 && background.luma >= 160
        if plain {
            for i in 0..<(w * h) where mask.bits[i] {
                let y = i / w, x = i - y * w
                canvas.set(mask.x0 + x, mask.y0 + y, background)
            }
        }
        return Erased(background: background, busy: !plain)
    }

    /// Exemplar fill for text over art: the masked area is rebuilt tile by tile,
    /// best-supported spots first, each tile copied from the nearby spot whose
    /// surroundings match best, so lines and tones carry on through the gap.
    static func textureFill(_ mask: LocalMask, canvas: PixelCanvas, avoid: Set<Int32>, labels: [Int32]?,
                            avoidRadius: Int, tile: Int = 10, search: Int = 66, step: Int = 3) {
        let ring = 4
        let win = tile + 2 * ring
        let ax0 = max(0, mask.x0 - search), ay0 = max(0, mask.y0 - search)
        let ax1 = min(canvas.width - 1, mask.x0 + mask.width - 1 + search)
        let ay1 = min(canvas.height - 1, mask.y0 + mask.height - 1 + search)
        let w = ax1 - ax0 + 1, h = ay1 - ay0 + 1
        guard w > win, h > win else { return }

        var original = [Bool](repeating: false, count: w * h)
        for y in 0..<mask.height {
            for x in 0..<mask.width where mask.bits[y * mask.width + x] {
                original[(mask.y0 - ay0 + y) * w + (mask.x0 - ax0 + x)] = true
            }
        }
        // Sources may not contain this text or any other lettering.
        var invalid = original
        if let labels, !avoid.isEmpty {
            var other = [Bool](repeating: false, count: w * h)
            for y in 0..<h {
                let row = (ay0 + y) * canvas.width + ax0
                for x in 0..<w where avoid.contains(labels[row + x]) { other[y * w + x] = true }
            }
            other = dilate(other, width: w, height: h, radius: avoidRadius)
            for i in 0..<(w * h) where other[i] { invalid[i] = true }
        }

        var r = [Float](repeating: 0, count: w * h), g = r, b = r, lum = r
        for y in 0..<h {
            for x in 0..<w {
                let c = canvas.rgb(ax0 + x, ay0 + y)
                let i = y * w + x
                r[i] = Float(c.r); g[i] = Float(c.g); b[i] = Float(c.b)
                lum[i] = 0.299 * r[i] + 0.587 * g[i] + 0.114 * b[i]
            }
        }
        var sat = [Int32](repeating: 0, count: (w + 1) * (h + 1))
        for y in 0..<h {
            var rowSum: Int32 = 0
            for x in 0..<w {
                if invalid[y * w + x] { rowSum += 1 }
                sat[(y + 1) * (w + 1) + x + 1] = sat[y * (w + 1) + x + 1] + rowSum
            }
        }
        func blocked(_ x: Int, _ y: Int) -> Bool {
            let a = sat[y * (w + 1) + x], bb = sat[y * (w + 1) + x + win]
            let c = sat[(y + win) * (w + 1) + x], d = sat[(y + win) * (w + 1) + x + win]
            return d - bb - c + a > 0
        }

        var unknown = original
        let nearWeight: Float = 0.04
        var passes = 0
        while passes < 400 {
            passes += 1
            // Front pixels, ranked by how much known context surrounds them.
            var front: [(index: Int, known: Int)] = []
            for y in 0..<h {
                for x in 0..<w where unknown[y * w + x] {
                    let i = y * w + x
                    guard (x > 0 && !unknown[i - 1]) || (x < w - 1 && !unknown[i + 1])
                            || (y > 0 && !unknown[i - w]) || (y < h - 1 && !unknown[i + w]) else { continue }
                    var known = 0
                    for yy in max(0, y - 3)...min(h - 1, y + 3) {
                        for xx in max(0, x - 3)...min(w - 1, x + 3) where !unknown[yy * w + xx] { known += 1 }
                    }
                    front.append((i, known))
                }
            }
            if front.isEmpty { break }
            front.sort { $0.known > $1.known }
            var progressed = false
            for item in front.prefix(max(1, front.count / 3)) where unknown[item.index] {
                let py = item.index / w, px = item.index - py * w
                let wx = max(0, min(w - win, px - win / 2)), wy = max(0, min(h - win, py - win / 2))
                var knownCount = 0
                for yy in 0..<win { for xx in 0..<win where !unknown[(wy + yy) * w + wx + xx] { knownCount += 1 } }
                guard knownCount >= 8 else { continue }

                var best = Float.greatestFiniteMagnitude, bx = -1, by = -1
                var sy = max(0, wy - search)
                while sy <= min(h - win, wy + search) {
                    var sx = max(0, wx - search)
                    while sx <= min(w - win, wx + search) {
                        defer { sx += step }
                        if blocked(sx, sy) { continue }
                        let dx = Float(sx - wx), dy = Float(sy - wy)
                        let penalty = nearWeight * (dx * dx + dy * dy)
                        if penalty >= best { continue }
                        var ssd: Float = 0, n: Float = 0
                        for yy in 0..<win {
                            let t = (wy + yy) * w + wx, s0 = (sy + yy) * w + sx
                            for xx in 0..<win where !unknown[t + xx] {
                                let d = lum[s0 + xx] - lum[t + xx]
                                ssd += d * d; n += 1
                            }
                            if n > 12 && ssd / n + penalty > best { break }
                        }
                        let score = ssd / max(n, 1) + penalty
                        if score < best { best = score; bx = sx; by = sy }
                    }
                    sy += step
                }
                guard bx >= 0 else { continue }
                for yy in 0..<win {
                    for xx in 0..<win {
                        let t = (wy + yy) * w + wx + xx
                        guard unknown[t] else { continue }
                        let s0 = (by + yy) * w + bx + xx
                        r[t] = r[s0]; g[t] = g[s0]; b[t] = b[s0]; lum[t] = lum[s0]
                        unknown[t] = false
                    }
                }
                progressed = true
            }
            if !progressed { break }
        }

        for y in 0..<h {
            for x in 0..<w where original[y * w + x] {
                let i = y * w + x
                canvas.set(ax0 + x, ay0 + y, RGB(r: UInt8(max(0, min(255, r[i]))),
                                                 g: UInt8(max(0, min(255, g[i]))),
                                                 b: UInt8(max(0, min(255, b[i])))))
            }
        }
        // Anything the tiles couldn't reach is smoothed in.
        var leftover = [Bool](repeating: false, count: mask.width * mask.height)
        var any = false
        for y in 0..<mask.height {
            for x in 0..<mask.width where unknown[(mask.y0 - ay0 + y) * w + (mask.x0 - ax0 + x)] {
                leftover[y * mask.width + x] = true
                any = true
            }
        }
        if any { fill(LocalMask(x0: mask.x0, y0: mask.y0, width: mask.width, height: mask.height, bits: leftover), canvas: canvas) }
    }

    /// A soft white haze shaped like the original lettering's outline band, so
    /// any seams in the rebuilt art read as a faint glow rather than glitches.
    static func haze(_ mask: LocalMask, glyph: CGFloat, canvas: PixelCanvas, strength: Float = 0.5) {
        let grow = max(2, Int(glyph * 0.3))
        let blur = max(2, Int(glyph * 0.3))
        let pad = grow + blur * 3
        let x0 = max(0, mask.x0 - pad), y0 = max(0, mask.y0 - pad)
        let x1 = min(canvas.width - 1, mask.x0 + mask.width - 1 + pad)
        let y1 = min(canvas.height - 1, mask.y0 + mask.height - 1 + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return }
        var band = [Bool](repeating: false, count: w * h)
        for y in 0..<mask.height {
            for x in 0..<mask.width where mask.bits[y * mask.width + x] {
                band[(mask.y0 - y0 + y) * w + (mask.x0 - x0 + x)] = true
            }
        }
        band = dilate(band, width: w, height: h, radius: grow)
        var alpha = band.map { $0 ? Float(1) : 0 }
        for _ in 0..<3 { alpha = boxBlur(alpha, width: w, height: h, radius: blur) }
        for y in 0..<h {
            for x in 0..<w {
                let a = min(1, alpha[y * w + x]) * strength
                guard a > 0.01 else { continue }
                let c = canvas.rgb(x0 + x, y0 + y)
                func mix(_ v: UInt8) -> UInt8 { UInt8(max(0, min(255, Float(v) * (1 - a) + 255 * a))) }
                canvas.set(x0 + x, y0 + y, RGB(r: mix(c.r), g: mix(c.g), b: mix(c.b)))
            }
        }
    }

    static func boxBlur(_ v: [Float], width w: Int, height h: Int, radius r: Int) -> [Float] {
        var tmp = [Float](repeating: 0, count: w * h)
        let size = Float(2 * r + 1)
        for y in 0..<h {
            var sum: Float = 0
            for x in -r...r { sum += v[y * w + min(max(x, 0), w - 1)] }
            for x in 0..<w {
                tmp[y * w + x] = sum / size
                sum += v[y * w + min(x + r + 1, w - 1)] - v[y * w + max(x - r, 0)]
            }
        }
        var out = [Float](repeating: 0, count: w * h)
        for x in 0..<w {
            var sum: Float = 0
            for y in -r...r { sum += tmp[min(max(y, 0), h - 1) * w + x] }
            for y in 0..<h {
                out[y * w + x] = sum / size
                sum += tmp[min(y + r + 1, h - 1) * w + x] - tmp[max(y - r, 0) * w + x]
            }
        }
        return out
    }

    /// Onion-peel fill: each pass fills masked pixels from their known neighbours.
    /// The mask's outer frame always stays as anchors.
    static func fill(_ mask: LocalMask, canvas: PixelCanvas) {
        let w = mask.width, h = mask.height
        guard w > 2, h > 2 else { return }
        var unknown = mask.bits
        for x in 0..<w { unknown[x] = false; unknown[(h - 1) * w + x] = false }
        for y in 0..<h { unknown[y * w] = false; unknown[y * w + w - 1] = false }
        var r = [Float](repeating: 0, count: w * h), g = r, b = r
        for y in 0..<h {
            for x in 0..<w {
                let c = canvas.rgb(mask.x0 + x, mask.y0 + y)
                r[y * w + x] = Float(c.r); g[y * w + x] = Float(c.g); b[y * w + x] = Float(c.b)
            }
        }
        let painted = unknown
        var passes = w + h
        while passes > 0 {
            passes -= 1
            var updates: [(Int, Float, Float, Float)] = []
            for y in 1..<(h - 1) {
                for x in 1..<(w - 1) where unknown[y * w + x] {
                    var sr: Float = 0, sg: Float = 0, sb: Float = 0, n: Float = 0
                    for dy in -1...1 {
                        for dx in -1...1 where !(dx == 0 && dy == 0) {
                            let j = (y + dy) * w + (x + dx)
                            if !unknown[j] { sr += r[j]; sg += g[j]; sb += b[j]; n += 1 }
                        }
                    }
                    if n > 0 { updates.append((y * w + x, sr / n, sg / n, sb / n)) }
                }
            }
            if updates.isEmpty { break }
            for (i, vr, vg, vb) in updates {
                r[i] = vr; g[i] = vg; b[i] = vb
                unknown[i] = false
            }
        }
        for y in 0..<h {
            for x in 0..<w where painted[y * w + x] {
                let i = y * w + x
                canvas.set(mask.x0 + x, mask.y0 + y, RGB(r: UInt8(max(0, min(255, r[i]))),
                                                         g: UInt8(max(0, min(255, g[i]))),
                                                         b: UInt8(max(0, min(255, b[i])))))
            }
        }
    }

    /// Square dilation in two separable passes.
    static func dilate(_ bits: [Bool], width w: Int, height h: Int, radius r: Int) -> [Bool] {
        guard r > 0 else { return bits }
        var tmp = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            var count = 0
            for x in 0..<min(r, w) where bits[y * w + x] { count += 1 }
            for x in 0..<w {
                let add = x + r
                if add < w && bits[y * w + add] { count += 1 }
                tmp[y * w + x] = count > 0
                let remove = x - r
                if remove >= 0 && bits[y * w + remove] { count -= 1 }
            }
        }
        var out = [Bool](repeating: false, count: w * h)
        for x in 0..<w {
            var count = 0
            for y in 0..<min(r, h) where tmp[y * w + x] { count += 1 }
            for y in 0..<h {
                let add = y + r
                if add < h && tmp[add * w + x] { count += 1 }
                out[y * w + x] = count > 0
                let remove = y - r
                if remove >= 0 && tmp[remove * w + x] { count -= 1 }
            }
        }
        return out
    }
}
