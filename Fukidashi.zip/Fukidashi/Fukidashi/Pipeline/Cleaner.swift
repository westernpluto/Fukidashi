import CoreGraphics
import Foundation

/// Removes the original lettering before the English is drawn.
enum Cleaner {
    /// The bubble's own background colour (median of its background pixels).
    static func backgroundColor(of bubble: BubbleCandidate, canvas: PixelCanvas) -> RGB {
        let m = bubble.component
        var samples: [RGB] = []
        let step = max(1, (m.width * m.height) / 4000)
        var i = 0
        while i < m.bits.count {
            if m.bits[i] {
                let y = i / m.width, x = i - y * m.width
                samples.append(canvas.rgb(m.x0 + x, m.y0 + y))
            }
            i += step
        }
        return RGB.median(samples)
    }

    /// Repaints the bubble interior (background + enclosed lettering) with the
    /// bubble colour, which also removes anti-aliasing fringes and JPEG noise.
    static func clean(bubble: BubbleCandidate, color: RGB, canvas: PixelCanvas) {
        let f = bubble.filled
        for y in 0..<f.height {
            for x in 0..<f.width where f.bits[y * f.width + x] {
                canvas.set(f.x0 + x, f.y0 + y, color)
            }
        }
    }

    /// Text drawn over art or on a borderless box: mask the strokes that stand
    /// out from the local background and fill them in from the edges inward.
    /// Returns the estimated background colour.
    @discardableResult
    static func inpaint(rect: CGRect, canvas: PixelCanvas) -> RGB {
        let pad = 4
        let x0 = max(0, Int(rect.minX) - pad), y0 = max(0, Int(rect.minY) - pad)
        let x1 = min(canvas.width - 1, Int(rect.maxX) + pad), y1 = min(canvas.height - 1, Int(rect.maxY) + pad)
        let w = x1 - x0 + 1, h = y1 - y0 + 1
        guard w > 2, h > 2 else { return .white }

        var border: [RGB] = []
        for x in 0..<w { border.append(canvas.rgb(x0 + x, y0)); border.append(canvas.rgb(x0 + x, y1)) }
        for y in 0..<h { border.append(canvas.rgb(x0, y0 + y)); border.append(canvas.rgb(x1, y0 + y)) }
        let bg = RGB.median(border)
        let bgLuma = bg.luma

        var mask = [Bool](repeating: false, count: w * h)
        for y in 0..<h {
            for x in 0..<w where abs(canvas.rgb(x0 + x, y0 + y).luma - bgLuma) > 48 {
                mask[y * w + x] = true
            }
        }
        // Dilate by 2 px so anti-aliased edges go too (border pixels stay as anchors).
        var dilated = mask
        for y in 1..<(h - 1) {
            for x in 1..<(w - 1) where mask[y * w + x] {
                for dy in -2...2 {
                    for dx in -2...2 {
                        let nx = x + dx, ny = y + dy
                        if nx > 0, ny > 0, nx < w - 1, ny < h - 1 { dilated[ny * w + nx] = true }
                    }
                }
            }
        }

        // Onion-peel fill: each pass fills masked pixels touching known pixels.
        var r = [Float](repeating: 0, count: w * h)
        var g = r, b = r
        for y in 0..<h {
            for x in 0..<w {
                let c = canvas.rgb(x0 + x, y0 + y)
                r[y * w + x] = Float(c.r); g[y * w + x] = Float(c.g); b[y * w + x] = Float(c.b)
            }
        }
        var unknown = dilated
        var remaining = unknown.reduce(0) { $1 ? $0 + 1 : $0 }
        var guardPasses = w + h
        while remaining > 0 && guardPasses > 0 {
            guardPasses -= 1
            var updates: [(Int, Float, Float, Float)] = []
            for y in 0..<h {
                for x in 0..<w where unknown[y * w + x] {
                    var sr: Float = 0, sg: Float = 0, sb: Float = 0, n: Float = 0
                    for dy in -1...1 {
                        for dx in -1...1 where !(dx == 0 && dy == 0) {
                            let nx = x + dx, ny = y + dy
                            guard nx >= 0, ny >= 0, nx < w, ny < h else { continue }
                            let j = ny * w + nx
                            if !unknown[j] { sr += r[j]; sg += g[j]; sb += b[j]; n += 1 }
                        }
                    }
                    if n > 0 { updates.append((y * w + x, sr / n, sg / n, sb / n)) }
                }
            }
            if updates.isEmpty { break }
            for (i, vr, vg, vb) in updates {
                r[i] = vr; g[i] = vg; b[i] = vb
                unknown[i] = false
            }
            remaining -= updates.count
        }

        for y in 0..<h {
            for x in 0..<w where dilated[y * w + x] {
                let i = y * w + x
                canvas.set(x0 + x, y0 + y, RGB(r: UInt8(max(0, min(255, r[i]))),
                                               g: UInt8(max(0, min(255, g[i]))),
                                               b: UInt8(max(0, min(255, b[i])))))
            }
        }
        return bg
    }
}
