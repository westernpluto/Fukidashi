import Foundation
import FoundationModels
import Translation

enum TranslationEngineError: LocalizedError {
    case languagePackMissing(String)
    case nothingAvailable

    var errorDescription: String? {
        switch self {
        case .languagePackMissing(let name):
            return "Download \(name) for Apple Translate in Settings, or turn on Apple Intelligence, so pages can be translated offline."
        case .nothingAvailable:
            return "No on-device translator is available. Turn on Apple Intelligence or download the language for Apple Translate in Settings."
        }
    }
}

/// Translates one page of dialogue on device.
///
/// Primary engine: Apple's on-device language model, given the whole page in
/// reading order plus the previous page's lines, so it can infer dropped
/// subjects, keep character voice and localise rather than translate word by
/// word. Fallback: Apple Translate (system translation models).
enum Localizer {
    static var appleIntelligenceAvailable: Bool { SystemLanguageModel.default.isAvailable }

    static var appleIntelligenceStatus: String {
        switch SystemLanguageModel.default.availability {
        case .available:
            return "Ready"
        case .unavailable(let reason):
            switch reason {
            case .deviceNotEligible: return "This device doesn't support Apple Intelligence"
            case .appleIntelligenceNotEnabled: return "Turn on Apple Intelligence in the Settings app"
            case .modelNotReady: return "Model is still downloading"
            default: return "Unavailable"
            }
        }
    }

    struct Result {
        var lines: [String?]
        var note: String?
    }

    static func translate(_ lines: [String], context: [String], options: TranslationOptions) async throws -> Result {
        var output = [String?](repeating: nil, count: lines.count)
        var pending: [Int] = []
        for (i, line) in lines.enumerated() {
            if let direct = punctuationOnly(line, language: options.source) { output[i] = direct } else { pending.append(i) }
        }
        guard !pending.isEmpty else { return Result(lines: output, note: nil) }
        let todo = pending.map { lines[$0] }

        var translated = [String?](repeating: nil, count: todo.count)
        let useModel = options.engine != .appleTranslate && appleIntelligenceAvailable
        if useModel {
            translated = await modelTranslate(todo, context: context, options: options)
        }

        let missing = translated.indices.filter { translated[$0] == nil }
        var note: String?
        if !missing.isEmpty {
            do {
                let fallback = try await appleTranslate(missing.map { todo[$0] }, source: options.source)
                for (k, i) in missing.enumerated() { translated[i] = fallback[k] }
            } catch {
                if !useModel { throw error }
                note = "\(missing.count) line(s) couldn't be translated. " + (error.localizedDescription)
            }
        }
        for (k, i) in pending.enumerated() { output[i] = translated[k].map(tidy) }
        return Result(lines: output, note: note)
    }

    // MARK: Apple Intelligence

    private static func instructions(_ options: TranslationOptions) -> String {
        let lang = options.source.displayName
        let honorifics = options.keepHonorifics
            ? "Keep honorifics such as -san, -kun, -chan, -sama and -senpai attached to names."
            : "Drop honorifics like -san and -kun; convey politeness or closeness through word choice instead."
        let subjects = options.source == .japanese
            ? "Japanese often leaves out the subject and object; work out who is speaking and who is meant from the other lines.\n"
            : ""
        return """
        You are a professional manga letterer and localizer. You turn \(lang) comic dialogue into natural, fluent, idiomatic English that reads the way an official English release would.
        Rules:
        - Translate the meaning, tone and each character's voice, not word for word. Use contractions and everyday spoken English.
        - The \(lang) text came from OCR and may contain small recognition errors; infer what was meant.
        \(subjects)- Keep character and place names. \(honorifics)
        - Turn sound effects and interjections into short English equivalents such as "Huh?", "Whoa!", "Ugh..." or "Tch."
        - Keep each line about as short as the original so it fits back into its speech bubble.
        - Output exactly one line per input line, in the same order, formatted as [number] English text.
        - Never add notes, explanations, romanization or the original text.
        """
    }

    private static func prompt(_ lines: [String], context: [String]) -> String {
        var p = ""
        if !context.isEmpty {
            p += "Earlier in this chapter (already translated, for context only):\n"
            p += context.joined(separator: "\n")
            p += "\n\n"
        }
        p += "Translate these speech bubbles from one page, listed in reading order:\n"
        for (i, line) in lines.enumerated() { p += "[\(i + 1)] \(line)\n" }
        return p
    }

    private static func modelTranslate(_ lines: [String], context: [String], options: TranslationOptions) async -> [String?] {
        if let whole = await modelAttempt(lines, context: context, options: options),
           whole.contains(where: { $0 != nil }) {
            // Retry any lines the model skipped, in a short batch of their own.
            let skipped = whole.indices.filter { whole[$0] == nil }
            guard !skipped.isEmpty, skipped.count < lines.count else { return whole }
            var merged = whole
            if let again = await modelAttempt(skipped.map { lines[$0] }, context: [], options: options) {
                for (k, i) in skipped.enumerated() where k < again.count { merged[i] = again[k] }
            }
            return merged
        }
        // The whole page failed (context too long, or a guardrail): go in small chunks.
        var out = [String?](repeating: nil, count: lines.count)
        var start = 0
        while start < lines.count {
            let end = min(start + 5, lines.count)
            if let part = await modelAttempt(Array(lines[start..<end]), context: [], options: options) {
                for (k, v) in part.enumerated() { out[start + k] = v }
            }
            start = end
        }
        return out
    }

    private static func modelAttempt(_ lines: [String], context: [String], options: TranslationOptions) async -> [String?]? {
        let model = SystemLanguageModel(guardrails: .permissiveContentTransformations)
        let session = LanguageModelSession(model: model, instructions: instructions(options))
        do {
            let response = try await session.respond(to: prompt(lines, context: context),
                                                     options: GenerationOptions(temperature: 0.3))
            return parse(response.content, count: lines.count, source: options.source)
        } catch {
            return nil
        }
    }

    /// Reads "[n] text" lines; drops anything that still contains source script.
    static func parse(_ response: String, count: Int, source: SourceLanguage) -> [String?] {
        var out = [String?](repeating: nil, count: count)
        for raw in response.split(whereSeparator: \.isNewline) {
            var line = raw.trimmingCharacters(in: .whitespaces)
            while line.hasPrefix("-") || line.hasPrefix("*") { line = String(line.dropFirst()).trimmingCharacters(in: .whitespaces) }
            guard line.hasPrefix("["), let close = line.firstIndex(of: "]") else { continue }
            let number = line[line.index(after: line.startIndex)..<close].trimmingCharacters(in: .whitespaces)
            guard let n = Int(number), n >= 1, n <= count else { continue }
            var text = String(line[line.index(after: close)...]).trimmingCharacters(in: .whitespaces)
            if text.hasPrefix(":") { text = String(text.dropFirst()).trimmingCharacters(in: .whitespaces) }
            guard !text.isEmpty, source.scriptCount(text) == 0 else { continue }
            out[n - 1] = text
        }
        return out
    }

    // MARK: Apple Translate

    static func appleTranslate(_ lines: [String], source: SourceLanguage) async throws -> [String] {
        let target = Locale.Language(identifier: "en")
        let status = await LanguageAvailability().status(from: source.localeLanguage, to: target)
        guard status == .installed else { throw TranslationEngineError.languagePackMissing(source.displayName) }
        let session: TranslationSession
        if #available(iOS 26.4, *) {
            session = TranslationSession(installedSource: source.localeLanguage, target: target, preferredStrategy: .highFidelity)
        } else {
            session = TranslationSession(installedSource: source.localeLanguage, target: target)
        }
        let requests = lines.enumerated().map { TranslationSession.Request(sourceText: $0.element, clientIdentifier: String($0.offset)) }
        let responses = try await session.translations(from: requests)
        var out = lines
        for response in responses {
            if let id = response.clientIdentifier, let i = Int(id), i >= 0, i < out.count { out[i] = response.targetText }
        }
        return out
    }

    // MARK: Helpers

    /// "！？", "…" and friends don't need a translator.
    static func punctuationOnly(_ text: String, language: SourceLanguage) -> String? {
        guard language.scriptCount(text) == 0 else { return nil }
        let map: [Character: String] = ["！": "!", "？": "?", "…": "...", "‥": "..", "・": ".", "。": ".", "、": ",",
                                        "ー": "—", "〜": "~", "～": "~", "!": "!", "?": "?", ".": "."]
        var out = ""
        for ch in text where !ch.isWhitespace {
            guard let m = map[ch] else { return nil }
            out += m
        }
        return out.isEmpty ? nil : out
    }

    static func tidy(_ s: String) -> String {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let quotes: Set<Character> = ["\"", "“", "”", "「", "」", "『", "』"]
        while let f = t.first, quotes.contains(f), let l = t.last, quotes.contains(l), t.count > 1 {
            t = String(t.dropFirst().dropLast()).trimmingCharacters(in: .whitespaces)
        }
        return t.split(whereSeparator: { $0 == " " || $0 == "\n" }).joined(separator: " ")
    }
}
