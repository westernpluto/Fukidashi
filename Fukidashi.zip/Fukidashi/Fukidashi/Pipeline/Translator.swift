import Foundation
import FoundationModels
import Translation

enum TranslationEngineError: LocalizedError {
    case languagePackMissing(String)
    case nothingAvailable

    var errorDescription: String? {
        switch self {
        case .languagePackMissing(let name):
            return "Download \(name) for Apple Translate in Settings, or turn on Apple Intelligence, so pages can be translated offline."
        case .nothingAvailable:
            return "No on-device translator is available. Turn on Apple Intelligence or download the language for Apple Translate in Settings."
        }
    }
}

/// Translates one page of dialogue on device.
///
/// Primary engine: Apple's on-device language model, given the whole page in
/// reading order plus the previous page's lines, so it can infer dropped
/// subjects, keep character voice and localise rather than translate word by
/// word. Fallback: Apple Translate (system translation models).
enum Localizer {
    static var appleIntelligenceAvailable: Bool { SystemLanguageModel.default.isAvailable }

    static var appleIntelligenceStatus: String {
        switch SystemLanguageModel.default.availability {
        case .available:
            return "Ready"
        case .unavailable(let reason):
            switch reason {
            case .deviceNotEligible: return "This device doesn't support Apple Intelligence"
            case .appleIntelligenceNotEnabled: return "Turn on Apple Intelligence in the Settings app"
            case .modelNotReady: return "Model is still downloading"
            default: return "Unavailable"
            }
        }
    }

    struct Result {
        var lines: [String?]
        var note: String?
    }

    static func translate(_ lines: [String], context: [String], options: TranslationOptions) async throws -> Result {
        var output = [String?](repeating: nil, count: lines.count)
        var pending: [Int] = []
        for (i, line) in lines.enumerated() {
            if let direct = punctuationOnly(line, language: options.source)
                ?? MetaText.direct(line, language: options.source)
                ?? MetaText.credit(line, language: options.source) {
                output[i] = direct
            } else {
                pending.append(i)
            }
        }
        guard !pending.isEmpty else { return Result(lines: output, note: nil) }
        let todo = pending.map { lines[$0] }

        var translated = [String?](repeating: nil, count: todo.count)
        let useModel = options.engine != .appleTranslate && appleIntelligenceAvailable
        if useModel {
            translated = await modelTranslate(todo, context: context, options: options)
        }

        let missing = translated.indices.filter { translated[$0] == nil }
        var note: String?
        if !missing.isEmpty {
            do {
                let fallback = try await appleTranslate(missing.map { todo[$0] }, source: options.source)
                for (k, i) in missing.enumerated() { translated[i] = fallback[k] }
            } catch {
                if !useModel { throw error }
                note = "\(missing.count) line(s) couldn't be translated. " + (error.localizedDescription)
            }
        }
        for (k, i) in pending.enumerated() {
            output[i] = translated[k].map { finish(tidy($0), source: lines[i]) }
        }
        return Result(lines: output, note: note)
    }

    // MARK: Apple Intelligence

    private static func instructions(_ options: TranslationOptions) -> String {
        let lang = options.source.displayName
        let honorifics = options.keepHonorifics
            ? "Keep honorifics such as -san, -kun, -chan, -sama and -senpai attached to names."
            : "Drop honorifics like -san and -kun; convey politeness or closeness through word choice instead."
        let subjects = options.source == .japanese
            ? "Japanese often leaves out the subject and object; work out who is speaking and who is meant from the other lines.\n"
            : ""
        return """
        You are a professional manga letterer and localizer. You turn \(lang) comic dialogue into natural, fluent, idiomatic English that reads the way an official English release would.
        Rules:
        - Translate the meaning, tone and each character's voice, not word for word. Use contractions and everyday spoken English.
        - The \(lang) text came from OCR and may contain small recognition errors; infer what was meant.
        \(subjects)- Keep character and place names. \(honorifics)
        - Turn sound effects and interjections into short, natural English interjections.
        - Translate only what each line says. Never move words from one line into another.
        - Short labels and titles get no final period.
        - Keep each line about as short as the original so it fits back into its speech bubble.
        - Output exactly one line per input line, in the same order, formatted as [number] English text.
        - Never add notes, explanations, romanization or the original text.
        """
    }

    private static func prompt(_ lines: [String], context: [String]) -> String {
        var p = ""
        if !context.isEmpty {
            p += "Earlier in this chapter (already translated, for context only):\n"
            p += context.joined(separator: "\n")
            p += "\n\n"
        }
        p += "Translate these speech bubbles from one page, listed in reading order:\n"
        for (i, line) in lines.enumerated() { p += "[\(i + 1)] \(line)\n" }
        return p
    }

    private static func modelTranslate(_ lines: [String], context: [String], options: TranslationOptions) async -> [String?] {
        if let whole = await modelAttempt(lines, context: context, options: options),
           whole.contains(where: { $0 != nil }) {
            // Retry any lines the model skipped, in a short batch of their own.
            let skipped = whole.indices.filter { whole[$0] == nil }
            guard !skipped.isEmpty, skipped.count < lines.count else { return whole }
            var merged = whole
            if let again = await modelAttempt(skipped.map { lines[$0] }, context: [], options: options) {
                for (k, i) in skipped.enumerated() where k < again.count { merged[i] = again[k] }
            }
            for i in merged.indices.filter({ merged[$0] == nil }).prefix(6) {
                if let single = await modelAttempt([lines[i]], context: [], options: options), let first = single.first {
                    merged[i] = first
                }
            }
            return merged
        }
        // The whole page failed (context too long, or a guardrail): go in small chunks.
        var out = [String?](repeating: nil, count: lines.count)
        var start = 0
        while start < lines.count {
            let end = min(start + 5, lines.count)
            if let part = await modelAttempt(Array(lines[start..<end]), context: [], options: options) {
                for (k, v) in part.enumerated() { out[start + k] = v }
            }
            start = end
        }
        return out
    }

    private static func modelAttempt(_ lines: [String], context: [String], options: TranslationOptions) async -> [String?]? {
        let model = SystemLanguageModel(guardrails: .permissiveContentTransformations)
        let session = LanguageModelSession(model: model, instructions: instructions(options))
        do {
            let response = try await session.respond(to: prompt(lines, context: context),
                                                     options: GenerationOptions(temperature: 0.3))
            return parse(response.content, count: lines.count, source: options.source)
        } catch {
            return nil
        }
    }

    /// Reads "[n] text" lines; drops anything that still contains source script.
    static func parse(_ response: String, count: Int, source: SourceLanguage) -> [String?] {
        var out = [String?](repeating: nil, count: count)
        for raw in response.split(whereSeparator: \.isNewline) {
            var line = raw.trimmingCharacters(in: .whitespaces)
            while line.hasPrefix("-") || line.hasPrefix("*") { line = String(line.dropFirst()).trimmingCharacters(in: .whitespaces) }
            guard line.hasPrefix("["), let close = line.firstIndex(of: "]") else { continue }
            let number = line[line.index(after: line.startIndex)..<close].trimmingCharacters(in: .whitespaces)
            guard let n = Int(number), n >= 1, n <= count else { continue }
            var text = String(line[line.index(after: close)...]).trimmingCharacters(in: .whitespaces)
            if text.hasPrefix(":") { text = String(text.dropFirst()).trimmingCharacters(in: .whitespaces) }
            guard !text.isEmpty, source.scriptCount(text) == 0 else { continue }
            out[n - 1] = text
        }
        return out
    }

    // MARK: Apple Translate

    static func appleTranslate(_ lines: [String], source: SourceLanguage) async throws -> [String] {
        var labels: [String?] = []
        var texts: [String] = []
        for line in lines {
            if let credit = MetaText.creditLabel(line, language: source) {
                labels.append(credit.0); texts.append(credit.1)
            } else {
                labels.append(nil); texts.append(line)
            }
        }
        let translated = try await appleTranslateRaw(texts, source: source)
        return translated.enumerated().map { i, t in labels[i].map { "\($0): \(t)" } ?? t }
    }

    private static func appleTranslateRaw(_ lines: [String], source: SourceLanguage) async throws -> [String] {
        let target = Locale.Language(identifier: "en")
        let status = await LanguageAvailability().status(from: source.localeLanguage, to: target)
        guard status == .installed else { throw TranslationEngineError.languagePackMissing(source.displayName) }
        let session: TranslationSession
        if #available(iOS 26.4, *) {
            session = TranslationSession(installedSource: source.localeLanguage, target: target, preferredStrategy: .highFidelity)
        } else {
            session = TranslationSession(installedSource: source.localeLanguage, target: target)
        }
        let requests = lines.enumerated().map { TranslationSession.Request(sourceText: $0.element, clientIdentifier: String($0.offset)) }
        let responses = try await session.translations(from: requests)
        var out = lines
        for response in responses {
            if let id = response.clientIdentifier, let i = Int(id), i >= 0, i < out.count { out[i] = response.targetText }
        }
        return out
    }

    // MARK: Helpers

    /// "！？", "…" and friends don't need a translator.
    static func punctuationOnly(_ text: String, language: SourceLanguage) -> String? {
        guard language.scriptCount(text) == 0 else { return nil }
        let map: [Character: String] = ["！": "!", "？": "?", "…": "...", "‥": "..", "・": ".", "。": ".", "、": ",",
                                        "ー": "—", "〜": "~", "～": "~", "!": "!", "?": "?", ".": "."]
        var out = ""
        for ch in text where !ch.isWhitespace {
            guard let m = map[ch] else { return nil }
            out += m
        }
        return out.isEmpty ? nil : out
    }

    /// Short labels ("Story: Ta-chan") read better without the period small
    /// models like to add, unless the original ended its sentence.
    static func finish(_ english: String, source: String) -> String {
        let words = english.split(separator: " ").count
        let sourceEndsSentence = source.hasSuffix("。") || source.hasSuffix("．")
        if words <= 5, english.hasSuffix("."), !english.hasSuffix(".."), !sourceEndsSentence {
            return String(english.dropLast())
        }
        return english
    }

    static func tidy(_ s: String) -> String {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let quotes: Set<Character> = ["\"", "“", "”", "「", "」", "『", "』"]
        while let f = t.first, quotes.contains(f), let l = t.last, quotes.contains(l), t.count > 1 {
            t = String(t.dropFirst().dropLast()).trimmingCharacters(in: .whitespaces)
        }
        return t.split(whereSeparator: { $0 == " " || $0 == "\n" }).joined(separator: " ")
    }
}


/// Chapter numbers, credits and stock publishing phrases have fixed English
/// equivalents, so they never depend on the translator.
enum MetaText {
    static func normalized(_ text: String) -> String {
        let fullWidthDigits = Array("０１２３４５６７８９")
        let strip: Set<Character> = ["〈", "〉", "<", ">", "《", "》", "【", "】", "(", ")", "（", "）", "「", "」", "『", "』", "［", "］", "[", "]", " ", "　", "・"]
        var out = ""
        for ch in text where !strip.contains(ch) {
            if let d = fullWidthDigits.firstIndex(of: ch) { out.append(Character(String(d))) } else { out.append(ch) }
        }
        return out
    }

    static func direct(_ text: String, language: SourceLanguage) -> String? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        var bangs = ""
        var core = Substring(t)
        while let last = core.last, "!！?？".contains(last) {
            bangs = (last == "?" || last == "？" ? "?" : "!") + bangs
            core = core.dropLast()
        }
        let c = String(core)
        // OCR often turns the decorative brackets around "第28話" into stray kana.
        if let n = number(in: c, pattern: "第([0-9]+)話"), c.count <= "第\(n)話".count + 2 { return "Chapter \(n)" + bangs }
        if let n = number(in: c, pattern: "^第([0-9]+)巻$") { return "Volume \(n)" + bangs }
        if let n = number(in: c, pattern: "^(?:最新)?(?:単行本|コミックス|コミック)(?:第)?([0-9]+)巻(?:好評発売中|大好評発売中|発売中)?$") {
            return (c.hasSuffix("発売中") ? "Volume \(n) on sale now" : "Volume \(n)") + bangs
        }
        switch c {
        case "大好評発売中", "好評発売中", "絶賛発売中", "発売中": return "On sale now" + (bangs.isEmpty ? "!" : bangs)
        case "つづく", "続く", "次回につづく", "次回に続く": return "To be continued" + bangs
        case "完", "終", "おわり", "終わり": return "The End"
        default: return nil
        }
    }

    /// "原作 たーちゃん" → "Story: Ta-chan", without a translator.
    static func credit(_ text: String, language: SourceLanguage) -> String? {
        guard let pair = creditLabel(text, language: language), let romanized = romanizeName(pair.1) else { return nil }
        return "\(pair.0): \(romanized)"
    }

    /// Japanese name → romaji using the system's Japanese tokenizer, e.g.
    /// たーちゃん → Ta-chan. Returns nil if it can't produce plain Latin text.
    static func romanizeName(_ name: String) -> String? {
        let cf = name as CFString
        let length = CFStringGetLength(cf)
        guard length > 0, length <= 20 else { return nil }
        guard let tokenizer = CFStringTokenizerCreate(nil, cf, CFRange(location: 0, length: length),
                                                      kCFStringTokenizerUnitWord, Locale(identifier: "ja") as CFLocale)
        else { return nil }
        var parts: [String] = []
        while !CFStringTokenizerAdvanceToNextToken(tokenizer).isEmpty {
            guard let latin = CFStringTokenizerCopyCurrentTokenAttribute(tokenizer, kCFStringTokenizerAttributeLatinTranscription) as? String
            else { continue }
            var plain = latin.applyingTransform(.stripDiacritics, reverse: false) ?? latin
            plain = plain.filter { $0.isLetter || $0 == " " }
            if !plain.isEmpty { parts.append(plain.lowercased()) }
        }
        guard !parts.isEmpty else { return nil }
        let honorifics: Set<String> = ["chan", "san", "kun", "sama", "sensei", "senpai", "tan"]
        var words: [String] = []
        for part in parts {
            if honorifics.contains(part), let last = words.popLast() {
                words.append(last + "-" + part)
            } else {
                words.append(part.prefix(1).uppercased() + part.dropFirst())
            }
        }
        let result = words.joined(separator: " ")
        guard result.unicodeScalars.allSatisfy({ $0.isASCII }) else { return nil }
        return result
    }

    /// "原作 たーちゃん" → ("Story", "たーちゃん").
    static func creditLabel(_ text: String, language: SourceLanguage) -> (String, String)? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        let labels: [(String, String)] = [("キャラクター原案", "Character design"), ("キャラクターデザイン", "Character design"),
                                          ("原作", "Story"), ("原案", "Original concept"), ("漫画", "Art"),
                                          ("作画", "Art"), ("構成", "Composition"), ("脚本", "Script")]
        for (jp, en) in labels where t.hasPrefix(jp) {
            let rest = String(t.dropFirst(jp.count)).trimmingCharacters(in: CharacterSet(charactersIn: ":：/／ "))
            if !rest.isEmpty { return (en, rest) }
        }
        return nil
    }

    private static func number(in text: String, pattern: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              m.numberOfRanges > 1, let r = Range(m.range(at: 1), in: text) else { return nil }
        return String(text[r])
    }
}
