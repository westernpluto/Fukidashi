import Foundation
import FoundationModels
import Translation

enum TranslationEngineError: LocalizedError {
    case languagePackMissing(String)
    case nothingAvailable
    case offlineModelMissing

    var errorDescription: String? {
        switch self {
        case .languagePackMissing(let name):
            return "Download \(name) for Apple Translate in Settings, or turn on Apple Intelligence, so pages can be translated offline."
        case .nothingAvailable:
            return "No on-device translator is available. Turn on Apple Intelligence or download the language for Apple Translate in Settings."
        case .offlineModelMissing:
            return "Download the offline translation model in Settings first, or pick another translator."
        }
    }
}

/// Translates one page of dialogue on device.
///
/// Primary engine: Apple's on-device language model, given the whole page in
/// reading order plus the previous page's lines, so it can infer dropped
/// subjects, keep character voice and localise rather than translate word by
/// word. Fallback: Apple Translate (system translation models).
enum Localizer {
    static var appleIntelligenceAvailable: Bool { SystemLanguageModel.default.isAvailable }

    static var appleIntelligenceStatus: String {
        switch SystemLanguageModel.default.availability {
        case .available:
            return "Ready"
        case .unavailable(let reason):
            switch reason {
            case .deviceNotEligible: return "This device doesn't support Apple Intelligence"
            case .appleIntelligenceNotEnabled: return "Turn on Apple Intelligence in the Settings app"
            case .modelNotReady: return "Model is still downloading"
            default: return "Unavailable"
            }
        }
    }

    struct Result {
        var lines: [String?]
        var note: String?
    }

    static func translate(_ lines: [String], context: [String], options: TranslationOptions) async throws -> Result {
        var output = [String?](repeating: nil, count: lines.count)
        var pending: [Int] = []
        for (i, line) in lines.enumerated() {
            if let direct = glossaryMatch(line, options: options)
                ?? punctuationOnly(line, language: options.source)
                ?? MetaText.direct(line, language: options.source)
                ?? MetaText.interjection(line, language: options.source)
                ?? creditWithGlossary(line, options: options)
                ?? MetaText.credit(line, language: options.source) {
                output[i] = direct
            } else {
                pending.append(i)
            }
        }
        guard !pending.isEmpty else { return Result(lines: output, note: nil) }
        let todo = pending.map { lines[$0] }

        var translated = [String?](repeating: nil, count: todo.count)
        var note: String?
        let offlineReady = OfflineModelFiles.isInstalled(options.offlineModel)
        if options.engine == .offlineModel && !offlineReady { throw TranslationEngineError.offlineModelMissing }

        // 1. A draft from a dedicated translation model: the downloaded one, or
        //    Apple Translate. These get the meaning right more often.
        var drafts = [String?](repeating: nil, count: todo.count)
        let wantsOffline = options.engine == .offlineModel || (options.engine == .automatic && offlineReady)
        if wantsOffline {
            do {
                drafts = try await OfflineTranslator.shared.translate(todo, context: context, glossary: options.glossary,
                                                                      model: options.offlineModel)
            } catch {
                note = "The offline model couldn't translate this page: \(error.localizedDescription)"
            }
        }
        if options.engine != .offlineModel, drafts.contains(where: { $0 == nil }),
           await languagePackInstalled(options.source) {
            let gaps = drafts.indices.filter { drafts[$0] == nil }
            if let fallback = try? await appleTranslate(gaps.map { todo[$0] }, source: options.source) {
                for (k, i) in gaps.enumerated() { drafts[i] = fallback[k] }
            }
        }

        // 2. Apple Intelligence rewrites the page into natural English, using the
        //    drafts for meaning. "Offline model" and "Apple Translate" skip this.
        let rewrite = (options.engine == .automatic || options.engine == .appleIntelligence) && appleIntelligenceAvailable
        if rewrite {
            let hasDrafts = drafts.allSatisfy { $0 != nil }
            let rewritten = await modelTranslate(todo, drafts: hasDrafts ? drafts.map { $0 ?? "" } : nil,
                                                 context: context, options: options)
            for i in todo.indices {
                translated[i] = keepIfFaithful(rewritten[i], draft: drafts[i], source: todo[i]) ?? drafts[i]
            }
        } else {
            translated = drafts
        }

        // 3. Anything still missing: Apple Translate on its own.
        let missing = translated.indices.filter { translated[$0] == nil }
        if !missing.isEmpty {
            do {
                let fallback = try await appleTranslate(missing.map { todo[$0] }, source: options.source)
                for (k, i) in missing.enumerated() { translated[i] = fallback[k] }
            } catch {
                if translated.allSatisfy({ $0 == nil }) { throw error }
                note = (note.map { $0 + " " } ?? "") + "\(missing.count) line(s) couldn't be translated. " + error.localizedDescription
            }
        }
        for (k, i) in pending.enumerated() {
            output[i] = translated[k].map { polish($0, source: lines[i], options: options) }
                ?? MetaText.nameFallback(lines[i], language: options.source)
        }
        return Result(lines: output, note: note)
    }

    /// Rejects a rewrite that copies one of the style examples or balloons far
    /// beyond its draft (a sign the model invented content).
    static func keepIfFaithful(_ rewrite: String?, draft: String?, source: String) -> String? {
        guard let rewrite else { return nil }
        let lowered = rewrite.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let copied = StyleGuide.examples.contains {
            $0.english.lowercased() == lowered && MetaText.normalized($0.source) != MetaText.normalized(source)
        }
        if copied { return nil }
        if let draft, rewrite.count > draft.count * 5 / 2 + 24 { return nil }
        return rewrite
    }

    /// Final clean-up shared by every engine.
    static func polish(_ text: String, source: String, options: TranslationOptions) -> String {
        var t = finish(tidy(text), source: source)
        if !options.keepHonorifics {
            t = t.replacingOccurrences(of: "(?<=[A-Za-z])-(san|kun|chan|sama|dono|senpai|sensei|tan)\\b",
                                       with: "", options: [.regularExpression, .caseInsensitive])
        }
        return t
    }

    /// A whole line that is exactly a glossary entry ("ユウタ!" → "Yuta!").
    static func glossaryMatch(_ line: String, options: TranslationOptions) -> String? {
        let core = MetaText.normalized(line)
        var stripped = Substring(core), tail = ""
        while let last = stripped.last, "!！?？…‥".contains(last) {
            tail = (last == "?" || last == "？" ? "?" : (last == "…" || last == "‥" ? "..." : "!")) + tail
            stripped = stripped.dropLast()
        }
        guard let entry = options.glossary.first(where: { $0.source == String(stripped) }) else { return nil }
        return entry.english + tail
    }

    /// Credits whose name is in the glossary ("漫画 叶景太" → "Art: <your spelling>").
    static func creditWithGlossary(_ line: String, options: TranslationOptions) -> String? {
        guard let credit = MetaText.creditLabel(line, language: options.source),
              let entry = options.glossary.first(where: { $0.source == credit.1 }) else { return nil }
        return "\(credit.0): \(entry.english)"
    }

    // MARK: Apple Intelligence

    private static func instructions(_ options: TranslationOptions, withDrafts: Bool) -> String {
        let lang = options.source.displayName
        let honorifics = options.keepHonorifics
            ? "Keep honorifics such as -san, -kun, -chan, -sama and -senpai attached to names."
            : "Drop honorifics like -san and -kun; convey politeness or closeness through word choice instead."
        let subjects = options.source == .japanese
            ? "Japanese often leaves out the subject and object; work out who is speaking and who is meant from the other lines.\n"
            : ""
        return """
        You are a professional manga localizer. You turn \(lang) comic dialogue into natural, idiomatic English that reads the way an official English release would.
        Rules:
        - Write what a native English speaker would actually say in this situation, in each character's voice. Restructure freely and use contractions; never translate word for word.
        - Keep it punchy. Split a long sentence into two or three short ones. Add small words English needs ("That was…", "It's from…") when the Japanese leaves them implied.
        - Phone calls, greetings, thanks and set phrases get their natural English equivalents, not literal ones.
        - Keep leading or trailing "..." and "!?" where the original has them.
        - The lines are the speech bubbles and captions of one page, in reading order. A sentence may continue from one line into the next.
        - The \(lang) text came from OCR and may contain small recognition errors; infer what was meant.
        \(subjects)- Keep character and place names. \(honorifics)
        - Sound effects and interjections become short, natural English interjections.
        - Never move words from one line into another.
        - Short labels and titles get no final period.
        \(withDrafts ? "- After each line is a rough machine translation marked draft:. Use it to understand the meaning, then write your own natural English. The draft may be wrong or stiff.\n" : "")- Output exactly one line per input line, in the same order, formatted as [number] English text.
        - Never add notes, explanations, romanization or the original text.

        Style examples. These come from a different manga: they only show the tone and how freely to rewrite. Never reuse their wording.
        \(StyleGuide.examples.map { "\($0.source) → \($0.english)" }.joined(separator: "\n"))
        """
    }

    private static func prompt(_ lines: [String], drafts: [String]?, context: [String],
                               glossary: [GlossaryEntry] = []) -> String {
        var p = ""
        let page = lines.joined(separator: "\n")
        let terms = glossary.filter { page.contains($0.source) }
        if !terms.isEmpty {
            p += "Always translate these names and terms exactly like this:\n"
            p += terms.map { "\($0.source) = \($0.english)" }.joined(separator: "\n") + "\n\n"
        }
        if !context.isEmpty {
            p += "Earlier in this chapter (already translated, for context only):\n"
            p += context.joined(separator: "\n")
            p += "\n\n"
        }
        p += "Translate these speech bubbles from one page, listed in reading order:\n"
        for (i, line) in lines.enumerated() {
            p += "[\(i + 1)] \(line)\n"
            if let drafts, i < drafts.count { p += "    draft: \(drafts[i])\n" }
        }
        return p
    }

    private static func modelTranslate(_ lines: [String], drafts: [String]?, context: [String],
                                       options: TranslationOptions) async -> [String?] {
        func sub(_ idx: [Int]) -> [String]? { drafts.map { d in idx.map { d[$0] } } }
        if let whole = await modelAttempt(lines, drafts: drafts, context: context, options: options),
           whole.contains(where: { $0 != nil }) {
            // Retry any lines the model skipped, in a short batch of their own.
            let skipped = whole.indices.filter { whole[$0] == nil }
            guard !skipped.isEmpty, skipped.count < lines.count else { return whole }
            var merged = whole
            if let again = await modelAttempt(skipped.map { lines[$0] }, drafts: sub(skipped), context: [], options: options) {
                for (k, i) in skipped.enumerated() where k < again.count { merged[i] = again[k] }
            }
            for i in merged.indices.filter({ merged[$0] == nil }).prefix(6) {
                if let single = await modelAttempt([lines[i]], drafts: sub([i]), context: [], options: options),
                   let first = single.first {
                    merged[i] = first
                }
            }
            return merged
        }
        // The whole page failed (context too long, or a guardrail): go in small chunks.
        var out = [String?](repeating: nil, count: lines.count)
        var start = 0
        while start < lines.count {
            let end = min(start + 5, lines.count)
            if let part = await modelAttempt(Array(lines[start..<end]), drafts: sub(Array(start..<end)), context: [],
                                             options: options) {
                for (k, v) in part.enumerated() { out[start + k] = v }
            }
            start = end
        }
        return out
    }

    private static func modelAttempt(_ lines: [String], drafts: [String]?, context: [String],
                                     options: TranslationOptions) async -> [String?]? {
        let model = SystemLanguageModel(guardrails: .permissiveContentTransformations)
        let session = LanguageModelSession(model: model, instructions: instructions(options, withDrafts: drafts != nil))
        do {
            let response = try await session.respond(to: prompt(lines, drafts: drafts, context: context,
                                                                glossary: options.glossary),
                                                     options: GenerationOptions(temperature: 0.3))
            return parse(response.content, count: lines.count, source: options.source)
        } catch {
            return nil
        }
    }

    /// Reads "[n] text" lines; drops anything that still contains source script.
    static func parse(_ response: String, count: Int, source: SourceLanguage) -> [String?] {
        var out = [String?](repeating: nil, count: count)
        for raw in response.split(whereSeparator: \.isNewline) {
            var line = raw.trimmingCharacters(in: .whitespaces)
            while line.hasPrefix("-") || line.hasPrefix("*") { line = String(line.dropFirst()).trimmingCharacters(in: .whitespaces) }
            guard line.hasPrefix("["), let close = line.firstIndex(of: "]") else { continue }
            let number = line[line.index(after: line.startIndex)..<close].trimmingCharacters(in: .whitespaces)
            guard let n = Int(number), n >= 1, n <= count else { continue }
            var text = String(line[line.index(after: close)...]).trimmingCharacters(in: .whitespaces)
            if text.hasPrefix(":") { text = String(text.dropFirst()).trimmingCharacters(in: .whitespaces) }
            if text.lowercased().hasPrefix("draft:") { text = String(text.dropFirst(6)).trimmingCharacters(in: .whitespaces) }
            guard !text.isEmpty, source.scriptCount(text) == 0 else { continue }
            out[n - 1] = text
        }
        return out
    }

    // MARK: Apple Translate

    static func languagePackInstalled(_ source: SourceLanguage) async -> Bool {
        await LanguageAvailability().status(from: source.localeLanguage, to: Locale.Language(identifier: "en")) == .installed
    }

    static func appleTranslate(_ lines: [String], source: SourceLanguage) async throws -> [String] {
        var labels: [String?] = []
        var texts: [String] = []
        for line in lines {
            if let credit = MetaText.creditLabel(line, language: source) {
                labels.append(credit.0); texts.append(credit.1)
            } else {
                labels.append(nil); texts.append(line)
            }
        }
        let translated = try await appleTranslateRaw(texts, source: source)
        return translated.enumerated().map { i, t in labels[i].map { "\($0): \(t)" } ?? t }
    }

    private static func appleTranslateRaw(_ lines: [String], source: SourceLanguage) async throws -> [String] {
        let target = Locale.Language(identifier: "en")
        let status = await LanguageAvailability().status(from: source.localeLanguage, to: target)
        guard status == .installed else { throw TranslationEngineError.languagePackMissing(source.displayName) }
        let session: TranslationSession
        if #available(iOS 26.4, *) {
            session = TranslationSession(installedSource: source.localeLanguage, target: target, preferredStrategy: .highFidelity)
        } else {
            session = TranslationSession(installedSource: source.localeLanguage, target: target)
        }
        let requests = lines.enumerated().map { TranslationSession.Request(sourceText: $0.element, clientIdentifier: String($0.offset)) }
        let responses = try await session.translations(from: requests)
        var out = lines
        for response in responses {
            if let id = response.clientIdentifier, let i = Int(id), i >= 0, i < out.count { out[i] = response.targetText }
        }
        return out
    }

    // MARK: Helpers

    /// "！？", "…" and friends don't need a translator.
    static func punctuationOnly(_ text: String, language: SourceLanguage) -> String? {
        guard language.scriptCount(text) == 0 else { return nil }
        let map: [Character: String] = ["！": "!", "？": "?", "…": "...", "‥": "..", "・": ".", "。": ".", "、": ",",
                                        "ー": "—", "〜": "~", "～": "~", "!": "!", "?": "?", ".": "."]
        var out = ""
        for ch in text where !ch.isWhitespace {
            guard let m = map[ch] else { return nil }
            out += m
        }
        return out.isEmpty ? nil : out
    }

    /// Short labels ("Story: Ta-chan") read better without the period small
    /// models like to add, unless the original ended its sentence.
    static func finish(_ text: String, source: String) -> String {
        let english = text.split(separator: " ", omittingEmptySubsequences: false).map { word -> String in
            guard let first = word.first, first.isUppercase, word.count > 3 else { return String(word) }
            return String(word).replacingOccurrences(of: "uu", with: "u").replacingOccurrences(of: "UU", with: "U")
        }.joined(separator: " ")
        let words = english.split(separator: " ").count
        let sourceEndsSentence = source.hasSuffix("。") || source.hasSuffix("．")
        if words <= 5, english.hasSuffix("."), !english.hasSuffix(".."), !sourceEndsSentence {
            return String(english.dropLast())
        }
        return english
    }

    static func tidy(_ s: String) -> String {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        let quotes: Set<Character> = ["\"", "“", "”", "「", "」", "『", "』"]
        while let f = t.first, quotes.contains(f), let l = t.last, quotes.contains(l), t.count > 1 {
            t = String(t.dropFirst().dropLast()).trimmingCharacters(in: .whitespaces)
        }
        return t.split(whereSeparator: { $0 == " " || $0 == "\n" }).joined(separator: " ")
    }
}


/// Chapter numbers, credits and stock publishing phrases have fixed English
/// equivalents, so they never depend on the translator.
enum MetaText {
    static func normalized(_ text: String) -> String {
        let fullWidthDigits = Array("０１２３４５６７８９")
        let strip: Set<Character> = ["〈", "〉", "<", ">", "《", "》", "【", "】", "(", ")", "（", "）", "「", "」", "『", "』", "［", "］", "[", "]", " ", "　", "・"]
        var out = ""
        for ch in text where !strip.contains(ch) {
            if let d = fullWidthDigits.firstIndex(of: ch) { out.append(Character(String(d))) } else { out.append(ch) }
        }
        return out
    }

    static func direct(_ text: String, language: SourceLanguage) -> String? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        var bangs = ""
        var core = Substring(t)
        while let last = core.last, "!！?？".contains(last) {
            bangs = (last == "?" || last == "？" ? "?" : "!") + bangs
            core = core.dropLast()
        }
        let c = String(core)
        // OCR often turns the decorative brackets around "第28話" into stray kana.
        if let n = number(in: c, pattern: "第([0-9]+)話"), c.count <= "第\(n)話".count + 2 { return "Chapter \(n)" + bangs }
        if let n = number(in: c, pattern: "^第([0-9]+)巻$") { return "Volume \(n)" + bangs }
        if let n = number(in: c, pattern: "^(?:最新)?(?:単行本|コミックス|コミック)(?:第)?([0-9]+)巻(?:好評発売中|大好評発売中|発売中)?$") {
            return (c.hasSuffix("発売中") ? "Volume \(n) on sale now" : "Volume \(n)") + bangs
        }
        if c.hasPrefix("次号") {
            if let date = releaseDate(in: c) { return "Next issue on sale \(date)" + bangs }
            return "Next issue" + (bangs.isEmpty ? "" : bangs)
        }
        if c.hasSuffix("発売"), let date = releaseDate(in: c), c.count <= 20 { return "On sale \(date)" + bangs }
        switch c {
        case "大好評発売中", "好評発売中", "絶賛発売中", "発売中": return "On sale now" + (bangs.isEmpty ? "!" : bangs)
        case "つづく", "続く", "次回につづく", "次回に続く": return "To be continued" + bangs
        case "完", "終", "おわり", "終わり": return "The End"
        default: return nil
        }
    }

    /// "2026年11月19日(木)" → "November 19, 2026".
    static func releaseDate(in text: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: "([0-9]{4})年([0-9]{1,2})月([0-9]{1,2})日"),
              let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let yr = Range(m.range(at: 1), in: text), let mr = Range(m.range(at: 2), in: text),
              let dr = Range(m.range(at: 3), in: text),
              let month = Int(text[mr]), (1...12).contains(month), let day = Int(text[dr]) else { return nil }
        let months = ["January", "February", "March", "April", "May", "June", "July", "August",
                      "September", "October", "November", "December"]
        return "\(months[month - 1]) \(day), \(text[yr])"
    }

    /// Short gasps, laughs and reactions the small model tends to get wrong
    /// ("ハァ… ハァ…" is panting, not "Wow, wow"). Whole lines only.
    static func interjection(_ text: String, language: SourceLanguage) -> String? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        guard !t.isEmpty, t.count <= 14 else { return nil }
        let table: [String: String] = [
            "はぁ": "Huff", "はあ": "Huff", "はー": "Haah", "ふう": "Phew", "ふぅ": "Phew", "ふー": "Phew",
            "は": "Ha", "はは": "Haha", "ははは": "Hahaha", "あはは": "Ahaha", "あははは": "Ahaha",
            "ふふ": "Heh heh", "ふふふ": "Heh heh heh", "へへ": "Heh heh", "えへへ": "Hehe",
            "え": "Huh", "えっ": "Huh", "ええ": "Yeah", "えー": "Ehh", "ええー": "Whaaat",
            "あ": "Ah", "あっ": "Ah", "ああ": "Ahh", "あー": "Ahh",
            "うわ": "Whoa", "うわっ": "Whoa", "うわあ": "Whoa", "わあ": "Wow", "わっ": "Whoa",
            "ちっ": "Tch", "くっ": "Ngh", "ぐっ": "Ugh", "うっ": "Ugh", "ぐあ": "Gah", "ぐわ": "Gah",
            "ひっ": "Eek", "ひい": "Eeek", "ひー": "Hoo", "おお": "Ooh", "おー": "Ooh", "おぉ": "Ooh",
            "よし": "All right", "よしっ": "All right", "うん": "Yeah", "はい": "Yes", "いや": "No",
            "なに": "What", "なにっ": "What", "何": "What", "何っ": "What", "ん": "Hm", "んっ": "Hm",
            "へえ": "Huh", "へー": "Huh", "ほう": "Oh", "む": "Hmm", "むう": "Hmm"
        ]
        let separators = CharacterSet(charactersIn: "…‥、。,. ")
        let pieces = t.components(separatedBy: separators).filter { !$0.isEmpty }
        guard !pieces.isEmpty else { return nil }
        var words: [String] = []
        for piece in pieces {
            var core = Substring(piece), tail = ""
            while let last = core.last, "!！?？~〜".contains(last) {
                tail = (last == "?" || last == "？" ? "?" : (last == "~" || last == "〜" ? "" : "!")) + tail
                core = core.dropLast()
            }
            // Katakana → hiragana so "ハァ" and "はぁ" share one entry.
            let key = String(core).applyingTransform(.hiraganaToKatakana, reverse: true) ?? String(core)
            guard let english = table[key] else { return nil }
            words.append((words.isEmpty ? english : english.prefix(1).lowercased() + english.dropFirst()) + tail)
        }
        let trailing = text.hasSuffix("…") || text.hasSuffix("‥") || text.hasSuffix("...") ? "..." : ""
        let joiner = text.contains("…") || text.contains("‥") ? "... " : " "
        let joined = words.joined(separator: joiner)
        let last = joined.last.map { "!?".contains($0) } ?? false
        return joined + (last ? "" : trailing)
    }

    /// "原作 たーちゃん" → "Story: Ta-chan", without a translator.
    static func credit(_ text: String, language: SourceLanguage) -> String? {
        guard let pair = creditLabel(text, language: language), let romanized = romanizeName(pair.1) else { return nil }
        return "\(pair.0): \(romanized)"
    }

    /// A short all-kanji line (an author's name in credits) that no translator
    /// handled is written in romaji rather than left in Japanese.
    static func nameFallback(_ text: String, language: SourceLanguage) -> String? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        if let credit = credit(t, language: language) { return credit }
        let kanjiOnly = !t.isEmpty && t.count <= 5 && t.unicodeScalars.allSatisfy { (0x4E00...0x9FFF).contains($0.value) }
        return kanjiOnly ? romanizeName(t) : nil
    }

    /// Japanese name → romaji using the system's Japanese tokenizer, e.g.
    /// たーちゃん → Ta-chan. Returns nil if it can't produce plain Latin text.
    static func romanizeName(_ name: String) -> String? {
        let cf = name as CFString
        let length = CFStringGetLength(cf)
        guard length > 0, length <= 20 else { return nil }
        guard let tokenizer = CFStringTokenizerCreate(nil, cf, CFRange(location: 0, length: length),
                                                      kCFStringTokenizerUnitWord, Locale(identifier: "ja") as CFLocale)
        else { return nil }
        var parts: [String] = []
        while !CFStringTokenizerAdvanceToNextToken(tokenizer).isEmpty {
            guard let latin = CFStringTokenizerCopyCurrentTokenAttribute(tokenizer, kCFStringTokenizerAttributeLatinTranscription) as? String
            else { continue }
            var plain = latin.applyingTransform(.stripDiacritics, reverse: false) ?? latin
            plain = plain.filter { $0.isLetter || $0 == " " }
            if !plain.isEmpty { parts.append(plain.lowercased()) }
        }
        guard !parts.isEmpty else { return nil }
        let honorifics: Set<String> = ["chan", "san", "kun", "sama", "sensei", "senpai", "tan"]
        var words: [String] = []
        for part in parts {
            if honorifics.contains(part), let last = words.popLast() {
                words.append(last + "-" + part)
            } else {
                words.append(part.prefix(1).uppercased() + part.dropFirst())
            }
        }
        let result = words.joined(separator: " ")
        guard result.unicodeScalars.allSatisfy({ $0.isASCII }) else { return nil }
        return result
    }

    /// "原作 たーちゃん" → ("Story", "たーちゃん").
    static func creditLabel(_ text: String, language: SourceLanguage) -> (String, String)? {
        guard language == .japanese else { return nil }
        let t = normalized(text)
        let labels: [(String, String)] = [("キャラクター原案", "Character design"), ("キャラクターデザイン", "Character design"),
                                          ("原作", "Story"), ("原案", "Original concept"), ("漫画", "Art"),
                                          ("作画", "Art"), ("構成", "Composition"), ("脚本", "Script")]
        for (jp, en) in labels where t.hasPrefix(jp) {
            let rest = String(t.dropFirst(jp.count)).trimmingCharacters(in: CharacterSet(charactersIn: ":：/／ "))
            if !rest.isEmpty { return (en, rest) }
        }
        return nil
    }

    private static func number(in text: String, pattern: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              m.numberOfRanges > 1, let r = Range(m.range(at: 1), in: text) else { return nil }
        return String(text[r])
    }
}


/// Original example pairs showing how freely to localize: implied subjects
/// spelled out, long lines split, set phrases replaced by English ones.
enum StyleGuide {
    struct Example {
        let source: String
        let english: String
    }

    static let examples: [Example] = [
        Example(source: "…なるほどな", english: "...I see."),
        Example(source: "はい もしもし 佐藤です", english: "Hello, Sato speaking."),
        Example(source: "了解です！お疲れ様でした！", english: "Got it! Thanks for all your hard work!"),
        Example(source: "母さんから", english: "It's from my mom."),
        Example(source: "暇だから適当に魔物狩ってレベル上げしてるだけだよ",
                english: "I was bored, so I've just been hunting monsters to level up. That's all."),
        Example(source: "別にお前のためにやったわけじゃねーし", english: "It's not like I did it for you or anything."),
        Example(source: "ならばここで終わりにしてやる", english: "Then I'll end this right here."),
        Example(source: "ちょ、待って待って！", english: "W-Wait, wait!"),
        Example(source: "マジかよ…", english: "You've gotta be kidding me...")
    ]
}
