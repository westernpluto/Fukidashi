import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

/// An RGBA bitmap the pipeline edits in place: pixels are cleaned directly in
/// memory and the English lettering is drawn into the same CGContext.
/// Coordinates used by the pipeline are pixels with a top-left origin.
final class PixelCanvas {
    let width: Int
    let height: Int
    let context: CGContext
    let bytesPerRow: Int
    let pixels: UnsafeMutablePointer<UInt8>

    init?(image: CGImage) {
        width = image.width
        height = image.height
        guard width > 0, height > 0,
              let space = CGColorSpace(name: CGColorSpace.sRGB),
              let ctx = CGContext(data: nil, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0, space: space,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        else { return nil }
        ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
        ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))
        ctx.interpolationQuality = .high
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        guard let data = ctx.data else { return nil }
        context = ctx
        bytesPerRow = ctx.bytesPerRow
        pixels = data.bindMemory(to: UInt8.self, capacity: ctx.bytesPerRow * height)
    }

    /// Row 0 of the bitmap memory is the top row of the image.
    @inline(__always) func offset(_ x: Int, _ y: Int) -> Int { y * bytesPerRow + x * 4 }

    @inline(__always) func rgb(_ x: Int, _ y: Int) -> RGB {
        let o = offset(x, y)
        return RGB(r: pixels[o], g: pixels[o + 1], b: pixels[o + 2])
    }

    @inline(__always) func set(_ x: Int, _ y: Int, _ c: RGB) {
        let o = offset(x, y)
        pixels[o] = c.r; pixels[o + 1] = c.g; pixels[o + 2] = c.b; pixels[o + 3] = 255
    }

    func grayscale() -> [UInt8] {
        var out = [UInt8](repeating: 255, count: width * height)
        for y in 0..<height {
            let row = y * bytesPerRow
            let outRow = y * width
            for x in 0..<width {
                let o = row + x * 4
                let l = (Int(pixels[o]) * 299 + Int(pixels[o + 1]) * 587 + Int(pixels[o + 2]) * 114) / 1000
                out[outRow + x] = UInt8(l)
            }
        }
        return out
    }

    func makeImage() -> CGImage? { context.makeImage() }
}

struct RGB: Equatable {
    var r: UInt8
    var g: UInt8
    var b: UInt8
    static let white = RGB(r: 255, g: 255, b: 255)
    static let black = RGB(r: 0, g: 0, b: 0)
    var luma: Int { (Int(r) * 299 + Int(g) * 587 + Int(b) * 114) / 1000 }
    var cgColor: CGColor {
        CGColor(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: 1)
    }

    static func median(_ colors: [RGB]) -> RGB {
        guard !colors.isEmpty else { return .white }
        func med(_ v: [UInt8]) -> UInt8 { v.sorted()[v.count / 2] }
        return RGB(r: med(colors.map(\.r)), g: med(colors.map(\.g)), b: med(colors.map(\.b)))
    }
}

/// Loading and saving images with ImageIO (handles JPEG, PNG, WebP, HEIC, GIF).
enum ImageFiles {
    /// Loads an image upright (EXIF orientation applied), capped at `maxPixels`.
    static func load(_ url: URL, maxPixels: Int = 12_000_000) -> CGImage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
        let w = (props?[kCGImagePropertyPixelWidth] as? Int) ?? 0
        let h = (props?[kCGImagePropertyPixelHeight] as? Int) ?? 0
        guard w > 0, h > 0 else { return CGImageSourceCreateImageAtIndex(source, 0, nil) }
        var maxDim = Double(max(w, h))
        if w * h > maxPixels { maxDim *= (Double(maxPixels) / Double(w * h)).squareRoot() }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: max(1, Int(maxDim))
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    /// Fast downsampled load for display and thumbnails.
    static func thumbnail(_ url: URL, maxDimension: Int) -> CGImage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: max(1, maxDimension)
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    @discardableResult
    static func writeJPEG(_ image: CGImage, to url: URL, quality: Double = 0.92) -> Bool {
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)
        else { return false }
        CGImageDestinationAddImage(dest, image, [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        return CGImageDestinationFinalize(dest)
    }

    /// Picks a file extension from the first bytes of image data.
    static func fileExtension(for data: Data) -> String? {
        let b = [UInt8](data.prefix(16))
        guard b.count >= 12 else { return nil }
        if b[0] == 0xFF, b[1] == 0xD8 { return "jpg" }
        if b[0] == 0x89, b[1] == 0x50, b[2] == 0x4E, b[3] == 0x47 { return "png" }
        if b[0] == 0x47, b[1] == 0x49, b[2] == 0x46 { return "gif" }
        if b[0] == 0x52, b[1] == 0x49, b[2] == 0x46, b[3] == 0x46,
           b[8] == 0x57, b[9] == 0x45, b[10] == 0x42, b[11] == 0x50 { return "webp" }
        if b[4] == 0x66, b[5] == 0x74, b[6] == 0x79, b[7] == 0x70 { return "heic" }
        if b[0] == 0x42, b[1] == 0x4D { return "bmp" }
        return nil
    }

    static let imageExtensions: Set<String> = ["jpg", "jpeg", "png", "webp", "gif", "heic", "heif", "bmp", "tif", "tiff", "avif"]
}
