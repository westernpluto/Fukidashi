import Foundation
import HuggingFace
import MLXHuggingFace
import MLXLLM
import MLXLMCommon
import Tokenizers

/// A dedicated translation model that runs on the phone with MLX.
enum OfflineModelChoice: String, CaseIterable, Identifiable, Codable, Sendable {
    case hyMT2Small, hyMT2Large

    var id: String { rawValue }

    /// Hugging Face repository with MLX weights.
    var repo: String {
        switch self {
        case .hyMT2Small: return "translate-studio/Hunyuan-MT2-1.8B-8bit-MLX"
        case .hyMT2Large: return "mlx-community/Hy-MT2-7B-4bit"
        }
    }

    var label: String {
        switch self {
        case .hyMT2Small: return "Hy-MT2 1.8B · about 1.9 GB"
        case .hyMT2Large: return "Hy-MT2 7B · about 4.3 GB"
        }
    }

    var note: String {
        switch self {
        case .hyMT2Small: return "Fast, good quality. Recommended."
        case .hyMT2Large: return "Best quality, slower. Uses a lot of memory."
        }
    }
}

/// Where downloaded models live: Application Support, so iOS doesn't purge them.
enum OfflineModelFiles {
    static var root: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("OfflineModels", isDirectory: true)
    }

    static func directory(for model: OfflineModelChoice) -> URL {
        root.appendingPathComponent(model.repo.replacingOccurrences(of: "/", with: "--"), isDirectory: true)
    }

    static func isInstalled(_ model: OfflineModelChoice) -> Bool {
        FileManager.default.fileExists(atPath: directory(for: model).appendingPathComponent(".complete").path)
    }

    static func delete(_ model: OfflineModelChoice) {
        try? FileManager.default.removeItem(at: directory(for: model))
    }
}

/// Downloads a model's files once, with progress, for the Settings screen.
@MainActor
final class OfflineModelDownloader: ObservableObject {
    static let shared = OfflineModelDownloader()

    enum State: Equatable {
        case idle
        case downloading(Double)
        case failed(String)
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var revision = 0
    private var task: Task<Void, Never>?

    func download(_ model: OfflineModelChoice) {
        guard task == nil else { return }
        state = .downloading(0)
        task = Task { [weak self] in
            do {
                try await Self.fetch(model) { fraction in
                    Task { @MainActor in OfflineModelDownloader.shared.state = .downloading(fraction) }
                }
                self?.state = .idle
            } catch is CancellationError {
                self?.state = .idle
            } catch {
                self?.state = .failed(error.localizedDescription)
            }
            self?.task = nil
            self?.revision += 1
        }
    }

    func cancel() {
        task?.cancel()
    }

    func delete(_ model: OfflineModelChoice) {
        OfflineModelFiles.delete(model)
        Task { await OfflineTranslator.shared.unload() }
        revision += 1
    }

    private struct ModelInfo: Decodable {
        struct Sibling: Decodable {
            let rfilename: String
            let size: Int64?
        }
        let siblings: [Sibling]
    }

    enum DownloadError: LocalizedError {
        case badResponse(Int)
        case noWeights
        var errorDescription: String? {
            switch self {
            case .badResponse(let code): return "The download server answered with error \(code). Try again later."
            case .noWeights: return "That model's files weren't found."
            }
        }
    }

    nonisolated private static func fetch(_ model: OfflineModelChoice,
                                          progress: @escaping @Sendable (Double) -> Void) async throws {
        let api = URL(string: "https://huggingface.co/api/models/\(model.repo)?blobs=true")!
        let (data, response) = try await URLSession.shared.data(from: api)
        if let http = response as? HTTPURLResponse, http.statusCode != 200 { throw DownloadError.badResponse(http.statusCode) }
        let info = try JSONDecoder().decode(ModelInfo.self, from: data)
        let wanted = info.siblings.filter { s in
            let name = s.rfilename.lowercased()
            return name.hasSuffix(".json") || name.hasSuffix(".safetensors") || name.hasSuffix(".jinja")
                || name.hasSuffix(".txt") || name.hasSuffix(".model") || name.hasSuffix(".tiktoken")
        }
        guard wanted.contains(where: { $0.rfilename.hasSuffix(".safetensors") }) else { throw DownloadError.noWeights }

        let folder = OfflineModelFiles.directory(for: model)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        var mutableFolder = folder
        try? mutableFolder.setResourceValues(values)

        let total = max(1, wanted.reduce(Int64(0)) { $0 + ($1.size ?? 0) })
        var done: Int64 = 0
        for file in wanted {
            try Task.checkCancellation()
            let destination = folder.appendingPathComponent(file.rfilename)
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            if let size = file.size, let existing = try? FileManager.default.attributesOfItem(atPath: destination.path)[.size] as? Int64,
               existing == size {
                done += size
                progress(Double(done) / Double(total))
                continue
            }
            let path = file.rfilename.split(separator: "/").map {
                String($0).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String($0)
            }.joined(separator: "/")
            let url = URL(string: "https://huggingface.co/\(model.repo)/resolve/main/\(path)")!
            let base = done
            try await FileDownloader(destination: destination) { written in
                progress(Double(base + written) / Double(total))
            }.run(url)
            done += file.size ?? 0
        }
        try Data().write(to: folder.appendingPathComponent(".complete"))
        progress(1)
    }
}

/// One file download with byte progress (URLSession delegate based, suited to
/// multi-gigabyte files).
final class FileDownloader: NSObject, URLSessionDownloadDelegate {
    private let destination: URL
    private let onProgress: @Sendable (Int64) -> Void
    private var continuation: CheckedContinuation<Void, Error>?
    private var session: URLSession?

    init(destination: URL, onProgress: @escaping @Sendable (Int64) -> Void) {
        self.destination = destination
        self.onProgress = onProgress
    }

    func run(_ url: URL) async throws {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                self.continuation = continuation
                let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
                self.session = session
                session.downloadTask(with: url).resume()
            }
        } onCancel: {
            self.session?.invalidateAndCancel()
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        onProgress(totalBytesWritten)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let status = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 200
        do {
            guard status == 200 else { throw OfflineModelDownloader.DownloadError.badResponse(status) }
            try? FileManager.default.removeItem(at: destination)
            try FileManager.default.moveItem(at: location, to: destination)
            continuation?.resume()
        } catch {
            continuation?.resume(throwing: error)
        }
        continuation = nil
        session.finishTasksAndInvalidate()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error {
            continuation?.resume(throwing: error)
            continuation = nil
        }
        session.finishTasksAndInvalidate()
    }
}

/// Runs the downloaded model. Kept loaded between pages.
actor OfflineTranslator {
    static let shared = OfflineTranslator()

    private var container: ModelContainer?
    private var loaded: OfflineModelChoice?

    func unload() {
        container = nil
        loaded = nil
    }

    private func load(_ model: OfflineModelChoice) async throws -> ModelContainer {
        if let container, loaded == model { return container }
        container = nil
        guard OfflineModelFiles.isInstalled(model) else { throw TranslationEngineError.offlineModelMissing }
        // A local folder: the loader reads it directly, no network involved.
        let configuration = ModelConfiguration(directory: OfflineModelFiles.directory(for: model))
        let loadedContainer = try await #huggingFaceLoadModelContainer(configuration: configuration)
        container = loadedContainer
        loaded = model
        return loadedContainer
    }

    /// Translates a page's lines. Tries the whole page in one pass (better
    /// context); if the model doesn't keep the line breaks, goes line by line.
    func translate(_ lines: [String], context: [String], glossary: [GlossaryEntry],
                   model: OfflineModelChoice) async throws -> [String?] {
        guard !lines.isEmpty else { return [] }
        let container = try await load(model)
        let pageText = lines.joined(separator: "\n")
        let terms = glossary.filter { !$0.source.isEmpty && pageText.contains($0.source) }

        let delimiter = " ||| "
        let whole = try await run(container, prompt: Self.prompt(
            text: lines.joined(separator: delimiter), terms: terms, background: context,
            delimiterNote: lines.count > 1))
        let parts = whole.components(separatedBy: "|||").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        if parts.count == lines.count, !parts.contains(where: \.isEmpty) {
            return parts
        }

        // One bubble at a time, with the rest of the page as background.
        var out = [String?](repeating: nil, count: lines.count)
        for (i, line) in lines.enumerated() {
            try Task.checkCancellation()
            let background = context + ["(This page) " + lines.joined(separator: " / ")]
            let text = try await run(container, prompt: Self.prompt(text: line, terms: terms, background: background,
                                                                    delimiterNote: false))
            let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if !cleaned.isEmpty { out[i] = cleaned }
        }
        return out
    }

    private func run(_ container: ModelContainer, prompt: String) async throws -> String {
        // Tencent's recommended sampling for Hy-MT2, slightly cooler for consistency.
        let parameters = GenerateParameters(maxTokens: 1024, temperature: 0.5, topP: 0.6, topK: 20,
                                            repetitionPenalty: 1.05)
        let session = ChatSession(container, generateParameters: parameters)
        return try await session.respond(to: prompt)
    }

    /// Hy-MT2's documented prompt pieces: terminology ("X translates to Y"),
    /// background information, delimiter retention, and the base instruction.
    static func prompt(text: String, terms: [GlossaryEntry], background: [String], delimiterNote: Bool) -> String {
        var p = ""
        if !terms.isEmpty {
            p += "Refer to the following translations:\n"
            p += terms.map { "\($0.source) translates to \($0.english)" }.joined(separator: "\n")
            p += "\n\n"
        }
        if !background.isEmpty {
            p += "[Background Information]\n" + background.joined(separator: "\n") + "\n\n"
            p += "Please translate the following text into English, taking the provided background information into consideration. "
        } else {
            p += "Translate the following text into English. "
        }
        p += "Note that the translation style must strictly conform to [natural spoken English as in an official English manga release: contractions, short punchy sentences, each character's own voice]. "
        if delimiterNote {
            p += "Each part separated by ||| is a separate speech bubble. You must retain the exact same number of delimiters in the translation. "
        }
        p += "Note that you should only output the translated result without any additional explanation:\n\n"
        p += text
        return p
    }
}
