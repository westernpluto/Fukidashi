import CoreGraphics
import Foundation

/// A boolean mask over a rectangle of the page (local coordinates).
struct LocalMask {
    let x0: Int
    let y0: Int
    let width: Int
    let height: Int
    var bits: [Bool]

    init(x0: Int, y0: Int, width: Int, height: Int, bits: [Bool]) {
        self.x0 = x0; self.y0 = y0; self.width = width; self.height = height; self.bits = bits
    }

    init(x0: Int, y0: Int, width: Int, height: Int, fill: Bool) {
        self.init(x0: x0, y0: y0, width: width, height: height,
                  bits: [Bool](repeating: fill, count: width * height))
    }

    @inline(__always) subscript(x: Int, y: Int) -> Bool { bits[y * width + x] }

    /// Page-coordinate lookup.
    @inline(__always) func contains(_ gx: Int, _ gy: Int) -> Bool {
        let x = gx - x0, y = gy - y0
        guard x >= 0, y >= 0, x < width, y < height else { return false }
        return bits[y * width + x]
    }

    var frame: CGRect { CGRect(x: x0, y: y0, width: width, height: height) }
}

/// A speech bubble (or caption box) found on the page.
struct BubbleCandidate {
    /// The bubble's background pixels.
    var component: LocalMask
    /// Enclosed non-background pixels: the original lettering.
    var holes: LocalMask
    /// component ∪ holes: the whole interior of the bubble.
    var filled: LocalMask
    /// Where the original text sits, in page pixels.
    var textRect: CGRect
    /// Approximate size of one source glyph, in page pixels.
    var glyph: CGFloat
    /// True for dark bubbles with light text.
    var isDark: Bool
    var area: Int { filled.bits.reduce(0) { $1 ? $0 + 1 : $0 } }
    var center: CGPoint { CGPoint(x: filled.frame.midX, y: filled.frame.midY) }
}

/// Finds speech bubbles without a learned model: a bubble is a large, compact
/// region of near-uniform background that fully encloses many small marks
/// (the lettering). Each result is later confirmed by OCR, so false positives
/// that contain no text are dropped.
enum BubbleDetector {
    struct Component {
        var id: Int32
        var area: Int
        var minX: Int
        var minY: Int
        var maxX: Int
        var maxY: Int
        var width: Int { maxX - minX + 1 }
        var height: Int { maxY - minY + 1 }
    }

    static func detect(gray: [UInt8], width: Int, height: Int) -> [BubbleCandidate] {
        var found = detect(gray: gray, width: width, height: height, dark: false)
        found += detect(gray: gray, width: width, height: height, dark: true)

        // A panel interior can look like a giant bubble that contains real bubbles;
        // keep the innermost regions only.
        var keep: [BubbleCandidate] = []
        for (i, a) in found.enumerated() {
            let aArea = a.filled.width * a.filled.height
            var containsOther = false
            // Same polarity only: a bold dark glyph inside a white caption box can
            // look like a tiny dark "bubble", and must not knock out the box.
            for (j, b) in found.enumerated() where i != j && b.isDark == a.isDark {
                let bArea = b.filled.width * b.filled.height
                if bArea < aArea && a.filled.contains(Int(b.center.x), Int(b.center.y)) {
                    containsOther = true
                    break
                }
            }
            if !containsOther { keep.append(a) }
        }
        keep.sort { $0.filled.width * $0.filled.height > $1.filled.width * $1.filled.height }
        return Array(keep.prefix(80))
    }

    private static func detect(gray: [UInt8], width: Int, height: Int, dark: Bool) -> [BubbleCandidate] {
        let pageArea = width * height
        let mask: [Bool] = dark ? gray.map { $0 <= 55 } : gray.map { $0 >= 200 }
        let (labels, comps) = label(mask, width: width, height: height, eightConnected: false)
        let minArea = max(600, Int(Double(pageArea) * 0.0008))
        let maxArea = Int(Double(pageArea) * 0.20)
        var out: [BubbleCandidate] = []

        for c in comps {
            let bw = c.width, bh = c.height
            guard c.area >= minArea, c.area <= maxArea, bw >= 24, bh >= 24,
                  Double(c.area) / Double(bw * bh) >= 0.25 else { continue }

            var local = [Bool](repeating: false, count: bw * bh)
            for y in 0..<bh {
                let row = (c.minY + y) * width + c.minX
                for x in 0..<bw where labels[row + x] == c.id { local[y * bw + x] = true }
            }

            // Flood "outside" through non-bubble pixels from the box edges; whatever
            // non-bubble pixels remain are enclosed by the bubble: its lettering.
            var outside = [Bool](repeating: false, count: bw * bh)
            var stack: [Int] = []
            stack.reserveCapacity(1024)
            func seed(_ i: Int) {
                if !local[i] && !outside[i] { outside[i] = true; stack.append(i) }
            }
            for x in 0..<bw { seed(x); seed((bh - 1) * bw + x) }
            for y in 0..<bh { seed(y * bw); seed(y * bw + bw - 1) }
            while let p = stack.popLast() {
                let y = p / bw, x = p - y * bw
                if x > 0 { seed(p - 1) }
                if x < bw - 1 { seed(p + 1) }
                if y > 0 { seed(p - bw) }
                if y < bh - 1 { seed(p + bw) }
            }

            var holes = [Bool](repeating: false, count: bw * bh)
            var filled = [Bool](repeating: false, count: bw * bh)
            var filledArea = 0, holeArea = 0
            var tMinX = Int.max, tMinY = Int.max, tMaxX = -1, tMaxY = -1
            for i in 0..<(bw * bh) {
                let isHole = !local[i] && !outside[i]
                if isHole {
                    holes[i] = true
                    holeArea += 1
                    let y = i / bw, x = i - y * bw
                    tMinX = min(tMinX, x); tMaxX = max(tMaxX, x)
                    tMinY = min(tMinY, y); tMaxY = max(tMaxY, y)
                }
                if isHole || local[i] { filled[i] = true; filledArea += 1 }
            }
            guard filledArea > 0, holeArea > 0 else { continue }
            // Bubbles are compact shapes (ellipses, boxes, clouds).
            guard Double(filledArea) / Double(bw * bh) >= 0.45 else { continue }
            let ratio = Double(holeArea) / Double(filledArea)
            guard ratio >= 0.004, ratio <= 0.45 else { continue }

            // Lettering is many small marks; a big enclosed object means this is art.
            let (_, holeComps) = label(holes, width: bw, height: bh, eightConnected: true)
            guard !holeComps.isEmpty else { continue }
            let hasBigObject = holeComps.contains {
                (Double($0.width) > 0.45 * Double(bw) && Double($0.height) > 0.45 * Double(bh))
                    || Double($0.area) > 0.18 * Double(filledArea)
            }
            guard !hasBigObject else { continue }

            let glyph = estimateGlyphSize(holes: holes, width: bw, height: bh, components: holeComps)
            let textRect = CGRect(x: c.minX + tMinX, y: c.minY + tMinY,
                                  width: tMaxX - tMinX + 1, height: tMaxY - tMinY + 1)
            out.append(BubbleCandidate(
                component: LocalMask(x0: c.minX, y0: c.minY, width: bw, height: bh, bits: local),
                holes: LocalMask(x0: c.minX, y0: c.minY, width: bw, height: bh, bits: holes),
                filled: LocalMask(x0: c.minX, y0: c.minY, width: bw, height: bh, bits: filled),
                textRect: textRect, glyph: glyph, isDark: dark))
        }
        return out
    }

    /// Glyph size. The size of the larger marks (85th percentile) is robust to
    /// small kana, dakuten and "…" dots; the projection profile (column widths for
    /// vertical text, row heights for horizontal) is preferred when it agrees,
    /// since kanji often split into several smaller marks.
    static func estimateGlyphSize(holes: [Bool], width: Int, height: Int, components: [Component]) -> CGFloat {
        let sizes = components.map { max($0.width, $0.height) }.filter { $0 >= 3 }.sorted()
        let fromMarks = sizes.isEmpty ? 0 : Double(sizes[Int(0.85 * Double(sizes.count - 1))])
        var colProfile = [Int](repeating: 0, count: width)
        var rowProfile = [Int](repeating: 0, count: height)
        for y in 0..<height {
            for x in 0..<width where holes[y * width + x] {
                colProfile[x] += 1
                rowProfile[y] += 1
            }
        }
        func runs(_ p: [Int]) -> [Int] {
            var out: [Int] = []
            var run = 0
            for v in p {
                if v > 0 { run += 1 } else if run > 0 { out.append(run); run = 0 }
            }
            if run > 0 { out.append(run) }
            return out
        }
        func upperQuartile(_ v: [Int]) -> Double {
            guard !v.isEmpty else { return 0 }
            let s = v.sorted()
            return Double(s[Int(0.75 * Double(s.count - 1))])
        }
        let a = upperQuartile(runs(colProfile)), b = upperQuartile(runs(rowProfile))
        let fromProfile = [a, b].filter { $0 > 0 }.min() ?? 0
        let g = (fromMarks > 0 && fromProfile >= fromMarks && fromProfile <= 1.5 * fromMarks) || fromMarks == 0
            ? fromProfile : fromMarks
        return CGFloat(max(8, g))
    }

    /// Connected-component labelling with an explicit stack.
    static func label(_ mask: [Bool], width: Int, height: Int, eightConnected: Bool) -> ([Int32], [Component]) {
        let n = width * height
        var labels = [Int32](repeating: -1, count: n)
        var comps: [Component] = []
        var stack: [Int] = []
        stack.reserveCapacity(4096)
        for start in 0..<n where mask[start] && labels[start] < 0 {
            let cid = Int32(comps.count)
            var c = Component(id: cid, area: 0, minX: Int.max, minY: Int.max, maxX: -1, maxY: -1)
            labels[start] = cid
            stack.append(start)
            while let p = stack.popLast() {
                let y = p / width, x = p - y * width
                c.area += 1
                if x < c.minX { c.minX = x }
                if x > c.maxX { c.maxX = x }
                if y < c.minY { c.minY = y }
                if y > c.maxY { c.maxY = y }
                let left = x > 0, right = x < width - 1, up = y > 0, down = y < height - 1
                if left { let q = p - 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                if right { let q = p + 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                if up { let q = p - width; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                if down { let q = p + width; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                if eightConnected {
                    if left && up { let q = p - width - 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                    if right && up { let q = p - width + 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                    if left && down { let q = p + width - 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                    if right && down { let q = p + width + 1; if mask[q] && labels[q] < 0 { labels[q] = cid; stack.append(q) } }
                }
            }
            comps.append(c)
        }
        return (labels, comps)
    }
}
